import os
import logging

from app.db import db

log = logging.getLogger(__name__)

# Сколько часов считаем "достаточно старым", чтобы удалить запись из media_dedup.
# По умолчанию 48 часов — заметно больше твоих 4 часов TTL в S3,
# но можно переопределить через переменную окружения.
MEDIA_DEDUP_TTL_HOURS = int(os.getenv("MEDIA_DEDUP_TTL_HOURS", "48"))


def cleanup_once() -> int:
    """
    Удаляет из media_dedup записи, у которых last_used_at старше TTL.
    Ничего не делает с S3 — там у тебя уже крутится свой cron.
    Возвращает количество удалённых строк.
    """
    if MEDIA_DEDUP_TTL_HOURS <= 0:
        log.info("MEDIA_DEDUP_TTL_HOURS <= 0, очистка отключена")
        return 0

    with db() as conn, conn.cursor() as cur:
        cur.execute(
            """
            DELETE FROM media_dedup
             WHERE last_used_at < now() - (%s || ' hours')::interval
            """,
            (str(MEDIA_DEDUP_TTL_HOURS),),
        )
        deleted = cur.rowcount or 0

    log.info(
        "cleanup_media_dedup: deleted %s rows older than %s hours",
        deleted,
        MEDIA_DEDUP_TTL_HOURS,
    )
    return deleted


def main():
    logging.basicConfig(level=logging.INFO)
    deleted = cleanup_once()
    print(
        f"Deleted {deleted} media_dedup rows older than {MEDIA_DEDUP_TTL_HOURS} hours"
    )


if __name__ == "__main__":
    main()

