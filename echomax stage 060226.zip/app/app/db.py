import os
import asyncio
import logging
from contextlib import contextmanager
import psycopg2
import psycopg2.extras
from psycopg2.pool import ThreadedConnectionPool
from app.config import Cfg

log = logging.getLogger("db")

_POOL: ThreadedConnectionPool | None = None


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)))
    except Exception:
        return default


def _make_dsn() -> str:
    """
    Собираем DSN из Cfg.PG/ENV с таймаутом соединения и TCP keepalive.
    Никаких параметров не убираем по сравнению с текущим кодом — только добавляем безопасные.
    """
    host = (Cfg.PG.get("host") or os.getenv("POSTGRES_HOST") or "postgres")
    dbname = (Cfg.PG.get("db")   or os.getenv("POSTGRES_DB")   or "postgres")
    user = (Cfg.PG.get("user")   or os.getenv("POSTGRES_USER") or "postgres")
    password = (Cfg.PG.get("password") or os.getenv("POSTGRES_PASSWORD") or "")
    port = int(Cfg.PG.get("port", os.getenv("POSTGRES_PORT") or 5432))

    # Дополнительно: application_name и keepalive-параметры libpq.
    app_name = os.getenv("PG_APP_NAME", "tg-relay")
    sslmode = os.getenv("POSTGRES_SSLMODE")  # опционально: require/disable/verify-full и т.п.

    parts = [
        f"dbname={dbname}",
        f"user={user}",
        f"password={password}",
        f"host={host}",
        f"port={port}",
        "connect_timeout=5",
        "keepalives=1",
        "keepalives_idle=30",
        "keepalives_interval=10",
        "keepalives_count=3",
        f"application_name={app_name}",
    ]
    if sslmode:
        parts.append(f"sslmode={sslmode}")

    return " ".join(parts)


def _get_pool() -> ThreadedConnectionPool:
    """
    Ленивая инициализация пула.
    Границы пула читаем из ENV, при этом гарантируем max >= min.
    """
    global _POOL
    if _POOL is not None:
        return _POOL

    minconn = _env_int("PG_POOL_MIN", 2)
    maxconn = _env_int("PG_POOL_MAX", 32)
    if maxconn < minconn:
        maxconn = minconn

    _POOL = ThreadedConnectionPool(
        minconn=minconn,
        maxconn=maxconn,
        dsn=_make_dsn(),
        cursor_factory=psycopg2.extras.RealDictCursor,
    )
    log.info("PG pool created: min=%s max=%s", minconn, maxconn)
    return _POOL


def _apply_session_settings(conn) -> None:
    """
    Выставляем сессионные таймауты сразу после checkout из пула.
    Это защищает от «висячих» запросов и заблокированных транзакций.
    Значения настраиваются через ENV, при отсутствии — дефолты разумные.
    """
    st_ms = _env_int("PG_STATEMENT_TIMEOUT_MS", 12000)  # 12s
    idle_tx_ms = _env_int("PG_IDLE_IN_TX_TIMEOUT_MS", 5000)  # 5s
    try:
        with conn.cursor() as c:
            c.execute(
                "SET statement_timeout = %s; "
                "SET idle_in_transaction_session_timeout = %s;",
                (f"{st_ms}ms", f"{idle_tx_ms}ms"),
            )
    except Exception as e:
        # Не роняем поток на проблемах с SET (редко, но бывает)
        log.warning("Failed to apply PG session settings: %s", e)


@contextmanager
def db():
    """
    Совместимо с существующим кодом:
        with db() as conn, conn.cursor() as cur:
            cur.execute("select 1")
    Под капотом — пул. Автокоммит не включаем: явно commit/rollback на выходе.
    """
    pool = _get_pool()
    conn = pool.getconn()
    try:
        _apply_session_settings(conn)
        yield conn
        conn.commit()
    except Exception:
        try:
            conn.rollback()
        except Exception:
            pass
        raise
    finally:
        try:
            pool.putconn(conn)
        except Exception as e:
            log.warning("Failed to return PG connection to pool: %s", e)


def close_pool():
    """
    На случай корректного завершения приложения.
    """
    global _POOL
    if _POOL:
        try:
            _POOL.closeall()
        finally:
            _POOL = None
            log.info("PG pool closed")


def query(sql: str, params: tuple | dict | None = None):
    """
    Синхронный helper — использовать там, где и так синхронный контекст.
    Возвращает list[dict] для SELECT, либо None для команд без результата.
    """
    with db() as conn:
        with conn.cursor() as cur:
            cur.execute(sql, params or ())
            if cur.description:
                return cur.fetchall()
            return None


async def aquery(sql: str, params: tuple | dict | None = None):
    """
    Асинхронный helper — выполняет query() в thread executor, чтобы не блокировать event loop.
    Промежуточное решение до миграции на asyncpg.
    """
    return await asyncio.to_thread(query, sql, params)

