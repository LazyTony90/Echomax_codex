# app/app/admin.py
import os
import logging
import asyncio
from typing import Optional, List

from aiogram import Router, F
from aiogram.enums import ChatType
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
from aiogram.types import (
    Message,
    CallbackQuery,
    InlineKeyboardMarkup,
)
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.exceptions import TelegramBadRequest

from app.db import db
from app.link_router_cache import invalidate_source_links
from app.alerts import get_recent_alerts  # 🔹 для вывода последних алертов

log = logging.getLogger(__name__)
router = Router()

# ----------- Админы из ENV -----------


def _parse_admin_ids(env_val: str) -> set[int]:
    ids: set[int] = set()
    for chunk in (env_val or "").replace(",", " ").split():
        try:
            ids.add(int(chunk))
        except Exception:
            pass
    return ids


ADMIN_IDS: set[int] = _parse_admin_ids(os.getenv("ADMIN_IDS", ""))


def is_admin(uid: Optional[int]) -> bool:
    return bool(uid) and (uid in ADMIN_IDS)


async def deny(cq_or_msg):
    txt = "⛔ Доступ запрещён."
    if isinstance(cq_or_msg, Message):
        await cq_or_msg.answer(txt)
    else:
        await cq_or_msg.answer(txt, show_alert=True)


# ----------- FSM -----------


class AdminLookup(StatesGroup):
    waiting_user_id = State()


class AdminBroadcast(StatesGroup):
    waiting_text = State()


# ----------- Клавиатуры -----------


def kb_admin_root() -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    kb.button(text="🔎 Пользователь по ID", callback_data="admin:user")
    kb.button(text="📣 Рассылка", callback_data="admin:broadcast")
    kb.button(text="📊 Диагностика", callback_data="admin:stats")
    kb.button(text="▶️ Снять авто-паузу MAX", callback_data="admin:unpause_auto")
    kb.adjust(1)
    return kb.as_markup()

def kb_admin_stats() -> InlineKeyboardMarkup:
    """
    Клавиатура, которая показывается на экране диагностики.
    """
    kb = InlineKeyboardBuilder()
    kb.button(text="🔄 Обновить", callback_data="admin:stats:refresh")
    kb.button(text="📜 Последние алерты", callback_data="admin:stats:alerts")
    kb.button(text="🏠 Админ-меню", callback_data="admin:menu")
    kb.adjust(1)
    return kb.as_markup()

def _reset_auto_paused_links() -> tuple[int, list[int]]:
    """
    Снимает авто-паузу со всех связок, которые:
      - target_platform = 'max'
      - enabled = false
      - auto_paused = true

    Возвращает (количество изменённых связок, список source_chat_id для инвалидирования кэша).
    """
    with db() as conn, conn.cursor() as cur:
        cur.execute(
            """
            UPDATE channel_links
               SET enabled = true,
                   auto_paused = false
             WHERE auto_paused = true
               AND enabled = false
               AND target_platform = 'max'
         RETURNING source_chat_id
            """
        )
        rows = cur.fetchall() or []

    src_ids = sorted(
        {int(r["source_chat_id"]) for r in rows if r.get("source_chat_id") is not None}
    )
    return len(rows), src_ids


def kb_user_links(tg_user_id: int) -> InlineKeyboardMarkup:
    with db() as conn, conn.cursor() as cur:
        cur.execute(
            """
           select id, coalesce(name, concat('Связка #', id)) as title
                , source_chat_id, target_chat_id, paid_until, enabled
                , target_platform
           from channel_links
           where owner_tg_user_id=%s
           order by id
        """,
            (tg_user_id,),
        )
        rows = cur.fetchall()
    kb = InlineKeyboardBuilder()
    for r in rows:
        title = r["title"]
        kb.button(text=f"{title}", callback_data=f"admin:link:{r['id']}")
    kb.button(text="⬅️ Назад", callback_data="admin:menu")
    kb.adjust(1)
    return kb.as_markup()


def kb_link_actions(link_id: int) -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    kb.button(text="➕ +1 мес", callback_data=f"admin:link:add:{link_id}:m1")
    kb.button(text="➕ +3 мес", callback_data=f"admin:link:add:{link_id}:m3")
    kb.button(text="➕ +6 мес", callback_data=f"admin:link:add:{link_id}:m6")
    kb.button(text="➕ +12 мес", callback_data=f"admin:link:add:{link_id}:m12")
    kb.button(text="➕ +7 дней", callback_data=f"admin:link:add:{link_id}:d7")
    kb.button(text="⏯ Вкл/Выкл", callback_data=f"admin:link:toggle:{link_id}")
    kb.button(text="⬅️ К пользователю", callback_data="admin:back_to_user_links")
    kb.button(text="🏠 Админ-меню", callback_data="admin:menu")
    kb.adjust(2, 2, 2, 1, 1)
    return kb.as_markup()


def kb_broadcast_segments() -> InlineKeyboardMarkup:
    """
    Клавиатура выбора сегмента для рассылки.
    """
    kb = InlineKeyboardBuilder()
    kb.button(
        text="👥 Все, кто создавал связки",
        callback_data="admin:bcast:seg:all_creators",
    )
    kb.button(
        text="✅ С действующим периодом",
        callback_data="admin:bcast:seg:active_any",
    )
    kb.button(
        text="💬 Чаты с действующим периодом",
        callback_data="admin:bcast:seg:active_chats",
    )
    kb.button(
        text="📣 Каналы с действующим периодом",
        callback_data="admin:bcast:seg:active_channels",
    )
    kb.button(
        text="⏳ Без действующего периода",
        callback_data="admin:bcast:seg:no_active",
    )
    kb.button(text="⬅️ Назад", callback_data="admin:menu")
    kb.adjust(1)
    return kb.as_markup()


# ----------- Вспомогательные тексты -----------


def link_info_text(link_id: int) -> str:
    from datetime import datetime, timezone

    with db() as conn, conn.cursor() as cur:
        cur.execute(
            """
          select cl.id, cl.name, cl.source_chat_id, cl.target_chat_id,
                 cl.target_platform,
                 cl.paid_until, cl.trial_until, cl.is_trial, cl.enabled,
                 u.tg_user_id,
                 cl.link_type
          from channel_links cl
          join users u on u.tg_user_id = cl.owner_tg_user_id
          where cl.id=%s
        """,
            (link_id,),
        )
        L = cur.fetchone()
    if not L:
        return "Связка не найдена."

    title = L["name"] or f"Связка #{L['id']}"
    status = "✅ Включена" if L["enabled"] else "⏸ Отключена"
    paid = (
        f"оплачено до <b>{L['paid_until']:%Y-%m-%d %H:%M}</b>"
        if L.get("paid_until")
        else "не оплачено"
    )

    # Тип связки (канал/чат)
    link_type = (L.get("link_type") or "channel").lower()
    if link_type == "chat":
        link_type_label = "чат"
    else:
        link_type_label = "канал"

    # Метка платформы приёмника
    platform = L.get("target_platform", "tg")
    if platform == "tg":
        dst_label = "Telegram"
    elif platform == "max":
        dst_label = "MAX"
    else:
        dst_label = platform

    trial = ""
    now = datetime.now(timezone.utc)
    if L.get("trial_until"):
        if L["trial_until"] > now:
            trial = f"\n🔥 Триал до <b>{L['trial_until']:%Y-%m-%d %H:%M}</b>"
        else:
            trial = "\nТриал истёк"
            if not L.get("paid_until") or L["paid_until"] <= now:
                trial += "\n<b>⚠️ Триал закончился. Нужна оплата, чтобы продолжить.</b>"

    return (
        f"<b>{title}</b> (id={L['id']}, тип: {link_type_label})\n"
        f"Владелец: <code>{L['tg_user_id']}</code>\n"
        f"Источник (Telegram): <code>{L['source_chat_id']}</code>\n"
        f"Приёмник ({dst_label}): <code>{L['target_chat_id']}</code>\n"
        f"Статус: {status}, {paid}{trial}"
    )


def user_links_text(tg_user_id: int) -> str:
    with db() as conn, conn.cursor() as cur:
        cur.execute(
            """
           select id, coalesce(name, concat('Связка #', id)) as title,
                  source_chat_id, target_chat_id, target_platform,
                  paid_until, enabled, link_type
           from channel_links
           where owner_tg_user_id=%s
           order by id
        """,
            (tg_user_id,),
        )
        rows = cur.fetchall()
    if not rows:
        return f"У пользователя <code>{tg_user_id}</code> нет связок."
    lines = [f"<b>Связки пользователя</b> <code>{tg_user_id}</code>:"]
    for r in rows:
        status = "✅" if r["enabled"] else "⏸"
        paid = r["paid_until"].strftime("%Y-%m-%d") if r.get("paid_until") else "—"

        platform = r.get("target_platform", "tg")
        if platform == "tg":
            dst_label = "TG"
        elif platform == "max":
            dst_label = "MAX"
        else:
            dst_label = platform

        link_type = (r.get("link_type") or "channel").lower()
        if link_type == "chat":
            ltype_label = "чат"
        else:
            ltype_label = "канал"

        lines.append(
            f"• #{r['id']} «{r['title']}» [{ltype_label}] {status}  "
            f"<code>{r['source_chat_id']}</code> → [{dst_label}] <code>{r['target_chat_id']}</code>  "
            f"до: <b>{paid}</b>"
        )
    return "\n".join(lines)


def _segment_human_name(key: str) -> str:
    mapping = {
        "all_creators": "Все, кто создавал связки",
        "active_any": "Все с действующим (оплаченный или триал) периодом",
        "active_chats": "Связки чатов с действующим периодом",
        "active_channels": "Связки каналов с действующим периодом",
        "no_active": "Создавали связки, но без действующего периода",
    }
    return mapping.get(key, key)


def _select_broadcast_user_ids(segment: str) -> List[int]:
    """
    Возвращает список tg_user_id для рассылки в зависимости от сегмента.
    Все выборки делаются по owner_tg_user_id в channel_links.
    """
    with db() as conn, conn.cursor() as cur:
        if segment == "all_creators":
            cur.execute(
                """
                select distinct owner_tg_user_id as uid
                  from channel_links
                 where owner_tg_user_id is not null
                """
            )
        elif segment == "active_any":
            cur.execute(
                """
                select distinct owner_tg_user_id as uid
                  from channel_links
                 where owner_tg_user_id is not null
                   and (paid_until >= now() or trial_until >= now())
                """
            )
        elif segment == "active_chats":
            cur.execute(
                """
                select distinct owner_tg_user_id as uid
                  from channel_links
                 where owner_tg_user_id is not null
                   and coalesce(link_type, 'channel') = 'chat'
                   and (paid_until >= now() or trial_until >= now())
                """
            )
        elif segment == "active_channels":
            cur.execute(
                """
                select distinct owner_tg_user_id as uid
                  from channel_links
                 where owner_tg_user_id is not null
                   and coalesce(link_type, 'channel') = 'channel'
                   and (paid_until >= now() or trial_until >= now())
                """
            )
        elif segment == "no_active":
            # пользователи, у которых нет НИ ОДНОЙ активной (trial/paid) связки
            cur.execute(
                """
                select distinct c.owner_tg_user_id as uid
                  from channel_links c
                 where c.owner_tg_user_id is not null
                   and not exists (
                       select 1
                         from channel_links c2
                        where c2.owner_tg_user_id = c.owner_tg_user_id
                          and (c2.paid_until >= now() or c2.trial_until >= now())
                   )
                """
            )
        else:
            return []

        rows = cur.fetchall()

    uids: List[int] = []
    for r in rows:
        uid = r.get("uid") if isinstance(r, dict) else r[0]
        if uid:
            try:
                uids.append(int(uid))
            except Exception:
                continue
    return uids


def _diagnostics_text() -> str:
    """
    Простейшая диагностика по таблице channel_links.
    """
    with db() as conn, conn.cursor() as cur:
        # Всего уникальных владельцев
        cur.execute(
            "select count(distinct owner_tg_user_id) as c from channel_links where owner_tg_user_id is not null"
        )
        owners_row = cur.fetchone() or {"c": 0}
        owners = owners_row.get("c", 0)

        # Всего связок
        cur.execute("select count(*) as c from channel_links")
        links_row = cur.fetchone() or {"c": 0}
        total_links = links_row.get("c", 0)

        # Включённых связок
        cur.execute("select count(*) as c from channel_links where enabled = true")
        enabled_row = cur.fetchone() or {"c": 0}
        enabled_links = enabled_row.get("c", 0)

        # Связок с активным периодом trial/paid
        cur.execute(
            """
            select count(*) as c
              from channel_links
             where (paid_until >= now() or trial_until >= now())
            """
        )
        active_row = cur.fetchone() or {"c": 0}
        active_links = active_row.get("c", 0)

        # Активные чат-связки
        cur.execute(
            """
            select count(*) as c
              from channel_links
             where coalesce(link_type, 'channel') = 'chat'
               and (paid_until >= now() or trial_until >= now())
            """
        )
        active_chat_row = cur.fetchone() or {"c": 0}
        active_chat_links = active_chat_row.get("c", 0)

        # Активные канал-связки
        cur.execute(
            """
            select count(*) as c
              from channel_links
             where coalesce(link_type, 'channel') = 'channel'
               and (paid_until >= now() or trial_until >= now())
            """
        )
        active_channel_row = cur.fetchone() or {"c": 0}
        active_channel_links = active_channel_row.get("c", 0)

        # Включённых, но без активного периода (возможный «подозрительный» кейс)
        cur.execute(
            """
            select count(*) as c
              from channel_links
             where enabled = true
               and not (paid_until >= now() or trial_until >= now())
            """
        )
        enabled_without_active_row = cur.fetchone() or {"c": 0}
        enabled_without_active = enabled_without_active_row.get("c", 0)

    return (
        "<b>📊 Диагностика</b>\n"
        f"👥 Пользователей, создававших связки: <b>{owners}</b>\n"
        f"🔗 Всего связок: <b>{total_links}</b>\n"
        f"✅ Связок с активным периодом (trial/paid): <b>{active_links}</b>\n"
        f" 💬 из них чат-связки: <b>{active_chat_links}</b>\n"
        f" 📣 из них канал-связки: <b>{active_channel_links}</b>\n"
        f"🟢 Включённых связок (enabled=true): <b>{enabled_links}</b>\n"
        f"⚠️ Включены, но период истёк: <b>{enabled_without_active}</b>\n"
    )


def _recent_alerts_text(limit: int = 20) -> str:
    """
    Текст для вывода последних алертов (ошибок/предупреждений),
    которые проходят через notify_admin_throttled().
    """
    alerts = get_recent_alerts(limit=limit)
    if not alerts:
        return "<b>📜 Последние алерты</b>\n\nНет записей."

    lines: List[str] = [f"<b>📜 Последние алерты</b> (макс. {limit})"]
    for a in alerts:
        dt = a["ts"].astimezone()  # локальное время на сервере
        ts_str = dt.strftime("%Y-%m-%d %H:%M:%S")
        key = a.get("key") or "-"
        text = a.get("text") or ""
        if len(text) > 400:
            text = text[:400] + "…"
        lines.append(f"🕒 <code>{ts_str}</code>  <i>{key}</i>\n{text}")

    return "\n\n".join(lines)


# ----------- Обработчики: вход в админку -----------


@router.message(Command("admin"), F.chat.type == ChatType.PRIVATE)
async def admin_entry(msg: Message):
    if not is_admin(msg.from_user.id):
        return await deny(msg)
    await msg.answer("🏠 <b>Админ-меню</b>", reply_markup=kb_admin_root())


@router.callback_query(F.data == "admin:menu")
async def admin_menu(cq: CallbackQuery):
    if not is_admin(cq.from_user.id):
        return await deny(cq)
    await cq.message.edit_text("🏠 <b>Админ-меню</b>", reply_markup=kb_admin_root())
    await cq.answer()

@router.callback_query(F.data == "admin:unpause_auto")
async def admin_unpause_auto(cq: CallbackQuery):
    """
    Шаг 1: подтверждение массового снятия авто-пауз.
    """
    if not is_admin(cq.from_user.id):
        return await deny(cq)

    kb = InlineKeyboardBuilder()
    kb.button(
        text="✅ Снять авто-паузу со всех MAX-связок",
        callback_data="admin:unpause_auto:go",
    )
    kb.button(
        text="⬅️ Отмена",
        callback_data="admin:menu",
    )
    kb.adjust(1)

    await cq.message.edit_text(
        "Вы собираетесь <b>снять авто-паузу</b> со всех связок, которые были "
        "автоматически остановлены из-за ошибок в MAX.\n\n"
        "Ручные паузы пользователей затронуты не будут.",
        reply_markup=kb.as_markup(),
    )
    await cq.answer()


@router.callback_query(F.data == "admin:unpause_auto:go")
async def admin_unpause_auto_go(cq: CallbackQuery):
    """
    Шаг 2: фактическое снятие авто-пауз.
    """
    if not is_admin(cq.from_user.id):
        return await deny(cq)

    # Делаем тяжёлую БД-операцию в threadpool
    count, src_ids = await asyncio.to_thread(_reset_auto_paused_links)

    # Инвалидируем кэш маршрутов по всем источникам
    for chat_id in src_ids:
        try:
            invalidate_source_links(chat_id)
        except Exception as e:
            log.warning(
                "admin_unpause_auto: failed to invalidate cache for %s: %s",
                chat_id,
                e,
            )

    await cq.message.edit_text(
        f"Снял авто-паузу со связок MAX: <b>{count}</b> шт.\n"
        "Ручные паузы пользователей не изменялись.",
        reply_markup=kb_admin_root(),
    )
    await cq.answer("Готово.")

# ----------- Обработчики: поиск пользователя и его связок -----------


@router.callback_query(F.data == "admin:user")
async def admin_user_query(cq: CallbackQuery, state: FSMContext):
    if not is_admin(cq.from_user.id):
        return await deny(cq)
    await state.set_state(AdminLookup.waiting_user_id)
    await cq.message.edit_text("Введите <b>Telegram user_id</b> пользователя (число).")
    await cq.answer()


@router.message(AdminLookup.waiting_user_id, F.chat.type == ChatType.PRIVATE)
async def admin_user_receive_id(msg: Message, state: FSMContext):
    if not is_admin(msg.from_user.id):
        return await deny(msg)
    try:
        uid = int((msg.text or "").strip())
    except Exception:
        return await msg.answer("Нужно число. Введите user_id ещё раз.")
    await state.update_data(lookup_uid=uid)
    await state.clear()
    await msg.answer(user_links_text(uid), reply_markup=kb_user_links(uid))


@router.callback_query(F.data == "admin:back_to_user_links")
async def admin_back_to_user_links(cq: CallbackQuery, state: FSMContext):
    if not is_admin(cq.from_user.id):
        return await deny(cq)
    data = await state.get_data()
    uid = data.get("lookup_uid")
    if not uid:
        await cq.message.edit_text("Введите <b>Telegram user_id</b> пользователя (число).")
        await state.set_state(AdminLookup.waiting_user_id)
        return await cq.answer()
    await cq.message.edit_text(user_links_text(uid), reply_markup=kb_user_links(uid))
    await cq.answer()


@router.callback_query(
    F.data.startswith("admin:link:")
    & ~F.data.contains(":add:")
    & ~F.data.contains(":toggle:")
)
async def admin_link_open(cq: CallbackQuery, state: FSMContext):
    if not is_admin(cq.from_user.id):
        return await deny(cq)
    parts = cq.data.split(":")  # admin:link:<id>
    link_id = int(parts[2])
    with db() as conn, conn.cursor() as cur:
        cur.execute("select owner_tg_user_id from channel_links where id=%s", (link_id,))
        row = cur.fetchone()
    if row:
        await state.update_data(lookup_uid=row["owner_tg_user_id"])
    await cq.message.edit_text(link_info_text(link_id), reply_markup=kb_link_actions(link_id))
    await cq.answer()


@router.callback_query(F.data.startswith("admin:link:add:"))
async def admin_link_add_time(cq: CallbackQuery):
    if not is_admin(cq.from_user.id):
        return await deny(cq)
    # admin:link:add:<link_id>:<period>
    _, _, _, link_id_s, period = cq.data.split(":")
    link_id = int(link_id_s)

    period_map = {
        "m1": "1 month",
        "m3": "3 months",
        "m6": "6 months",
        "m12": "12 months",
        "d7": "7 days",
    }
    if period not in period_map:
        return await cq.answer("Неизвестный период.", show_alert=True)

    with db() as conn, conn.cursor() as cur:
        cur.execute(
            f"""
           update channel_links
              set paid_until =
                    (case when paid_until is null or paid_until < now()
                          then now() else paid_until end)
                    + interval '{period_map[period]}',
                  is_trial = false         -- любая «оплата» отключает триал
            where id=%s
        returning paid_until, source_chat_id;
        """,
            (link_id,),
        )
        row = cur.fetchone()

    if not row:
        return await cq.answer("Связка не найдена.", show_alert=True)

    # Инвалидируем кэш по источнику
    try:
        invalidate_source_links(row["source_chat_id"])
    except Exception as e:
        log.warning("admin_link_add_time: failed to invalidate cache: %s", e)

    await cq.message.edit_text(link_info_text(link_id), reply_markup=kb_link_actions(link_id))
    await cq.answer(f"✅ Продлено до {row['paid_until']:%Y-%m-%d %H:%M}")


@router.callback_query(F.data.startswith("admin:link:toggle:"))
async def admin_link_toggle(cq: CallbackQuery):
    if not is_admin(cq.from_user.id):
        return await deny(cq)
    link_id = int(cq.data.split(":")[-1])
    with db() as conn, conn.cursor() as cur:
        cur.execute(
            """
           update channel_links
              set enabled = not enabled
            where id=%s
        returning enabled, source_chat_id;
        """,
            (link_id,),
        )
        row = cur.fetchone()
    if not row:
        return await cq.answer("Связка не найдена.", show_alert=True)

    # Инвалидируем кэш по источнику
    try:
        invalidate_source_links(row["source_chat_id"])
    except Exception as e:
        log.warning("admin_link_toggle: failed to invalidate cache: %s", e)

    state = "включена" if row["enabled"] else "отключена"
    await cq.message.edit_text(link_info_text(link_id), reply_markup=kb_link_actions(link_id))
    await cq.answer(f"Состояние: {state}")


# ----------- Обработчики: диагностика -----------


@router.callback_query(F.data == "admin:stats")
async def admin_stats(cq: CallbackQuery):
    if not is_admin(cq.from_user.id):
        return await deny(cq)
    text = _diagnostics_text()
    try:
        await cq.message.edit_text(text, reply_markup=kb_admin_stats())
    except TelegramBadRequest as e:
        if "message is not modified" in str(e):
            await cq.answer("Статистика не изменилась.")
            return
        raise
    await cq.answer()


@router.callback_query(F.data == "admin:stats:refresh")
async def admin_stats_refresh(cq: CallbackQuery):
    if not is_admin(cq.from_user.id):
        return await deny(cq)
    text = _diagnostics_text()
    try:
        await cq.message.edit_text(text, reply_markup=kb_admin_stats())
    except TelegramBadRequest as e:
        if "message is not modified" in str(e):
            await cq.answer("Статистика не изменилась.")
            return
        raise
    await cq.answer("Обновлено.")


@router.callback_query(F.data == "admin:stats:alerts")
async def admin_stats_alerts(cq: CallbackQuery):
    if not is_admin(cq.from_user.id):
        return await deny(cq)
    text = _recent_alerts_text(limit=20)
    try:
        await cq.message.edit_text(text, reply_markup=kb_admin_stats())
    except TelegramBadRequest as e:
        if "message is not modified" in str(e):
            await cq.answer("Без изменений.")
            return
        raise
    await cq.answer()


# ----------- Обработчики: рассылка -----------


@router.callback_query(F.data == "admin:broadcast")
async def admin_broadcast_menu(cq: CallbackQuery, state: FSMContext):
    if not is_admin(cq.from_user.id):
        return await deny(cq)
    # на всякий случай очищаем состояние рассылки
    data = await state.get_data()
    if data.get("bcast_segment"):
        await state.clear()
    await cq.message.edit_text(
        "📣 <b>Рассылка</b>\n\n"
        "Выберите сегмент пользователей, которым нужно отправить сообщение.",
        reply_markup=kb_broadcast_segments(),
    )
    await cq.answer()


@router.callback_query(F.data.startswith("admin:bcast:seg:"))
async def admin_broadcast_choose_segment(cq: CallbackQuery, state: FSMContext):
    if not is_admin(cq.from_user.id):
        return await deny(cq)
    # admin:bcast:seg:<key>
    parts = cq.data.split(":")
    seg_key = parts[-1]
    human = _segment_human_name(seg_key)

    await state.set_state(AdminBroadcast.waiting_text)
    await state.update_data(bcast_segment=seg_key)

    await cq.message.edit_text(
        "📣 <b>Рассылка</b>\n\n"
        f"Сегмент: <b>{human}</b>\n\n"
        "Отправьте одним сообщением <b>текст рассылки</b>, "
        "который будет отправлен всем пользователям этого сегмента.\n\n"
        "Рассылка может занять некоторое время, в зависимости от количества получателей.",
    )
    await cq.answer()


@router.message(AdminBroadcast.waiting_text, F.chat.type == ChatType.PRIVATE)
async def admin_broadcast_receive_text(msg: Message, state: FSMContext):
    if not is_admin(msg.from_user.id):
        return await deny(msg)

    text = (msg.text or "").strip()
    if not text:
        return await msg.answer("Текст пустой. Отправьте текст рассылки ещё раз.")

    data = await state.get_data()
    seg_key = data.get("bcast_segment")
    if not seg_key:
        await state.clear()
        return await msg.answer(
            "Сегмент рассылки не выбран. Откройте /admin → «📣 Рассылка» и выберите сегмент заново."
        )

    human = _segment_human_name(seg_key)
    user_ids = _select_broadcast_user_ids(seg_key)
    total = len(user_ids)
    if total == 0:
        await state.clear()
        return await msg.answer(
            f"В сегменте «{human}» нет получателей. Рассылка отменена.",
            reply_markup=kb_admin_root(),
        )

    await msg.answer(
        f"📣 Запускаю рассылку для сегмента «{human}».\n"
        f"Получателей: <b>{total}</b>.\n\n"
        "По завершении пришлю короткий отчёт.",
    )

    ok = 0
    fail = 0

    # Небольшая пауза между отправками, чтобы не ловить лимиты Telegram
    delay_sec = float(os.getenv("ADMIN_BROADCAST_DELAY", "0.05"))

    for uid in user_ids:
        try:
            await msg.bot.send_message(uid, text)
            ok += 1
        except Exception as e:
            fail += 1
            log.warning("admin broadcast: failed to send to %s: %s", uid, e)
        if delay_sec > 0:
            await asyncio.sleep(delay_sec)

    await state.clear()

    await msg.answer(
        "✅ Рассылка завершена.\n\n"
        f"Сегмент: <b>{human}</b>\n"
        f"Всего пользователей в сегменте: <b>{total}</b>\n"
        f"Успешно отправлено: <b>{ok}</b>\n"
        f"Не удалось отправить: <b>{fail}</b>",
        reply_markup=kb_admin_root(),
    )

