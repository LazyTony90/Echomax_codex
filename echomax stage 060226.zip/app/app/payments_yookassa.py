#app/app/payments_yookassa.py
import os
import logging
import asyncio
import uuid
import json
import contextlib
from datetime import datetime, timedelta, timezone
from typing import Optional, Tuple
from calendar import monthrange  # для календарного +1 месяца

from yookassa import Configuration, Payment
from psycopg2.extras import Json

from app.db import db

log = logging.getLogger(__name__)

# -----------------------------------------------------------------------------
#  Инициализация ЮKassa (HTTP Basic Auth)
# -----------------------------------------------------------------------------

YK_SHOP_ID = os.getenv("YOOKASSA_SHOP_ID", "")
YK_SECRET_KEY = os.getenv("YOOKASSA_SECRET_KEY", "")

# Базовый URL, куда ЮKassa вернёт пользователя после оплаты
YK_RETURN_URL_BASE = os.getenv("YOOKASSA_RETURN_URL_BASE", "https://t.me/tgechomax_bot")

# Цена подписки за 1 месяц (в рублях)
_subscription_env = (
    os.getenv("SUBSCRIPTION_PRICE_RUB")
    or os.getenv("MONTHLY_PRICE_RUB")
    or "500"
)
YK_SUBSCRIPTION_PRICE_RUB = int(_subscription_env)

AUTOPAY_ENABLED = os.getenv("YK_AUTOPAY_ENABLED", "1") != "0"
AUTOPAY_INTERVAL_SEC = int(os.getenv("YK_AUTOPAY_INTERVAL_SEC", "90"))
AUTOPAY_BATCH_SIZE = int(os.getenv("YK_AUTOPAY_BATCH_SIZE", "30"))

# Автоплатёж: пауза перед повторной попыткой после неуспешного списания (в минутах)
AUTOPAY_RETRY_MINUTES = int(os.getenv("YK_AUTOPAY_RETRY_MINUTES", "360"))
# Максимальная пауза (минуты) при увеличивающемся backoff
AUTOPAY_RETRY_MAX_MINUTES = int(os.getenv("YK_AUTOPAY_RETRY_MAX_MINUTES", "1440"))


UTC = timezone.utc


def init_yookassa() -> None:
    """
    Инициализация конфигурации SDK ЮKassa.
    """
    if not (YK_SHOP_ID and YK_SECRET_KEY):
        log.warning(
            "YooKassa not configured: YOOKASSA_SHOP_ID or YOOKASSA_SECRET_KEY is empty"
        )
        return

    Configuration.account_id = YK_SHOP_ID
    Configuration.secret_key = YK_SECRET_KEY
    log.info("YooKassa configuration initialized with shop_id=%s", YK_SHOP_ID)


# вызывать один раз при старте приложения
init_yookassa()

# -----------------------------------------------------------------------------
#  Вспомогательные функции даты/подписки
# -----------------------------------------------------------------------------

def _calc_next_paid_until(current_paid_until: Optional[datetime]) -> datetime:
    """
    Куда продлить paid_until:

    - если уже есть действующая подписка в будущем — добавляем к ней +1 календарный месяц;
    - иначе — считаем от текущего момента (момент оплаты).

    Под "1 месяцем" понимаем именно календарный месяц:
    - 15 января -> 15 февраля
    - 31 января -> 28/29 февраля
    - 30 марта -> 30 апреля
    и т.п.
    """
    now = datetime.now(UTC)

    # Базовая точка: либо уже оплаченный период в будущем, либо текущий момент
    base = current_paid_until if (current_paid_until and current_paid_until > now) else now

    year = base.year
    month = base.month + 1
    if month > 12:
        month = 1
        year += 1

    # День месяца может "не влезть" (например, 31-е),
    # поэтому ограничиваем последним днём целевого месяца.
    last_day = monthrange(year, month)[1]
    day = min(base.day, last_day)

    # Время и таймзона сохраняются такими же, как у base
    return base.replace(year=year, month=month, day=day)

# -----------------------------------------------------------------------------
#  Доступ к БД (users.email, yk_payment_methods, link_autopay, yk_payments)
# -----------------------------------------------------------------------------

def _get_user_email(tg_user_id: int) -> Optional[str]:
    with db() as conn, conn.cursor() as cur:
        cur.execute(
            "SELECT email FROM users WHERE tg_user_id=%s LIMIT 1",
            (tg_user_id,),
        )
        row = cur.fetchone()
        if not row:
            return None
        return row["email"] or None


def _save_user_email(tg_user_id: int, email: str) -> None:
    with db() as conn, conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO users (tg_user_id, email)
            VALUES (%s, %s)
            ON CONFLICT (tg_user_id) DO UPDATE
                SET email = EXCLUDED.email
            """,
            (tg_user_id, email),
        )


def _insert_payment_method(tg_user_id: int, pm: dict) -> None:
    """
    pm — объект payment_method из ЮKassa (словарь целиком из webhook/Payment).
    Сохраняем/обновляем запись в yk_payment_methods.
    """
    pm_id = pm.get("id")
    pm_type = pm.get("type")
    last4 = None
    brand = None

    card = pm.get("card") or {}
    if card:
        last4 = card.get("last4")
        brand = card.get("card_type") or (card.get("card_product") or {}).get("name")

    if not pm_id:
        log.warning("insert_payment_method: payment_method.id is empty")
        return

    with db() as conn, conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO yk_payment_methods
                (tg_user_id, yk_payment_method_id, type, last4, card_brand, active)
            VALUES (%s, %s, %s, %s, %s, TRUE)
            ON CONFLICT (tg_user_id, yk_payment_method_id) DO UPDATE
                SET type = EXCLUDED.type,
                    last4 = EXCLUDED.last4,
                    card_brand = EXCLUDED.card_brand,
                    active = TRUE
            """,
            (tg_user_id, pm_id, pm_type, last4, brand),
        )


def _create_or_enable_link_autopay(
    link_id: int,
    tg_user_id: int,
    pm_id: str,
    new_paid_until: datetime,
) -> None:
    """
    Включаем автоплатёж для связки:
    - если запись для (link_id, tg_user_id) уже есть — обновляем и включаем,
    - если нет — создаём новую.
    """
    next_charge_at = new_paid_until  # списываем в день окончания оплаченного периода

    with db() as conn, conn.cursor() as cur:
        cur.execute(
            """
            UPDATE link_autopay
               SET yk_payment_method_id = %s,
                   period_months = 1,
                   enabled = TRUE,
                   canceled_at = NULL,
                   next_charge_at = %s
             WHERE link_id = %s
               AND tg_user_id = %s
            """,
            (pm_id, next_charge_at, link_id, tg_user_id),
        )

        if cur.rowcount == 0:
            cur.execute(
                """
                INSERT INTO link_autopay
                    (link_id, tg_user_id, yk_payment_method_id,
                     period_months, enabled, next_charge_at)
                VALUES (%s, %s, %s, 1, TRUE, %s)
                """,
                (link_id, tg_user_id, pm_id, next_charge_at),
            )


def _disable_link_autopay(link_id: int, tg_user_id: int) -> bool:
    """
    Отключаем автоплатёж (enabled = FALSE). Возвращаем True, если он был включён.
    """
    with db() as conn, conn.cursor() as cur:
        cur.execute(
            """
            UPDATE link_autopay
               SET enabled = FALSE,
                   canceled_at = NOW()
             WHERE link_id = %s
               AND tg_user_id = %s
               AND enabled = TRUE
         RETURNING id
            """,
            (link_id, tg_user_id),
        )
        row = cur.fetchone()
        return bool(row)


def _insert_payment_log(
    yk_payment_id: str,
    link_id: int,
    tg_user_id: int,
    amount: float,
    currency: str,
    status: str,
    paid_at: Optional[datetime],
    raw: dict,
) -> None:
    with db() as conn, conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO yk_payments
                (yk_payment_id, link_id, tg_user_id,
                 amount, currency, status, paid_at, raw_payload)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            ON CONFLICT (yk_payment_id) DO UPDATE
                SET status = EXCLUDED.status,
                    paid_at = EXCLUDED.paid_at,
                    raw_payload = EXCLUDED.raw_payload
            """,
            (yk_payment_id, link_id, tg_user_id, amount, currency, status, paid_at, Json(raw)),
        )


def _get_yk_payment_status(yk_payment_id: str) -> Optional[str]:
    """Return stored status for a YooKassa payment id, if any."""
    with db() as conn, conn.cursor() as cur:
        cur.execute(
            "SELECT status FROM yk_payments WHERE yk_payment_id = %s",
            (yk_payment_id,),
        )
        row = cur.fetchone()
        if not row:
            return None
        if isinstance(row, dict):
            return row.get("status")
        return row[0]


def _get_link_owner_and_paid_until(link_id: int) -> Tuple[Optional[int], Optional[datetime]]:
    with db() as conn, conn.cursor() as cur:
        cur.execute(
            "SELECT owner_tg_user_id, paid_until FROM channel_links WHERE id=%s",
            (link_id,),
        )
        row = cur.fetchone()
        if not row:
            return None, None
        return row["owner_tg_user_id"], row["paid_until"]


def _get_link_paid_until(link_id: int) -> Optional[datetime]:
    _, paid_until = _get_link_owner_and_paid_until(link_id)
    return paid_until


def _update_link_paid_until(link_id: int, new_paid_until: datetime) -> None:
    with db() as conn, conn.cursor() as cur:
        cur.execute(
            """
            UPDATE channel_links
               SET paid_until = %s,
                   is_trial = FALSE
             WHERE id = %s
            """,
            (new_paid_until, link_id),
        )


def _set_autopay_next_charge_at(link_id: int, tg_user_id: int, next_charge_at: datetime) -> None:
    """Обновляет next_charge_at в link_autopay, если профиль существует."""
    with db() as conn, conn.cursor() as cur:
        cur.execute(
            "UPDATE link_autopay\n"
            "   SET next_charge_at = %s\n"
            " WHERE link_id = %s\n"
            "   AND tg_user_id = %s\n"
            "   AND enabled = TRUE",
            (next_charge_at, link_id, tg_user_id),
        )

def _schedule_autopay_retry(link_id: int, tg_user_id: int) -> None:
    """Планирует повтор автосписания через backoff (по умолчанию 6 часов)."""
    now = datetime.now(UTC)
    delay_min = max(5, int(AUTOPAY_RETRY_MINUTES))
    delay_min = min(delay_min, int(AUTOPAY_RETRY_MAX_MINUTES))
    _set_autopay_next_charge_at(link_id, tg_user_id, now + timedelta(minutes=delay_min))

# -----------------------------------------------------------------------------
#  Публичные функции (бот)
# -----------------------------------------------------------------------------

def get_or_ask_email_for_user(tg_user_id: int) -> Optional[str]:
    return _get_user_email(tg_user_id)


def save_user_email(tg_user_id: int, email: str) -> None:
    _save_user_email(tg_user_id, email)


async def create_initial_payment_for_link(
    tg_user_id: int,
    link_id: int,
    email: str,
) -> str:
    """
    Создаёт платёж в ЮKassa за 1 месяц подписки.
    Включает save_payment_method=True.
    """
    _save_user_email(tg_user_id, email)
    amount_value = f"{YK_SUBSCRIPTION_PRICE_RUB:.2f}"

    def _sync_create():
        description = f"Подписка 1 мес для связки #{link_id}"
        metadata = {
            "link_id": str(link_id),
            "tg_user_id": str(tg_user_id),
            "purpose": "link_subscription_1m",
        }
        return_url = f"{YK_RETURN_URL_BASE}/yookassa/return"

        payload = {
            "amount": {
                "value": amount_value,
                "currency": "RUB",
            },
            "confirmation": {
                "type": "redirect",
                "return_url": return_url,
            },
            "capture": True,
            "description": description,
            "save_payment_method": True,
            "metadata": metadata,
            "receipt": {
                "customer": {"email": email},
                "items": [
                    {
                        "description": "Подписка на сервис",
                        "quantity": "1.00",
                        "amount": {
                            "value": amount_value,
                            "currency": "RUB",
                        },
                        "vat_code": 1,
                        "payment_mode": "full_prepayment",
                        "payment_subject": "service",
                    }
                ],
            },
        }

        idempotence_key = str(uuid.uuid4())
        payment = Payment.create(payload, idempotence_key)
        return payment

    payment = await asyncio.to_thread(_sync_create)

    if payment.status not in ("pending", "waiting_for_capture"):
        log.warning(
            "yookassa_payment_unexpected_status",
            extra={"status": payment.status, "pid": payment.id},
        )

    confirmation_url = payment.confirmation.confirmation_url

    log.info(
        "yookassa_payment_created",
        extra={
            "pid": payment.id,
            "link_id": link_id,
            "tg_user_id": tg_user_id,
            "amount": amount_value,
        },
    )

    _insert_payment_log(
        yk_payment_id=payment.id,
        link_id=link_id,
        tg_user_id=tg_user_id,
        amount=float(amount_value),
        currency="RUB",
        status=payment.status,
        paid_at=None,
        raw=json.loads(payment.json()),
    )

    return confirmation_url


def disable_autopay_for_link(link_id: int, tg_user_id: int) -> bool:
    return _disable_link_autopay(link_id, tg_user_id)

# -----------------------------------------------------------------------------
#  Webhook от ЮKassa
# -----------------------------------------------------------------------------

def handle_yookassa_webhook(payload: dict) -> None:
    event = payload.get("event") or ""
    obj = payload.get("object") or {}
    payment_id = obj.get("id")

    if not payment_id:
        log.warning("yookassa_webhook_no_payment_id", extra={"payload": payload})
        return

    try:
        payment = Payment.find_one(payment_id)
        real_obj = json.loads(payment.json())
    except Exception:
        log.exception("yookassa_webhook_payment_fetch_failed", extra={"pid": payment_id})
        return

    status = real_obj.get("status")

    # Для корректной работы автоплатежей нам важно логировать изменения статуса
    # (failed/canceled/etc), но продлевать подписку — только при succeeded.

    amount_obj = real_obj.get("amount") or {}
    amount = amount_obj.get("value")
    currency = amount_obj.get("currency", "RUB")
    metadata = real_obj.get("metadata") or {}
    pm = real_obj.get("payment_method") or {}

    paid_at_str = real_obj.get("captured_at") or real_obj.get("created_at")
    paid_at: Optional[datetime] = None
    if paid_at_str:
        try:
            paid_at = datetime.fromisoformat(paid_at_str.replace("Z", "+00:00"))
        except Exception:
            paid_at = None

    try:
        link_id = int(metadata.get("link_id"))
        tg_user_id = int(metadata.get("tg_user_id"))
    except Exception:
        log.warning(
            "yookassa_webhook_missing_metadata",
            extra={"metadata": metadata, "pid": payment_id},
        )
        return

    expected_amount = f"{YK_SUBSCRIPTION_PRICE_RUB:.2f}"
    if str(amount) != expected_amount or currency != "RUB":
        log.warning(
            "yookassa_webhook_amount_mismatch",
            extra={
                "pid": payment_id,
                "amount": amount,
                "currency": currency,
                "expected_amount": expected_amount,
                "expected_currency": "RUB",
            },
        )
        return

    owner_id, current_paid_until = _get_link_owner_and_paid_until(link_id)
    if owner_id is None:
        log.warning(
            "yookassa_webhook_unknown_link",
            extra={"pid": payment_id, "link_id": link_id},
        )
        return

    if int(owner_id) != tg_user_id:
        log.warning(
            "yookassa_webhook_owner_mismatch",
            extra={
                "pid": payment_id,
                "link_id": link_id,
                "meta_tg_user_id": tg_user_id,
                "owner_tg_user_id": owner_id,
            },
        )
        return

    existing_status = _get_yk_payment_status(payment_id)

    _insert_payment_log(
        yk_payment_id=payment_id,
        link_id=link_id,
        tg_user_id=tg_user_id,
        amount=float(amount or 0),
        currency=currency,
        status=status,
        paid_at=paid_at,
        raw=real_obj,
    )
    # Если платёж неуспешен — ничего не продлеваем.
    # Для автоплатежа запланируем повтор через backoff, чтобы профиль не "залипал".
    if status != "succeeded":
        try:
            meta_autopay = str(metadata.get("autopay") or "") == "1" or str(metadata.get("purpose") or "") == "link_subscription_autopay"
        except Exception:
            meta_autopay = False

        if meta_autopay and status in ("failed", "canceled"):
            _schedule_autopay_retry(link_id, tg_user_id)
            log.warning(
                "yookassa_webhook_autopay_not_succeeded",
                extra={"pid": payment_id, "link_id": link_id, "tg_user_id": tg_user_id, "status": status},
            )
        else:
            log.info(
                "yookassa_webhook_not_succeeded",
                extra={"pid": payment_id, "link_id": link_id, "tg_user_id": tg_user_id, "status": status},
            )
        return


    # Idempotency: YooKassa webhooks may be delivered more than once.
    # If we have already processed a succeeded payment_id, do not extend paid_until again.
    if existing_status == "succeeded":
        log.info(
            "yookassa_webhook_duplicate_succeeded_skip",
            extra={"pid": payment_id, "link_id": link_id, "tg_user_id": tg_user_id},
        )
        return

    new_paid_until = _calc_next_paid_until(current_paid_until)
    _update_link_paid_until(link_id, new_paid_until)

    # Если автоплатёж уже включен — сдвигаем next_charge_at на новую дату окончания периода.
    with contextlib.suppress(Exception):
        _set_autopay_next_charge_at(link_id, tg_user_id, new_paid_until)

    if pm.get("saved"):
        _insert_payment_method(tg_user_id, pm)
        pm_id = pm.get("id")
        if pm_id:
            _create_or_enable_link_autopay(link_id, tg_user_id, pm_id, new_paid_until)
        else:
            log.warning(
                "yookassa_webhook_saved_without_id",
                extra={"pid": payment_id},
            )

    log.info(
        "yookassa_webhook_processed",
        extra={
            "pid": payment_id,
            "event": event,
            "link_id": link_id,
            "tg_user_id": tg_user_id,
            "new_paid_until": new_paid_until.isoformat(),
        },
    )

# -----------------------------------------------------------------------------
#  Автоплатежи (воркер)
# -----------------------------------------------------------------------------

async def _run_autopay_cycle(max_count: int = AUTOPAY_BATCH_SIZE) -> int:
    if not AUTOPAY_ENABLED:
        return 0

    now = datetime.now(timezone.utc)

    def _load_due_profiles(ts_now: datetime, limit: int):
        with db() as conn, conn.cursor() as cur:
            cur.execute(
                """
                SELECT la.id,
                       la.link_id,
                       la.tg_user_id,
                       la.yk_payment_method_id,
                       la.period_months,
                       la.next_charge_at,
                       la.last_payment_id,
                       yp.status AS last_status
                  FROM link_autopay la
             LEFT JOIN yk_payments yp
                    ON yp.yk_payment_id = la.last_payment_id
                 WHERE la.enabled = TRUE
                   AND la.next_charge_at IS NOT NULL
                   AND la.next_charge_at <= %s
                   AND (
                         la.last_payment_id IS NULL
                      OR yp.status IS NULL
                      OR yp.status IN ('succeeded', 'canceled', 'failed')
                   )
              ORDER BY la.next_charge_at
                 LIMIT %s
                """,
                (ts_now, limit),
            )
            return cur.fetchall()

    rows = await asyncio.to_thread(_load_due_profiles, now, max_count)
    if not rows:
        return 0

    processed = 0
    amount_value = f"{YK_SUBSCRIPTION_PRICE_RUB:.2f}"

    for row in rows:
        la_id = row["id"]
        link_id = row["link_id"]
        tg_user_id = row["tg_user_id"]
        pm_id = row["yk_payment_method_id"]

        if not pm_id:
            log.warning(
                "autopay_skipped_no_pm_id",
                extra={"link_id": link_id, "tg_user_id": tg_user_id, "la_id": la_id},
            )
            continue

        # Email нужен для корректного чека (receipt).
        email = _get_user_email(tg_user_id)
        if not email:
            log.warning(
                "autopay_skipped_no_email",
                extra={"link_id": link_id, "tg_user_id": tg_user_id, "la_id": la_id},
            )
            continue

        def _sync_create():
            description = f"Автопродление подписки для связки #{link_id}"
            metadata = {
                "link_id": str(link_id),
                "tg_user_id": str(tg_user_id),
                "purpose": "link_subscription_autopay",
                "autopay": "1",
            }
            idempotence_key = str(uuid.uuid4())
            payload = {
                "amount": {
                    "value": amount_value,
                    "currency": "RUB",
                },
                "payment_method_id": pm_id,
                "capture": True,
                "description": description,
                "metadata": metadata,
                "receipt": {
                    "customer": {"email": email},
                    "items": [
                        {
                            "description": "Подписка на сервис",
                            "quantity": "1.00",
                            "amount": {
                                "value": amount_value,
                                "currency": "RUB",
                            },
                            "vat_code": 1,
                            "payment_mode": "full_prepayment",
                            "payment_subject": "service",
                        }
                    ],
                },
            }
            payment = Payment.create(payload, idempotence_key)
            return payment

        try:
            payment = await asyncio.to_thread(_sync_create)
        except Exception as e:
            # Отдельно обрабатываем ситуацию, когда ЮKassa сообщает,
            # что payment_method_id больше не существует или не сохранён.
            error_data = None
            if getattr(e, "args", None):
                # В yookassa BadRequestError первым аргументом приходит dict c описанием ошибки.
                first = e.args[0]
                if isinstance(first, dict):
                    error_data = first

            extra = {
                "link_id": link_id,
                "tg_user_id": tg_user_id,
                "la_id": la_id,
                "pm_id": pm_id,
                "error": error_data or repr(e),
            }

            handled_invalid_pm = False
            if isinstance(error_data, dict):
                code = error_data.get("code")
                parameter = error_data.get("parameter")
                description = (error_data.get("description") or "").lower()
                if code == "invalid_request" and parameter == "payment_method_id":
                    handled_invalid_pm = True
                    log.warning("autopay_invalid_payment_method", extra=extra)

                    # Помечаем способ оплаты неактивным и выключаем автоплатёж для связки,
                    # чтобы не получать бесконечный поток ошибок.
                    def _invalidate_pm_and_disable_autopay():
                        with db() as conn, conn.cursor() as cur:
                            cur.execute(
                                """
                                UPDATE yk_payment_methods
                                   SET active = FALSE
                                 WHERE tg_user_id = %s
                                   AND yk_payment_method_id = %s
                                """,
                                (tg_user_id, pm_id),
                            )
                            cur.execute(
                                """
                                UPDATE link_autopay
                                   SET enabled = FALSE,
                                       canceled_at = NOW()
                                 WHERE id = %s
                                """,
                                (la_id,),
                            )
                            conn.commit()

                    try:
                        # Запускаем БД-операции в отдельном потоке, чтобы не блокировать event lo
                        await asyncio.to_thread(_invalidate_pm_and_disable_autopay)
                    except Exception:
                        log.exception(
                            "autopay_invalid_pm_cleanup_failed",
                            extra={
                                "link_id": link_id,
                                "tg_user_id": tg_user_id,
                                "la_id": la_id,
                                "pm_id": pm_id,
                            },
                        )

            if not handled_invalid_pm:
                # Любые прочие ошибки логируем как раньше.
                log.exception("autopay_payment_create_failed", extra=extra)

            continue

        def _postprocess_payment():
            _insert_payment_log(
                yk_payment_id=payment.id,
                link_id=link_id,
                tg_user_id=tg_user_id,
                amount=float(amount_value),
                currency="RUB",
                status=payment.status,
                paid_at=None,
                raw=json.loads(payment.json()),
            )
            with db() as conn, conn.cursor() as cur:
                cur.execute(
                    """
                    UPDATE link_autopay
                       SET last_payment_id = %s
                     WHERE id = %s
                    """,
                    (payment.id, la_id),
                )

        try:
            await asyncio.to_thread(_postprocess_payment)
            processed += 1
            log.info(
                "autopay_payment_created",
                extra={
                    "pid": payment.id,
                    "link_id": link_id,
                    "tg_user_id": tg_user_id,
                    "la_id": la_id,
                    "status": payment.status,
                },
            )
        except Exception:
            log.exception(
                "autopay_payment_postprocess_failed",
                extra={"pid": getattr(payment, "id", None)},
            )

    return processed


async def _autopay_worker() -> None:
    log.info(
        "autopay_worker_started",
        extra={
            "interval_sec": AUTOPAY_INTERVAL_SEC,
            "batch_size": AUTOPAY_BATCH_SIZE,
            "enabled": AUTOPAY_ENABLED,
        },
    )
    try:
        while AUTOPAY_ENABLED:
            try:
                count = await _run_autopay_cycle()
                if count:
                    log.info("autopay_cycle_done", extra={"count": count})
            except Exception:
                log.exception("autopay_cycle_failed")
            await asyncio.sleep(AUTOPAY_INTERVAL_SEC)
    except asyncio.CancelledError:
        log.info("autopay_worker_cancelled")
        raise


def start_autopay_task() -> Optional[asyncio.Task]:
    if not AUTOPAY_ENABLED:
        log.info("autopay_disabled_by_env")
        return None
    loop = asyncio.get_running_loop()
    return loop.create_task(_autopay_worker(), name="yk_autopay_worker")

