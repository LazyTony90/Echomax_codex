import os
import re
import asyncio
import mimetypes
import time
import contextlib
from pathlib import Path
from typing import Awaitable, Callable, Tuple, Optional
import logging

log = logging.getLogger(__name__)

# ----- ПАРАМЕТРЫ КОНКУРЕНТНОСТИ И ПУТИ -----
CACHE_DIR = os.getenv("MEDIA_CACHE_DIR", "/app/cache")
Path(CACHE_DIR).mkdir(parents=True, exist_ok=True)

# ограничиваем одновременные скачивания из TG
_DL_CONCURRENCY = int(os.getenv("TG_DOWNLOAD_CONCURRENCY", "4"))

# верхний лимит размера одного объекта в кэше:
# - если задан TG_BIGFILE_MAX_MB, используем его (в байтах)
# - иначе используем MEDIA_MAX_BYTES или 64 МБ
_big_mb = os.getenv("TG_BIGFILE_MAX_MB", "").strip()
if _big_mb.isdigit() and int(_big_mb) > 0:
    _MAX_BYTES = int(_big_mb) * 1024 * 1024
else:
    _MAX_BYTES = int(os.getenv("MEDIA_MAX_BYTES", str(64 * 1024 * 1024)))

# TTL локального кэша (сек). По умолчанию = S3_PRESIGN_TTL или 14400 (≈4ч).
_CACHE_TTL = int(os.getenv("MEDIA_CACHE_TTL_SECONDS", os.getenv("S3_PRESIGN_TTL", "14400")))
_CLEAN_INTERVAL = int(os.getenv("MEDIA_CACHE_CLEAN_INTERVAL", "900"))  # каждые 15 мин

# ----- S3 (опционально) -----
_S3_ENABLED = all([
    os.getenv("S3_ENDPOINT_URL"),
    os.getenv("S3_BUCKET"),
    os.getenv("S3_ACCESS_KEY_ID"),
    os.getenv("S3_SECRET_ACCESS_KEY"),
])
_S3_ENDPOINT = os.getenv("S3_ENDPOINT_URL", "")
_S3_BUCKET = os.getenv("S3_BUCKET", "")
_S3_REGION = os.getenv("S3_REGION")
_S3_PATH_STYLE = os.getenv("S3_PATH_STYLE", "1").lower() not in ("0", "false", "no")

_s3_client = None


def _get_s3():
    """Ленивая инициализация клиента S3 (boto3)."""
    global _s3_client
    if not _S3_ENABLED:
        return None
    if _s3_client is not None:
        return _s3_client
    import boto3
    try:
        from botocore.config import Config as BotoConfig
        s3cfg = BotoConfig(s3={"addressing_style": "path" if _S3_PATH_STYLE else "virtual"})
    except Exception:
        s3cfg = None

    session = boto3.session.Session()
    _s3_client = session.client(
        "s3",
        endpoint_url=_S3_ENDPOINT,
        aws_access_key_id=os.getenv("S3_ACCESS_KEY_ID"),
        aws_secret_access_key=os.getenv("S3_SECRET_ACCESS_KEY"),
        region_name=_S3_REGION,
        config=s3cfg,
    )
    return _s3_client


def _safe_filename(name: Optional[str], fallback: str) -> str:
    n = (name or fallback or "file.bin")
    n = Path(n).name
    n = re.sub(r"[^\w.\-()+@ ]+", "_", n)
    return n or fallback


def _s3_key_for(file_id: str, filename: str) -> str:
    safe_name = _safe_filename(filename, file_id + ".bin")
    return f"tg-cache/{file_id}/{safe_name}"


async def _atomic_write_bytes(path: Path, data: bytes) -> None:
    tmp = path.with_suffix(path.suffix + ".part")
    await asyncio.to_thread(tmp.write_bytes, data)
    await asyncio.to_thread(tmp.replace, path)


class MediaCache:
    """
    Кэш Telegram-файлов:
      - дедуп скачиваний (in-flight coalescing)
      - ограничение параллелизма
      - локальный диск (атомарная запись)
      - опционально S3 (аккуратная работа с Body/ContentLength)
      - опциональная фоновая чистка старых файлов
    """
    def __init__(self):
        self._sem = asyncio.Semaphore(max(1, _DL_CONCURRENCY))
        self._inflight: dict[str, asyncio.Future] = {}
        self._cleaner_task: Optional[asyncio.Task] = None

    async def get_or_fetch(
        self,
        file_id: str,
        filename_hint: str,
        fetcher: Callable[[], Awaitable[Tuple[bytes, str]]],
        mime_hint: Optional[str] = None,
    ) -> Tuple[bytes, str]:
        """
        Возвращает (data, filename). Последовательно:
        1) локальный диск, 2) S3 (если настроен), 3) скачать через fetcher и сохранить (диск + S3).
        Объединяет параллельные запросы к одному file_id.
        """
        fut = self._inflight.get(file_id)
        if fut:
            return await fut

        loop = asyncio.get_running_loop()
        loop_fut: asyncio.Future = loop.create_future()
        self._inflight[file_id] = loop_fut
        try:
            # 1) локальный диск
            data, name = await self._try_disk(file_id, filename_hint)
            if data is not None:
                loop_fut.set_result((data, name))
                return data, name

            # 2) S3 (если настроен)
            if _S3_ENABLED:
                data, name = await self._try_s3(file_id, filename_hint)
                if data is not None:
                    await self._save_to_disk(file_id, name, data)
                    loop_fut.set_result((data, name))
                    return data, name

            # 3) скачать из Telegram c ограничением
            async with self._sem:
                data, real_name = await fetcher()

            if len(data) > _MAX_BYTES:
                raise ValueError(f"Media too large: {len(data)} > limit={_MAX_BYTES}")

            # 4) сохранить в кэш (диск + опционально S3)
            await self._save_to_disk(file_id, real_name, data)
            if _S3_ENABLED:
                await self._save_to_s3(file_id, real_name, data, mime_hint)

            loop_fut.set_result((data, real_name))
            return data, real_name

        except Exception as e:
            if not loop_fut.done():
                loop_fut.set_exception(e)
            raise
        finally:
            self._inflight.pop(file_id, None)

    # ---------- disk ----------
    async def _try_disk(self, file_id: str, filename_hint: str) -> Tuple[Optional[bytes], str]:
        bin_path = Path(CACHE_DIR) / f"{file_id}.bin"
        name_path = Path(CACHE_DIR) / f"{file_id}.name"
        if bin_path.exists():
            data = await asyncio.to_thread(bin_path.read_bytes)
            name = filename_hint
            if name_path.exists():
                try:
                    with_name = await asyncio.to_thread(name_path.read_text)
                    with_name = with_name.strip()
                    if with_name:
                        name = with_name
                except Exception:
                    pass
            return data, name
        return None, filename_hint

    async def _save_to_disk(self, file_id: str, filename: str, data: bytes) -> None:
        if len(data) > _MAX_BYTES:
            raise ValueError(f"Media too large: {len(data)} > limit={_MAX_BYTES}")
        bin_path = Path(CACHE_DIR) / f"{file_id}.bin"
        name_path = Path(CACHE_DIR) / f"{file_id}.name"
        await _atomic_write_bytes(bin_path, data)
        await asyncio.to_thread(name_path.write_text, _safe_filename(filename, file_id + ".bin"))

    # ---------- s3 ----------
    async def _try_s3(self, file_id: str, filename_hint: str) -> Tuple[Optional[bytes], str]:
        cli = _get_s3()
        if cli is None:
            return None, filename_hint

        keys = [
            _s3_key_for(file_id, filename_hint),
            f"tg-cache/{file_id}/{file_id}.bin",
        ]
        for key in keys:
            try:
                resp = await asyncio.to_thread(cli.get_object, Bucket=_S3_BUCKET, Key=key)
            except Exception:
                continue
            try:
                cl = resp.get("ContentLength")
                if isinstance(cl, int) and cl > _MAX_BYTES:
                    log.warning("S3 object too large: key=%s size=%s limit=%s", key, cl, _MAX_BYTES)
                    return None, filename_hint
                body = resp["Body"]
                data = body.read()
                body.close()
                name = Path(key).name
                return data, name
            except Exception as e:
                log.exception("S3 read failed for key=%s: %s", key, e)
                continue
        return None, filename_hint

    async def _save_to_s3(self, file_id: str, filename: str, data: bytes, mime_hint: Optional[str]) -> None:
        cli = _get_s3()
        if cli is None:
            return
        key = _s3_key_for(file_id, filename)
        content_type = mime_hint or (mimetypes.guess_type(filename or "")[0] or "application/octet-stream")
        await asyncio.to_thread(
            cli.put_object,
            Bucket=_S3_BUCKET,
            Key=key,
            Body=data,
            ContentType=content_type,
        )

    # ---------- periodic cleanup ----------
    async def _clean_once(self, ttl_sec: int) -> None:
        if ttl_sec <= 0:
            return
        now = time.time()
        removed = 0
        for bin_path in Path(CACHE_DIR).glob("*.bin"):
            try:
                st = bin_path.stat()
                if (now - st.st_mtime) > ttl_sec:
                    name_path = bin_path.with_suffix(".name")
                    await asyncio.to_thread(bin_path.unlink)
                    if name_path.exists():
                        with contextlib.suppress(Exception):
                            await asyncio.to_thread(name_path.unlink)
                    removed += 1
            except Exception:
                pass
        if removed:
            log.info("media_cache: cleanup removed %d old files", removed)

    async def _clean_loop(self, ttl_sec: int, interval_sec: int):
        try:
            while True:
                await self._clean_once(ttl_sec)
                await asyncio.sleep(max(60, interval_sec))
        except asyncio.CancelledError:
            pass
        except Exception as e:
            log.warning("media_cache: cleaner loop stopped: %s", e)

    def start_cleaner_task(self) -> Optional[asyncio.Task]:
        """Запускает фоновую чистку; возвращает task или None, если TTL отключён."""
        if _CACHE_TTL <= 0:
            return None
        try:
            loop = asyncio.get_running_loop()
            self._cleaner_task = loop.create_task(self._clean_loop(_CACHE_TTL, _CLEAN_INTERVAL))
            return self._cleaner_task
        except RuntimeError:
            return None

    async def stop_cleaner_task(self):
        """Останавливает фоновую чистку (если запущена)."""
        t = self._cleaner_task
        if t and not t.done():
            t.cancel()
            with contextlib.suppress(Exception):
                await t


