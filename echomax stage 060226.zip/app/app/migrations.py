# app/app/migrations.py
"""Database schema bootstrap / migrations.

Вся актуальная схема БД собрана здесь в одном месте.
Функция `apply_migrations()` идемпотентна: её можно безопасно вызывать
при каждом старте приложения.

Важно:
- НЕ добавляй SQL в main.py, всё, что относится к структуре таблиц —
  только здесь.
- Все изменения сделаны через CREATE IF NOT EXISTS / ALTER .. IF NOT EXISTS,
  поэтому они безопасны как для пустой БД, так и для уже рабочей.
"""

import logging
from typing import Any

log = logging.getLogger(__name__)

_MIGRATIONS_SQL = """
-- Core users table
CREATE TABLE IF NOT EXISTS users(
    id bigserial PRIMARY KEY,
    tg_user_id bigint NOT NULL UNIQUE,
    created_at timestamptz DEFAULT now(),
    trial_granted boolean NOT NULL DEFAULT false
);

-- Channel links (TG<->TG, TG<->MAX, chats/channels)
CREATE TABLE IF NOT EXISTS channel_links(
    id bigserial PRIMARY KEY,
    owner_tg_user_id bigint NOT NULL,
    source_chat_id bigint NOT NULL,
    target_chat_id bigint NOT NULL,
    enabled boolean NOT NULL DEFAULT true,
    paid_until timestamptz,
    name text,
    trial_until timestamptz,
    is_trial boolean NOT NULL DEFAULT false,
    target_platform text NOT NULL DEFAULT 'tg',
    link_type text NOT NULL DEFAULT 'channel'
);

ALTER TABLE channel_links
    ADD COLUMN IF NOT EXISTS auto_paused boolean NOT NULL DEFAULT false;

-- Upgrade from very old schemas (fields that might be missing)
ALTER TABLE channel_links
    ADD COLUMN IF NOT EXISTS name text,
    ADD COLUMN IF NOT EXISTS trial_until timestamptz,
    ADD COLUMN IF NOT EXISTS is_trial boolean NOT NULL DEFAULT false,
    ADD COLUMN IF NOT EXISTS target_platform text NOT NULL DEFAULT 'tg',
    ADD COLUMN IF NOT EXISTS link_type text NOT NULL DEFAULT 'channel';

CREATE UNIQUE INDEX IF NOT EXISTS ux_link_owner_src_tgt
    ON channel_links(owner_tg_user_id, source_chat_id, target_chat_id);
CREATE INDEX IF NOT EXISTS idx_links_source
    ON channel_links(source_chat_id);
CREATE INDEX IF NOT EXISTS idx_links_type_source
    ON channel_links(link_type, source_chat_id);
CREATE INDEX IF NOT EXISTS idx_links_owner_order
    ON channel_links(owner_tg_user_id, id);
CREATE INDEX IF NOT EXISTS idx_links_target
    ON channel_links(target_chat_id);
CREATE INDEX IF NOT EXISTS idx_links_src_enabled_order
    ON channel_links(source_chat_id, id) WHERE enabled;
CREATE INDEX IF NOT EXISTS channel_links_platform_target_idx
    ON channel_links(target_platform, target_chat_id);

-- Exclusions per link
CREATE TABLE IF NOT EXISTS link_exclusions(
    id bigserial PRIMARY KEY,
    link_id bigint NOT NULL REFERENCES channel_links(id) ON DELETE CASCADE,
    token text NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS link_exclusions_link_id_token_key
    ON link_exclusions(link_id, token);
CREATE INDEX IF NOT EXISTS idx_excl_link
    ON link_exclusions(link_id);
CREATE INDEX IF NOT EXISTS link_exclusions_link_id_idx
    ON link_exclusions(link_id);

-- Rules per link
CREATE TABLE IF NOT EXISTS rules(
    id bigserial PRIMARY KEY,
    link_id bigint NOT NULL REFERENCES channel_links(id) ON DELETE CASCADE,
    idx int NOT NULL,
    type text NOT NULL,
    data jsonb NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_rules_link_idx
    ON rules(link_id, idx);
CREATE UNIQUE INDEX IF NOT EXISTS rules_link_id_idx_key
    ON rules(link_id, idx);
CREATE INDEX IF NOT EXISTS rules_link_idx
    ON rules(link_id, idx);

-- Messages map (TG channel post edits)
CREATE TABLE IF NOT EXISTS messages_map(
    id bigserial PRIMARY KEY,
    link_id bigint NOT NULL REFERENCES channel_links(id) ON DELETE CASCADE,
    source_msg_id bigint NOT NULL,
    target_msg_id bigint NOT NULL,
    media_group_id text
);
CREATE UNIQUE INDEX IF NOT EXISTS messages_map_link_id_source_msg_id_key
    ON messages_map(link_id, source_msg_id);
CREATE UNIQUE INDEX IF NOT EXISTS messages_map_link_id_target_msg_id_key
    ON messages_map(link_id, target_msg_id);
CREATE INDEX IF NOT EXISTS idx_map_link
    ON messages_map(link_id, source_msg_id);
CREATE INDEX IF NOT EXISTS idx_map_link_target
    ON messages_map(link_id, target_msg_id);

-- Payments journal (старый журнал, может использоваться как история пополнений)
CREATE TABLE IF NOT EXISTS payments(
    id bigserial PRIMARY KEY,
    owner_tg_user_id bigint NOT NULL,
    link_id bigint NOT NULL REFERENCES channel_links(id) ON DELETE CASCADE,
    amount bigint NOT NULL,
    currency text NOT NULL,
    provider_payload jsonb,
    paid_at timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_pay_user
    ON payments(owner_tg_user_id, link_id, paid_at);
CREATE INDEX IF NOT EXISTS idx_pay_link
    ON payments(link_id, paid_at);

-- YooKassa: сохранённые способы оплаты, автоплатежи, лог платежей

-- users.email для фискализации/уведомлений
ALTER TABLE users
    ADD COLUMN IF NOT EXISTS email text;

-- Сохранённые способы оплаты ЮKassa (payment_method.id и метаданные)
CREATE TABLE IF NOT EXISTS yk_payment_methods(
    id bigserial PRIMARY KEY,
    tg_user_id bigint NOT NULL,
    yk_payment_method_id text NOT NULL, -- payment_method.id из ЮKassa
    type text,
    last4 text,
    card_brand text,
    created_at timestamptz NOT NULL DEFAULT now(),
    active boolean NOT NULL DEFAULT true
);

CREATE INDEX IF NOT EXISTS idx_yk_pm_user
    ON yk_payment_methods(tg_user_id);

CREATE UNIQUE INDEX IF NOT EXISTS uidx_yk_pm_user_method
    ON yk_payment_methods(tg_user_id, yk_payment_method_id);

-- Профиль автоплатежа по связке
CREATE TABLE IF NOT EXISTS link_autopay(
    id bigserial PRIMARY KEY,
    link_id bigint NOT NULL REFERENCES channel_links(id) ON DELETE CASCADE,
    tg_user_id bigint NOT NULL,
    yk_payment_method_id text NOT NULL, -- ссылка на yk_payment_methods.yk_payment_method_id
    period_months integer NOT NULL DEFAULT 1,
    enabled boolean NOT NULL DEFAULT true,
    next_charge_at timestamptz,
    last_payment_id text,              -- yookassa payment.id последнего успешного списания
    created_at timestamptz NOT NULL DEFAULT now(),
    canceled_at timestamptz
);

CREATE INDEX IF NOT EXISTS idx_link_autopay_link
    ON link_autopay(link_id);

CREATE INDEX IF NOT EXISTS idx_link_autopay_user
    ON link_autopay(tg_user_id);

-- Лог платежей YooKassa
CREATE TABLE IF NOT EXISTS yk_payments(
    id bigserial PRIMARY KEY,
    yk_payment_id text NOT NULL,        -- payment.id в ЮKassa
    link_id bigint NOT NULL REFERENCES channel_links(id) ON DELETE CASCADE,
    tg_user_id bigint NOT NULL,
    amount numeric(12,2) NOT NULL,
    currency text NOT NULL DEFAULT 'RUB',
    status text NOT NULL,               -- pending, waiting_for_capture, succeeded, canceled ...
    created_at timestamptz NOT NULL DEFAULT now(),
    paid_at timestamptz,
    raw_payload jsonb
);

CREATE UNIQUE INDEX IF NOT EXISTS uidx_yk_payments_payment_id
    ON yk_payments(yk_payment_id);

-- Deduplicated media storage
CREATE TABLE IF NOT EXISTS media_dedup(
    id bigserial PRIMARY KEY,
    tg_unique_id text,
    sha256 text NOT NULL,
    size_bytes bigint NOT NULL,
    s3_key text NOT NULL,
    max_type text NOT NULL,
    max_token text,
    max_payload jsonb,
    created_at timestamptz DEFAULT now(),
    last_used_at timestamptz DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_media_sha256_type
    ON media_dedup(sha256, max_type);
CREATE INDEX IF NOT EXISTS ix_media_tg_unique
    ON media_dedup(tg_unique_id);
CREATE INDEX IF NOT EXISTS ix_media_last_used
    ON media_dedup(last_used_at);

-- MAX inbox cursors
CREATE TABLE IF NOT EXISTS max_inbox_cursors(
    link_id bigint PRIMARY KEY REFERENCES channel_links(id) ON DELETE CASCADE,
    last_seq bigint,
    last_ts bigint,
    last_mid text,
    updated_at timestamptz DEFAULT now()
);

-- Cross-platform message map (TG <-> MAX, chats)
CREATE TABLE IF NOT EXISTS cross_message_map(
    id bigserial PRIMARY KEY,
    link_id bigint NOT NULL REFERENCES channel_links(id) ON DELETE CASCADE,
    src_platform text NOT NULL,
    src_msg_id text NOT NULL,
    dst_platform text NOT NULL,
    dst_msg_id text NOT NULL,
    created_at timestamptz DEFAULT now(),
    tg_msg_id bigint,
    max_mid text
);
-- Upgrade from very old schema where only tg_msg_id/max_mid existed
ALTER TABLE cross_message_map
    ADD COLUMN IF NOT EXISTS src_platform text,
    ADD COLUMN IF NOT EXISTS src_msg_id text,
    ADD COLUMN IF NOT EXISTS dst_platform text,
    ADD COLUMN IF NOT EXISTS dst_msg_id text,
    ADD COLUMN IF NOT EXISTS created_at timestamptz DEFAULT now(),
    ADD COLUMN IF NOT EXISTS tg_msg_id bigint,
    ADD COLUMN IF NOT EXISTS max_mid text;

CREATE UNIQUE INDEX IF NOT EXISTS cross_message_map_link_id_src_platform_src_msg_id_key
    ON cross_message_map(link_id, src_platform, src_msg_id);
CREATE UNIQUE INDEX IF NOT EXISTS cross_message_map_link_id_max_mid_key
    ON cross_message_map(link_id, max_mid);
CREATE UNIQUE INDEX IF NOT EXISTS cross_message_map_link_id_tg_msg_id_key
    ON cross_message_map(link_id, tg_msg_id);
CREATE INDEX IF NOT EXISTS ix_cross_map_link_tg
    ON cross_message_map(link_id, tg_msg_id);
CREATE INDEX IF NOT EXISTS ix_cross_map_link_max
    ON cross_message_map(link_id, max_mid);
CREATE INDEX IF NOT EXISTS ix_cross_dst
    ON cross_message_map(link_id, dst_platform, dst_msg_id);

-- Known chats cache
CREATE TABLE IF NOT EXISTS known_chats(
    chat_id bigint PRIMARY KEY,
    type text,
    title text,
    username text,
    is_member boolean NOT NULL DEFAULT true,
    last_seen timestamptz DEFAULT now()
);

-- Pending chat links (TG<->MAX chats binding by code)
CREATE TABLE IF NOT EXISTS pending_chat_links(
    code text PRIMARY KEY,
    owner_tg_user_id bigint NOT NULL,
    created_at timestamptz DEFAULT now(),
    source_chat_id bigint
);
CREATE INDEX IF NOT EXISTS ix_pcl_owner
    ON pending_chat_links(owner_tg_user_id);

-- Users extra fields for old schemas
ALTER TABLE users
    ADD COLUMN IF NOT EXISTS trial_granted boolean NOT NULL DEFAULT false,
    ADD COLUMN IF NOT EXISTS email text;

-- История использования бесплатного триала для связок
CREATE TABLE IF NOT EXISTS link_trials (
    id                  bigserial PRIMARY KEY,
    owner_tg_user_id    bigint       NOT NULL,
    source_chat_id      bigint       NOT NULL,
    target_chat_id      bigint       NOT NULL,
    target_platform     text         NOT NULL DEFAULT 'tg',
    link_type           text         NOT NULL DEFAULT 'channel',
    first_trial_started_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_link_trials_key
    ON link_trials(owner_tg_user_id, source_chat_id, target_chat_id, target_platform, link_type);

-- Бэкапируем уже выданные триалы (для существующих связок)
INSERT INTO link_trials(
    owner_tg_user_id, source_chat_id, target_chat_id, target_platform, link_type, first_trial_started_at
)
SELECT
    owner_tg_user_id,
    source_chat_id,
    target_chat_id,
    target_platform,
    link_type,
    now()
FROM channel_links
WHERE is_trial = true
  AND source_chat_id IS NOT NULL
  AND target_chat_id IS NOT NULL
ON CONFLICT (owner_tg_user_id, source_chat_id, target_chat_id, target_platform, link_type) DO NOTHING;


-- Legacy table from very old versions, no longer used
DROP TABLE IF EXISTS links CASCADE;
DROP SEQUENCE IF EXISTS links_id_seq;
"""


def apply_migrations(cur: Any) -> None:
    """Применить миграции.

    cur — курсор psycopg2 (dict cursor), как в остальных частях проекта.
    """
    cur.execute(_MIGRATIONS_SQL)
    log.info("DB migrations applied")

