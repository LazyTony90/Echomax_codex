import os

class Cfg:
    BOT_TOKEN = os.getenv("BOT_TOKEN")
    PUBLIC_BASE_URL = os.getenv("PUBLIC_BASE_URL")
    WEBHOOK_SECRET = os.getenv("WEBHOOK_SECRET","")
    APP_PORT = int(os.getenv("APP_PORT","8080"))

    PG = {
        "host": os.getenv("POSTGRES_HOST", "postgres"),
        "db": os.getenv("POSTGRES_DB"),
        "user": os.getenv("POSTGRES_USER"),
        "password": os.getenv("POSTGRES_PASSWORD"),
        "port": int(os.getenv("POSTGRES_PORT","5432")),
    }

    PAYMENT_MODE = os.getenv("PAYMENT_MODE","INVOICE")
    PROVIDER_TOKEN = os.getenv("PROVIDER_TOKEN","")

    # Основной источник — S3_*; AWS_* берём только как fallback.
    S3 = {
        "endpoint": os.getenv("S3_ENDPOINT_URL") or os.getenv("AWS_ENDPOINT_URL"),
        "access": os.getenv("S3_ACCESS_KEY_ID") or os.getenv("AWS_ACCESS_KEY_ID"),
        "secret": os.getenv("S3_SECRET_ACCESS_KEY") or os.getenv("AWS_SECRET_ACCESS_KEY"),
        "region": os.getenv("S3_REGION") or os.getenv("AWS_DEFAULT_REGION","eu-west-1"),
        "bucket": os.getenv("S3_BUCKET","media"),
        "tenant": os.getenv("S3_TENANT_ID","tenant-xxx"),
        "path_style": (os.getenv("S3_PATH_STYLE","1").lower() not in ("0","false","no")),
        "presign_ttl": int(os.getenv("S3_PRESIGN_TTL", "13800")),  # ~3h50m под ваш lifecycle 4ч
    }

    LIMITS = {
        "max_rules_per_link": int(os.getenv("MAX_RULES_PER_LINK","7")),
        "max_exclusions_per_link": int(os.getenv("MAX_EXCLUSIONS_PER_LINK","2")),
    }

    # Пробный период в днях (используется в menu.py)
    TRIAL_DAYS = int(os.getenv("TRIAL_DAYS","2"))

