#app/app/main.py
import os
import logging
import re
import json
import io
import tempfile
import shutil
import subprocess
import contextlib
import aiohttp
import asyncio
import html
import time
import ipaddress
from pathlib import Path
from typing import Tuple, List, Any, Optional, Dict, Set
from datetime import datetime, timezone

from aiohttp import web
from aiogram import Bot, Dispatcher, F
from aiogram.enums import ParseMode, ChatType
from aiogram.client.default import DefaultBotProperties
from aiogram.types import Update, Message
from aiogram.types import LinkPreviewOptions
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.exceptions import TelegramBadRequest

from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.client.telegram import TelegramAPIServer

from app import dedup_store
from app.db import db, aquery
from app.link_router_cache import (
    get_links_for_source as cached_get_links_for_source,
    invalidate_source_links,
)
from app.menu import router as menu_router, kb_link_menu
from app.admin import router as admin_router, ADMIN_IDS
from app.payments_yookassa import handle_yookassa_webhook, start_autopay_task
from app.expiry_notifier import expiry_notifier_worker
from app.config import Cfg
from app.alerts import (
    set_bot as alerts_set_bot,
    set_recipients as alerts_set_recipients,
    notify_admin_throttled,
)
from app.max_send import (
    send_text_to_chat as max_send_text,
    send_message as max_send_message,
    upload_image_bytes,
    upload_file_bytes,
    upload_audio_bytes,
    upload_video_bytes,
    upload_image_path,
    upload_file_path,
    upload_audio_path,
    upload_video_path,
    MaxSendError,
    get_tg_http_session,
    get_max_http_session,
    close_http_sessions,
)
from app.media_cache import MediaCache
from app.link_cache import (
    aget_exclusions_for_link,
    aget_rules_for_link,
)
from app.message_map import save_tg_to_max

try:
    from app.max_inbox import start as start_max_inbox
except Exception:
    start_max_inbox = None

LOG_LEVEL = os.getenv("LOG_LEVEL", "DEBUG").upper()
logging.basicConfig(level=LOG_LEVEL)
log = logging.getLogger(__name__)
logging.getLogger("botocore").setLevel(os.getenv("BOTO_LOG_LEVEL", "WARNING"))
logging.getLogger("boto3").setLevel(os.getenv("BOTO_LOG_LEVEL", "WARNING"))
logging.getLogger("urllib3").setLevel(os.getenv("BOTO_LOG_LEVEL", "WARNING"))

USE_CLOUD_WEBHOOK = os.getenv("TG_USE_CLOUD_WEBHOOK", "1").lower() not in ("0", "false", "no", "off")

BOT_TOKEN = Cfg.BOT_TOKEN

# --- основной бот (как и раньше) ---
bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))

# --- локальный Bot API (используем ТОЛЬКО если явно задан TG_LOCAL_BOT_API_URL) ---
_TG_LOCAL_BASE = (os.getenv("TG_LOCAL_BOT_API_URL") or "").strip()
_TG_USE_LOCAL_FOR_DOWNLOAD = bool(_TG_LOCAL_BASE)

bot_local: Optional[Bot] = None
if _TG_USE_LOCAL_FOR_DOWNLOAD:
    try:
        api = TelegramAPIServer.from_base(_TG_LOCAL_BASE, is_local=True)
        session = AiohttpSession(api=api)
        bot_local = Bot(
            token=BOT_TOKEN,
            session=session,
            default=DefaultBotProperties(parse_mode=ParseMode.HTML),
        )
        log.info("Local Telegram Bot API enabled for downloads: %s", _TG_LOCAL_BASE)
    except Exception as e:
        bot_local = None
        _TG_USE_LOCAL_FOR_DOWNLOAD = False
        log.warning("Failed to init local Telegram Bot API client, fallback to cloud: %s", e)


async def _tg_get_file_resilient(file_id: str):
    """
    Попробовать получить File из Telegram:
    1) сначала через облачный Bot API (bot),
    2) потом через локальный Bot API (bot_local), если он сконфигурирован.

    Любые TelegramBadRequest (в т.ч. invalid file_id) логируем и пробуем следующий backend,
    чтобы локальный сервер не ломал работу, если он не умеет разбирать конкретный file_id.
    """
    last_exc: Optional[Exception] = None

    for client, name in ((bot, "cloud"), (bot_local, "local")):
        if client is None:
            continue
        try:
            return await client.get_file(file_id)
        except TelegramBadRequest as e:
            msg = str(e)
            log.warning(
                "tg_get_file_resilient: get_file via %s failed for %s: %s",
                name,
                file_id,
                msg,
            )
            last_exc = e
            # пробуем следующий backend
            continue

    if last_exc:
        raise last_exc
    raise RuntimeError("No Telegram client available for get_file()")


dp = Dispatcher()
dp.include_router(menu_router)
dp.include_router(admin_router)

MC = MediaCache()
# --- image repair for MAX ---
async def _ffmpeg_reencode_to_jpeg(data: bytes) -> bytes:
    ff = shutil.which("ffmpeg")
    if not ff:
        raise RuntimeError("ffmpeg not found for image reencode")
    with tempfile.TemporaryDirectory() as td:
        inp = os.path.join(td, "in.bin")
        outp = os.path.join(td, "out.jpg")
        with open(inp, "wb") as f:
            f.write(data)

        # максимально совместимый JPEG
        proc = await asyncio.create_subprocess_exec(
            ff, "-y",
            "-i", inp,
            "-vf", "format=yuvj420p",
            "-q:v", "4",
            outp,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.PIPE,
        )
        _, err = await proc.communicate()
        if proc.returncode != 0 or not os.path.exists(outp):
            raise RuntimeError(f"ffmpeg reencode failed: {err[:400].decode(errors='replace')}")
        with open(outp, "rb") as f:
            return f.read()

async def _reencode_image_bytes_to_jpeg(data: bytes) -> bytes:
    # Сначала пробуем Pillow (если установлен), иначе ffmpeg.
    try:
        from PIL import Image  # type: ignore
        img = Image.open(io.BytesIO(data))
        img = img.convert("RGB")
        out = io.BytesIO()
        img.save(out, format="JPEG", quality=85, optimize=True)
        return out.getvalue()
    except Exception:
        return await _ffmpeg_reencode_to_jpeg(data)

async def _reupload_tg_image_as_jpeg(tg_file_id: str, filename_hint: str = "photo.jpg") -> Dict[str, Any]:
    data, filename = await MC.get_or_fetch(
        tg_file_id,
        filename_hint=filename_hint,
        fetcher=lambda: _raw_download_tg_file(tg_file_id),
        mime_hint="image/jpeg",
    )
    jpeg = await _reencode_image_bytes_to_jpeg(data)
    payload = await upload_image_bytes(jpeg, filename_hint or filename or "photo.jpg", mime_hint="image/jpeg")
    return payload

# --- большие файлы (обход лимита 20MB для ботов) ---
# Если файл большой, мы НЕ читаем его в RAM: либо берём локальный путь от tg-bot-api (--local),
# либо скачиваем потоково на диск в TG_BIGFILE_DIR, и потом стримим в MAX.
_BIG_THRESHOLD_MB = int(os.getenv("TG_BIGFILE_THRESHOLD_MB", "20"))
TG_BIGFILE_DIR = os.getenv("TG_BIGFILE_DIR", "/app/cache/tg-big")
Path(TG_BIGFILE_DIR).mkdir(parents=True, exist_ok=True)

_BIG_INFLIGHT: Dict[str, asyncio.Future] = {}
_BIG_SEM = asyncio.Semaphore(max(1, int(os.getenv("TG_DOWNLOAD_CONCURRENCY", "4"))))

_TG_BIG_DIR = (os.getenv("TG_BIGFILE_DIR") or "").strip()
_TG_BIG_TTL_HOURS = float(os.getenv("TG_BIGFILE_TTL_HOURS", "7"))
_TG_BIG_CLEAN_INTERVAL_MIN = float(os.getenv("TG_BIGFILE_CLEAN_INTERVAL_MIN", "20"))
_TG_BIG_CLEAN_GRACE_MIN = float(os.getenv("TG_BIGFILE_CLEAN_GRACE_MIN", "10"))


async def _cleanup_tg_big_dir_once() -> int:
    """
    Удаляет файлы в TG_BIGFILE_DIR старше TTL (с небольшим grace),
    возвращает количество удалённых файлов.
    """
    if not _TG_BIG_DIR:
        return 0
    p = Path(_TG_BIG_DIR)
    if not p.exists() or not p.is_dir():
        return 0

    now = time.time()
    ttl_sec = _TG_BIG_TTL_HOURS * 3600.0
    grace_sec = _TG_BIG_CLEAN_GRACE_MIN * 60.0
    cutoff = now - ttl_sec

    deleted = 0
    for f in p.iterdir():
        try:
            if not f.is_file():
                continue
            st = f.stat()
            # Если файл слишком "свежий" — пропускаем
            if st.st_mtime > (cutoff + grace_sec):
                continue
            f.unlink(missing_ok=True)
            deleted += 1
        except Exception:
            # не падаем из-за одного файла
            continue
    return deleted


def start_tg_big_cleaner_task() -> asyncio.Task | None:
    if not _TG_BIG_DIR:
        return None

    async def _worker():
        # небольшой стартовый сон — чтобы не мешать прогреву
        await asyncio.sleep(5)
        while True:
            try:
                n = await _cleanup_tg_big_dir_once()
                if n:
                    log.info("tg-big cleaner: deleted=%s dir=%s", n, _TG_BIG_DIR)
            except asyncio.CancelledError:
                raise
            except Exception as e:
                log.warning("tg-big cleaner failed: %s", e)
            await asyncio.sleep(max(60.0, _TG_BIG_CLEAN_INTERVAL_MIN * 60.0))

    return asyncio.create_task(_worker())


def _safe_fs_name(name: str) -> str:
    name = (name or "file.bin")
    name = Path(name).name
    name = re.sub(r"[^\w.\-()+@ ]+", "_", name)
    return name or "file.bin"


async def _download_tg_file_to_path(file_id: str, filename_hint: str) -> Tuple[str, str]:
    """Вернуть (local_path, filename) без загрузки файла в память."""
    fut = _BIG_INFLIGHT.get(file_id)
    if fut:
        return await fut

    loop = asyncio.get_running_loop()
    loop_fut: asyncio.Future = loop.create_future()
    _BIG_INFLIGHT[file_id] = loop_fut
    try:
        b = bot_local or bot
        f = await b.get_file(file_id)
        file_path = getattr(f, "file_path", None)
        if not file_path:
            raise RuntimeError("get_file returned empty file_path")

        # local Bot API может вернуть абсолютный путь на диске (в примонтированном томе)
        if isinstance(file_path, str) and file_path.startswith("/"):
            p = Path(file_path)
            if p.exists() and p.is_file():
                loop_fut.set_result((str(p), p.name or (file_id + ".bin")))
                return str(p), p.name or (file_id + ".bin")

        # иначе скачиваем потоково на диск
        url = _build_tg_file_url(str(file_path))
        # имя файла — из file_path, иначе из подсказки
        fname = os.path.basename(str(file_path)) or filename_hint or (file_id + ".bin")
        fname = _safe_fs_name(fname)

        dst_dir = Path(TG_BIGFILE_DIR)
        final_path = dst_dir / f"{file_id}__{fname}"
        if final_path.exists() and final_path.is_file():
            loop_fut.set_result((str(final_path), fname))
            return str(final_path), fname

        tmp_path = dst_dir / f"{file_id}__{fname}.part"

        sess = get_tg_http_session()
        async with _BIG_SEM:
            async with sess.get(
                url,
                timeout=aiohttp.ClientTimeout(
                    total=float(os.getenv("TG_HTTP_TIMEOUT_TOTAL", "180"))
                ),
            ) as resp:
                if resp.status != 200:
                    txt = await resp.text()
                    raise RuntimeError(
                        f"download tg file failed {resp.status}: {txt[:200]}"
                    )
                with open(tmp_path, "wb") as out:
                    async for chunk in resp.content.iter_chunked(1024 * 1024):
                        if chunk:
                            out.write(chunk)

        tmp_path.replace(final_path)
        loop_fut.set_result((str(final_path), fname))
        return str(final_path), fname
    except Exception as e:
        if not loop_fut.done():
            loop_fut.set_exception(e)
        raise
    finally:
        _BIG_INFLIGHT.pop(file_id, None)


def _is_big(file_size: Optional[int]) -> bool:
    try:
        return bool(file_size) and int(file_size) >= (_BIG_THRESHOLD_MB * 1024 * 1024)
    except Exception:
        return False


_ALBUM_BUF: Dict[str, Dict[str, Any]] = {}
_ALBUM_DELAY_SEC = float(os.getenv("ALBUM_FLUSH_DELAY", "1.2"))
_ALBUM_CONC = int(os.getenv("ALBUM_BUILD_CONCURRENCY", os.getenv("MAX_UPLOAD_CONCURRENCY", "3")))

_IMG_VIA_URL = os.getenv("MAX_IMAGE_VIA_URL", "0").lower() not in ("0", "false", "no", "off")
_S3_CANARY_KEY = os.getenv("S3_CANARY_KEY", "healthz/canary.txt")
_MAX_LINK_SEND_CONC = int(os.getenv("MAX_LINK_SEND_CONC", "1"))
_LINK_SEMS: Dict[int, asyncio.Semaphore] = {}

# --- настройки авто-паузы проблемных связок MAX ---
_MAX_LINK_ERR_WINDOW = int(os.getenv("MAX_LINK_ERROR_WINDOW_SEC", "300"))  # окно в секундах
_MAX_LINK_ERR_THRESHOLD = int(os.getenv("MAX_LINK_ERROR_THRESHOLD", "5"))  # сколько ошибок за окно
_LINK_ERR_STATS: Dict[int, List[float]] = {}
_AUTO_DISABLED_LINKS: set[int] = set()

_METRICS: Dict[str, int] = {
    "tg_updates": 0,
    "tg_channel_posts": 0,
    "tg_chat_msgs": 0,
    "max_send_ok": 0,
    "max_send_err": 0,
    "album_flushes": 0,
}

# --- фоновые задачи для webhook (мгновенный ACK) ---
_BG_TASKS: Set[asyncio.Task] = set()

# лимит параллельной обработки апдейтов (защита от перегруза)
_UPDATE_CONC = int(os.getenv("TG_UPDATE_CONCURRENCY", "50"))
_UPDATE_SEM = asyncio.Semaphore(max(1, _UPDATE_CONC))


def _track_task(t: asyncio.Task) -> None:
    _BG_TASKS.add(t)

    def _done(_t: asyncio.Task):
        _BG_TASKS.discard(_t)
        # забираем исключение, чтобы не было "Task exception was never retrieved"
        with contextlib.suppress(Exception):
            _t.exception()

    t.add_done_callback(_done)


async def _process_update(update: Update) -> None:
    async with _UPDATE_SEM:
        try:
            await dp.feed_update(bot, update)
        except Exception as e:
            # здесь важно НЕ падать — иначе можно терять апдейты пачкой
            log.exception("process_update failed: %s", e)


# --- настройки webhook ЮKassa ---
YK_WEBHOOK_SECRET = os.getenv("YOOKASSA_WEBHOOK") or Cfg.WEBHOOK_SECRET or ""

_YK_IP_RANGES = [
    ipaddress.ip_network("185.71.76.0/27"),
    ipaddress.ip_network("185.71.77.0/27"),
    ipaddress.ip_network("77.75.153.0/25"),
    ipaddress.ip_network("77.75.154.128/25"),
    ipaddress.ip_network("77.75.156.11/32"),
    ipaddress.ip_network("77.75.156.35/32"),
    ipaddress.ip_network("2a02:5180::/32"),
]


def _get_link_sem(link_id: int) -> asyncio.Semaphore:
    sem = _LINK_SEMS.get(link_id)
    if sem is None:
        sem = asyncio.Semaphore(max(1, _MAX_LINK_SEND_CONC))
        _LINK_SEMS[link_id] = sem
    return sem


async def _auto_pause_link(link_id: int) -> None:
    if link_id in _AUTO_DISABLED_LINKS:
        return

    try:
        rows = await aquery(
            """
            UPDATE channel_links
               SET enabled = false,
                   auto_paused = true
             WHERE id = %s
               AND enabled = true
         RETURNING id, source_chat_id, owner_tg_user_id,
            name
            """,
            (link_id,),
        )
    except Exception as e:
        log.warning("auto_pause_link: update failed for link %s: %s", link_id, e)
        return

    if not rows:
        return

    row = rows[0]
    _AUTO_DISABLED_LINKS.add(link_id)

    src_chat_id = row.get("source_chat_id")
    owner_id = row.get("owner_tg_user_id")
    name = row.get("name") or f"Связка #{link_id}"

    if src_chat_id:
        with contextlib.suppress(Exception):
            invalidate_source_links(int(src_chat_id))

    msg = (
        f"⚠️ Связка {link_id} («{name}») автоматически поставлена на паузу "
        f"из-за повторяющихся ошибок отправки в MAX. "
        f"Проверьте настройки канала/чата в MAX и права бота."
    )

    await notify_admin_throttled(f"auto_pause_link_{link_id}", msg)

    if owner_id:
        with contextlib.suppress(Exception):
            await bot.send_message(
                int(owner_id),
                msg + "\n\nВы можете вручную возобновить её в меню бота после проверки настроек.",
            )


async def _register_max_error(link_id: int, err: Exception) -> None:
    # Некоторые ошибки MAX считаем временными и не используем для авто-паузы
    msg = str(err)
    # Фатальная ошибка конфигурации: чат/канал в MAX не найден (удалён/нет доступа).
    # Ретраи и накопление порога тут не нужны — лучше сразу поставить связку на паузу,
    # чтобы не забивать очередь и не спамить алертами.
    if "chat.not.found" in msg:
        log.warning("register_max_error: MAX chat.not.found for link %s -> auto pause", link_id)
        await _auto_pause_link(link_id)
        # Сбросим накопленные ошибки, чтобы после перепривязки не срабатывала авто-пауза сразу снова
        _LINK_ERR_STATS.pop(link_id, None)
        return

    transient_markers = (
        "too.many.requests",     # 429 Too many chat send message requests
        "attachment.not.ready",  # видео/вложение ещё не обработано MAX
    )
    if any(marker in msg for marker in transient_markers):
        log.warning(
            "register_max_error: transient MAX error for link %s, "
            "not counting for auto-pause: %s",
            link_id,
            msg,
        )
        return

    if _MAX_LINK_ERR_THRESHOLD <= 0:
        return

    now = time.monotonic()
    cutoff = now - max(1, _MAX_LINK_ERR_WINDOW)

    lst = _LINK_ERR_STATS.get(link_id)
    if lst is None:
        lst = []
        _LINK_ERR_STATS[link_id] = lst

    # чистим старые ошибки и добавляем новую
    lst[:] = [t for t in lst if t >= cutoff]
    lst.append(now)

    if len(lst) >= _MAX_LINK_ERR_THRESHOLD:
        log.warning(
            "auto_pause_link: threshold reached for link %s (errors in window=%d)",
            link_id,
            len(lst),
        )
        await _auto_pause_link(link_id)



def _entity_type_name(et) -> str:
    try:
        return et.value if hasattr(et, "value") else str(et)
    except Exception:
        return str(et)


def _utf16_to_py_index(s: str, u16_index: int) -> int:
    if u16_index <= 0:
        return 0
    count = 0
    i = 0
    n = len(s)
    while i < n and count < u16_index:
        cp = ord(s[i])
        if cp >= 0x10000:
            count += 2
        else:
            count += 1
        i += 1
    return i


def _utf16_range_to_py_slice(s: str, offset_u16: int, length_u16: int) -> Tuple[int, int]:
    start = _utf16_to_py_index(s, offset_u16)
    end = _utf16_to_py_index(s, offset_u16 + max(0, length_u16))
    start = max(0, min(start, len(s)))
    end = max(start, min(end, len(s)))
    return start, end


def _wrap_for_entity(segment_text: str, etype: str, url: Optional[str]) -> Tuple[str, str]:
    etype = (etype or "").lower()

    if etype == "bold":
        return "<b>", "</b>"
    if etype == "italic":
        return "<i>", "</i>"
    if etype == "underline":
        return "<u>", "</u>"
    if etype == "strikethrough":
        return "<s>", "</s>"
    if etype == "code":
        return "<code>", "</code>"
    if etype == "pre":
        return "<pre>", "</pre>"
    if etype in ("blockquote", "block_quote", "quote"):
        return "<blockquote>", "</blockquote>"
    if etype == "spoiler":
        return '<span class="tg-spoiler">', "</span>"
    if etype in ("text_link", "url"):
        link = url or segment_text
        if link:
            return f'<a href="{html.escape(link, quote=True)}">', "</a>"
    return "", ""


def html_from_text_and_entities(text: str, entities: List[Any]) -> str:
    if not entities:
        return html.escape(text)

    opens: Dict[int, List[str]] = {}
    closes: Dict[int, List[str]] = {}

    n = len(text)

    for e in entities:
        try:
            etype = _entity_type_name(getattr(e, "type", None))
            offset_u16 = int(getattr(e, "offset", 0))
            length_u16 = int(getattr(e, "length", 0))
            url = getattr(e, "url", None)
        except Exception:
            continue

        if length_u16 <= 0:
            continue

        start, end = _utf16_range_to_py_slice(text, offset_u16, length_u16)
        if start >= end or start >= n:
            continue

        open_tag, close_tag = _wrap_for_entity(text[start:end], etype, url)
        if open_tag or close_tag:
            opens.setdefault(start, []).append(open_tag)
            closes.setdefault(end, []).append(close_tag)

    out: List[str] = []
    for i, ch in enumerate(text):
        if i in opens:
            out.extend(opens[i])
        out.append(html.escape(ch))
        if (i + 1) in closes:
            for tag in reversed(closes[i + 1]):
                out.append(tag)
    return "".join(out)


def get_text_and_html(msg: Message) -> Tuple[str, str, bool]:
    if msg.caption is not None:
        cap = msg.caption or ""
        ents = getattr(msg, "caption_entities", None) or []
        cap_html = html_from_text_and_entities(cap, ents)
        return cap, cap_html, True

    if msg.text is not None:
        txt = msg.text or ""
        html_like = getattr(msg, "html_text", None) or txt
        return txt, html_like, False

    return "", "", False


def disable_preview_from_source(msg: Message) -> bool:
    lpo = getattr(msg, "link_preview_options", None)
    try:
        return bool(lpo and getattr(lpo, "is_disabled", False))
    except Exception:
        return False


def ensure_json(data: Any) -> dict:
    if isinstance(data, dict):
        return data
    if isinstance(data, str):
        try:
            return json.loads(data)
        except Exception:
            return {}
    return {}


def apply_rules_to_html(htmltxt: str, rules: List[dict]) -> Tuple[str, bool]:
    if not htmltxt:
        return htmltxt, False

    cur = htmltxt
    changed_any = False

    for r in rules:
        try:
            typ = r["type"]
            data = ensure_json(r.get("data"))
        except Exception:
            continue

        if typ != "simple":
            continue

        from_html = (data.get("from_html") or "").strip()
        to_html = data.get("to_html") or ""

        from_plain = (data.get("from_plain") or data.get("from") or "").strip()
        to_plain = data.get("to_plain") or data.get("to") or ""

        before = cur

        if from_html:
            cur = cur.replace(from_html, to_html)
        elif from_plain:
            cur = cur.replace(from_plain, to_plain)

        if cur != before:
            changed_any = True

    return cur, changed_any


def exclusions_hit(text: str, tokens: List[str]) -> bool:
    t = text or ""
    return any(tok and tok in t for tok in tokens)


def build_sender_name_from_tg(msg: Message) -> str:
    try:
        u = getattr(msg, "from_user", None)
        if u:
            first = u.first_name or ""
            last = u.last_name or ""
            username = u.username or ""
            name = (first + " " + last).strip()
            if not name and username:
                name = "@" + username
            if not name:
                name = str(u.id)
            return name

        ch = getattr(msg, "sender_chat", None)
        if ch:
            title = getattr(ch, "title", None) or getattr(ch, "username", None)
            if title:
                return title
            cid = getattr(ch, "id", None)
            if cid is not None:
                return str(cid)
    except Exception:
        pass
    return ""



async def _notify_text_too_long_max(bot: Bot, link_row: dict, original_len: int) -> None:
    """
    Уведомление (только владельцу связки и админам) о том, что MAX ограничивает длину текста.
    Вызываем в двух случаях:
      1) мы сами обрезали текст перед отправкой в MAX;
      2) MAX вернул 400 с сообщением про размер request.text.
    """
    try:
        link_id = int(link_row.get("id") or 0)
    except Exception:
        link_id = 0

    link_name = (link_row or {}).get("name") or ""
    owner_id = (link_row or {}).get("owner_tg_user_id")

    note = (
        "⚠️ MAX ограничивает длину текста в сообщении (до 4000 символов).\n"
        f"Связка {link_id}" + (f" («{link_name}»)" if link_name else "") + "\n"
        f"В исходном сообщении было {original_len} символов, поэтому публикация в MAX была сокращена.\n"
        "Решение: сократите текст, разбейте на несколько сообщений или используйте правила замены/исключения."
    )

    # Админам — троттлинг по связке, чтобы не спамить при массовой ошибке
    await notify_admin_throttled(f"max_text_limit_{link_id}", note, min_interval_sec=600)

    # Владельцу — отправляем 1:1, без общего троттлинга (но всё равно ограничим 4096)
    if owner_id:
        with contextlib.suppress(Exception):
            await bot.send_message(int(owner_id), note[:4096])


async def send_text(bot: Bot, chat_id: int, htmltxt: str, preview_disabled: bool = False) -> None:
    if not htmltxt:
        return
    kwargs = {}
    if preview_disabled:
        kwargs["link_preview_options"] = LinkPreviewOptions(is_disabled=True)
    await bot.send_message(chat_id, htmltxt, **kwargs)


def _build_tg_file_url(file_path: str) -> str:
    """
    Строим URL до файла:
    - если включён локальный Bot API — используем его base
    - иначе используем api.telegram.org
    """
    if _TG_USE_LOCAL_FOR_DOWNLOAD and _TG_LOCAL_BASE:
        base = _TG_LOCAL_BASE.rstrip("/")
        return f"{base}/file/bot{BOT_TOKEN}/{file_path.lstrip('/')}"
    return f"https://api.telegram.org/file/bot{BOT_TOKEN}/{file_path}"


async def _raw_download_tg_file(file_id: str) -> Tuple[bytes, str]:
    """
    Скачивает файл из Telegram и возвращает (data, filename),
    как ожидает MediaCache.get_or_fetch().

    Логика:
    1) если есть локальный Bot API (bot_local) — сначала пробуем через него:
       - get_file
       - если file_path абсолютный — читаем с диска
       - иначе качаем по HTTP с botapi.echomax.ru/file/...
    2) если локальный API вернул ошибку/404/что угодно — пробуем облачный api.telegram.org:
       - get_file
       - качаем по HTTPS с api.telegram.org/file/...
    """
    last_error: Optional[Exception] = None

    # порядок попыток: сначала локальный, потом облако
    backends: List[Tuple[str, Optional[Bot]]] = [
        ("local", bot_local),
        ("cloud", bot),
    ]

    for backend_name, client in backends:
        if client is None:
            continue

        try:
            f = await client.get_file(file_id)
        except Exception as e:
            log.warning(
                "_raw_download_tg_file: %s get_file failed for %s: %s",
                backend_name,
                file_id,
                e,
            )
            last_error = e
            continue

        file_path = getattr(f, "file_path", None)
        if not file_path:
            last_error = RuntimeError(
                f"{backend_name} get_file returned empty file_path"
            )
            continue

        # Абсолютный путь на диске возможен только для локального Bot API (--local)
        if (
            backend_name == "local"
            and isinstance(file_path, str)
            and file_path.startswith("/")
        ):
            p = Path(file_path)
            if p.exists() and p.is_file():
                data = await asyncio.to_thread(p.read_bytes)
                filename = p.name or (file_id + ".bin")
                return data, filename
            else:
                last_error = RuntimeError(
                    f"local file path does not exist or not a file: {file_path}"
                )
                continue

        # Формируем URL для скачивания
        file_path_str = str(file_path)
        filename = os.path.basename(file_path_str) or (file_id + ".bin")

        if backend_name == "local":
            # Явно используем локальный base, не полагаясь на _build_tg_file_url,
            # чтобы не было путаницы, если бот ходит в облако.
            if not _TG_LOCAL_BASE:
                last_error = RuntimeError("local backend selected, but _TG_LOCAL_BASE is empty")
                continue
            base = _TG_LOCAL_BASE.rstrip("/")
            url = f"{base}/file/bot{BOT_TOKEN}/{file_path_str.lstrip('/')}"
        else:
            # облако всегда через api.telegram.org
            url = f"https://api.telegram.org/file/bot{BOT_TOKEN}/{file_path_str}"

        sess = get_tg_http_session()
        try:
            async with sess.get(url, timeout=aiohttp.ClientTimeout(total=180)) as resp:
                if resp.status == 200:
                    data = await resp.read()
                    return data, filename

                txt = await resp.text()
                log.warning(
                    "_raw_download_tg_file: %s HTTP %s for %s: %s",
                    backend_name,
                    resp.status,
                    url,
                    txt[:200],
                )
                last_error = RuntimeError(
                    f"download tg file via {backend_name} failed {resp.status}: {txt[:200]}"
                )
                continue
        except Exception as e:
            log.warning(
                "_raw_download_tg_file: %s HTTP error for %s: %s",
                backend_name,
                url,
                e,
            )
            last_error = e
            continue

    # сюда попадём, только если все бэкенды провалились
    if last_error:
        raise last_error
    raise RuntimeError("download tg file failed: no backend available")


async def _get_tg_file_url(file_id: str) -> str:
    """
    Получить ПУБЛИЧНЫЙ URL файла для передачи во внешние сервисы (MAX).

    Важно:
    - всегда используем api.telegram.org, даже если включён локальный Bot API;
    - если get_file вернул абсолютный путь (локальный режим) — считаем, что
      такой путь нельзя отдать наружу, и провоцируем fallback на upload.
    """
    f = await _tg_get_file_resilient(file_id)
    file_path = getattr(f, "file_path", None)
    if not file_path:
        raise RuntimeError("get_file returned empty file_path")

    fp = str(file_path)

    # Если это локальный абсолютный путь (/var/lib/telegram-bot-api/...)
    # — он не годится как публичный URL, пусть вызывающий код уйдёт в upload.
    if fp.startswith("/"):
        raise RuntimeError(
            "local file_path returned (absolute path); cannot use as public URL"
        )

    # Строим URL только через api.telegram.org — это доступно извне (для MAX)
    return f"https://api.telegram.org/file/bot{BOT_TOKEN}/{fp.lstrip('/')}"



async def build_max_attachment_from_msg(msg: Message) -> Optional[dict]:
    """
    Собираем attachment для MAX из сообщения Telegram.
    Если при загрузке медиа Telegram отвечает `invalid file_id`,
    мы не роняем весь апдейт, а просто пропускаем вложение (возвращаем None).
    """
    try:
        if msg.photo:
            ph = msg.photo[-1]

            if _IMG_VIA_URL:
                try:
                    url = await _get_tg_file_url(ph.file_id)
                    return {"type": "image", "payload": {"url": url}, "_tg_file_id": ph.file_id, "_tg_filename": "photo.jpg"}
                except Exception as e:
                    log.warning("image via url failed, fallback to upload: %s", e)

            data, filename = await MC.get_or_fetch(
                ph.file_id,
                filename_hint="photo.jpg",
                fetcher=lambda: _raw_download_tg_file(ph.file_id),
                mime_hint="image/jpeg",
            )
            payload = await upload_image_bytes(data, filename, mime_hint="image/jpeg")
            return {"type": "image", "payload": payload, "_tg_file_id": ph.file_id, "_tg_filename": filename}

        if msg.video:
            v = msg.video

            # большие видео — через локальный файл
            if _is_big(getattr(v, "file_size", None)):
                path, filename = await _download_tg_file_to_path(
                    v.file_id,
                    v.file_name or "video.mp4",
                )
                token = await upload_video_path(
                    path,
                    filename,
                    mime_hint=(v.mime_type or "video/mp4"),
                )
                return {"type": "video", "payload": {"token": token}}

            data, filename = await MC.get_or_fetch(
                v.file_id,
                filename_hint=v.file_name or "video.mp4",
                fetcher=lambda: _raw_download_tg_file(v.file_id),
                mime_hint=(v.mime_type or "video/mp4"),
            )
            token = await upload_video_bytes(
                data,
                filename,
                mime_hint=(v.mime_type or "video/mp4"),
            )
            return {"type": "video", "payload": {"token": token}}

        if getattr(msg, "video_note", None):
            vn = msg.video_note

            if _is_big(getattr(vn, "file_size", None)):
                path, filename = await _download_tg_file_to_path(
                    vn.file_id,
                    "video_note.mp4",
                )
                token = await upload_video_path(
                    path,
                    filename,
                    mime_hint="video/mp4",
                )
                return {"type": "video", "payload": {"token": token}}

            data, filename = await MC.get_or_fetch(
                vn.file_id,
                filename_hint="video_note.mp4",
                fetcher=lambda: _raw_download_tg_file(vn.file_id),
                mime_hint="video/mp4",
            )
            token = await upload_video_bytes(
                data,
                filename,
                mime_hint="video/mp4",
            )
            return {"type": "video", "payload": {"token": token}}

        if getattr(msg, "animation", None):
            a = msg.animation
            data, filename = await MC.get_or_fetch(
                a.file_id,
                filename_hint=a.file_name or "animation.mp4",
                fetcher=lambda: _raw_download_tg_file(a.file_id),
                mime_hint=(a.mime_type or "video/mp4"),
            )
            token = await upload_video_bytes(
                data,
                filename,
                mime_hint=(a.mime_type or "video/mp4"),
            )
            return {"type": "video", "payload": {"token": token}}

        if msg.document:
            d = msg.document

            # Telegram обычно отдаёт file_name и mime_type, но на всякий случай ставим дефолты
            fname = d.file_name or "file.bin"
            mime = d.mime_type or "application/octet-stream"

            # Для очень больших файлов лучше сразу писать во временный путь и грузить из файла
            if _is_big(getattr(d, "file_size", None)):
                path, filename = await _download_tg_file_to_path(
                    d.file_id,
                    fname,
                )
                try:
                    token = await upload_file_path(
                        path,
                        filename,
                        mime_hint=mime,
                    )
                    return {"type": "file", "payload": {"token": token}}
                except MaxSendError as e:
                    log.warning("document upload (path) failed (%s), fallback to bytes", e)
                    # fallback: читаем байты через кэш
                    data, filename = await MC.get_or_fetch(
                        d.file_id,
                        filename_hint=fname,
                        fetcher=lambda: _raw_download_tg_file(d.file_id),
                        mime_hint=mime,
                    )
                    token = await upload_file_bytes(
                        data,
                        filename,
                        mime_hint=mime,
                    )
                    return {"type": "file", "payload": {"token": token}}

            # Обычный случай: документ не слишком большой — берём в память через кэш
            data, filename = await MC.get_or_fetch(
                d.file_id,
                filename_hint=fname,
                fetcher=lambda: _raw_download_tg_file(d.file_id),
                mime_hint=mime,
            )
            try:
                token = await upload_file_bytes(
                    data,
                    filename,
                    mime_hint=mime,
                )
                return {"type": "file", "payload": {"token": token}}
            except MaxSendError as e:
                # На всякий случай логируем, но не роняем весь апдейт — тогда уйдёт только текст
                log.warning("document upload (bytes) failed (%s), attachment will be skipped", e)

        if msg.audio:
            a = msg.audio
            data, filename = await MC.get_or_fetch(
                a.file_id,
                filename_hint=a.file_name or "audio.mp3",
                fetcher=lambda: _raw_download_tg_file(a.file_id),
                mime_hint=(a.mime_type or "audio/mpeg"),
            )
            try:
                token = await upload_audio_bytes(
                    data,
                    filename,
                    mime_hint=(a.mime_type or "audio/mpeg"),
                )
                return {"type": "audio", "payload": {"token": token}}
            except MaxSendError as e:
                log.warning("audio upload failed (%s), fallback to file", e)
                ftoken = await upload_file_bytes(
                    data,
                    filename,
                    mime_hint=(a.mime_type or "application/octet-stream"),
                )
                return {"type": "file", "payload": {"token": ftoken}, "_audio_like": True}

        if msg.voice:
            v = msg.voice

            if _is_big(getattr(v, "file_size", None)):
                path, filename = await _download_tg_file_to_path(
                    v.file_id,
                    "voice.ogg",
                )
                try:
                    token = await upload_audio_path(
                        path,
                        filename,
                        mime_hint=(v.mime_type or "audio/ogg"),
                    )
                    return {"type": "audio", "payload": {"token": token}}
                except MaxSendError as e:
                    log.warning("voice upload failed (%s), fallback to file", e)
                    ftoken = await upload_file_path(
                        path,
                        filename,
                        mime_hint=(v.mime_type or "application/octet-stream"),
                    )
                    return {"type": "file", "payload": {"token": ftoken}, "_audio_like": True}

            data, filename = await MC.get_or_fetch(
                v.file_id,
                filename_hint="voice.ogg",
                fetcher=lambda: _raw_download_tg_file(v.file_id),
                mime_hint=(v.mime_type or "audio/ogg"),
            )
            try:
                token = await upload_audio_bytes(
                    data,
                    filename,
                    mime_hint=(v.mime_type or "audio/ogg"),
                )
                return {"type": "audio", "payload": {"token": token}}
            except MaxSendError as e:
                log.warning("voice upload failed (%s), fallback to file", e)
                ftoken = await upload_file_bytes(
                    data,
                    filename,
                    mime_hint=(v.mime_type or "application/octet-stream"),
                )
                return {"type": "file", "payload": {"token": ftoken}, "_audio_like": True}

        if msg.sticker:
            st = msg.sticker

            thumb = getattr(st, "thumbnail", None) or getattr(st, "thumb", None)
            if thumb:
                data, filename = await MC.get_or_fetch(
                    thumb.file_id,
                    filename_hint="sticker_preview.jpg",
                    fetcher=lambda: _raw_download_tg_file(thumb.file_id),
                    mime_hint="image/jpeg",
                )
                try:
                    payload = await upload_image_bytes(
                        data,
                        filename,
                        mime_hint="image/jpeg",
                    )
                    return {"type": "image", "payload": payload, "_tg_file_id": ph.file_id, "_tg_filename": filename}
                except MaxSendError as e:
                    log.warning(
                        "sticker thumb upload failed (%s), fallback to full sticker",
                        e,
                    )

            is_video = bool(getattr(st, "is_video", False))
            data, filename = await MC.get_or_fetch(
                st.file_id,
                filename_hint="sticker.webm" if is_video else "sticker.webp",
                fetcher=lambda: _raw_download_tg_file(st.file_id),
                mime_hint=("video/webm" if is_video else "image/webp"),
            )
            try:
                if is_video:
                    token = await upload_video_bytes(
                        data,
                        filename,
                        mime_hint="video/webm",
                    )
                    return {"type": "video", "payload": {"token": token}}
                else:
                    payload = await upload_image_bytes(
                        data,
                        filename,
                        mime_hint="image/webp",
                    )
                    return {"type": "image", "payload": payload, "_tg_file_id": ph.file_id, "_tg_filename": filename}
            except MaxSendError:
                ftoken = await upload_file_bytes(
                    data,
                    filename,
                    mime_hint="application/octet-stream",
                )
                return {"type": "file", "payload": {"token": ftoken}}

        return None

    except TelegramBadRequest as e:
        # ключевой фикс: не роняем апдейт, если Telegram сказал "invalid file_id"
        log.warning(
            "build_max_attachment_from_msg: TelegramBadRequest (invalid file_id?) "
            "for message %s: %s. Attachment will be skipped.",
            getattr(msg, "message_id", None),
            e,
        )
        return None
# ---- дальше твой файл без изменений ----

async def _album_flush(link_row: dict, items: List[Message]):
    link_id = int(link_row["id"])
    target_chat_id = int(link_row["target_chat_id"])

    _METRICS["album_flushes"] += 1

    text = ""
    htmltxt = ""
    for m in items:
        p, h, is_cap = get_text_and_html(m)
        if is_cap and (p or h):
            text, htmltxt = p, h
            break

    excl = await aget_exclusions_for_link(link_id)
    rules = await aget_rules_for_link(link_id)

    if exclusions_hit(text, excl):
        log.info("album: skipped by exclusion")
        return

    html_new, changed = apply_rules_to_html(htmltxt, rules) if rules else (htmltxt, False)
    caption = html_new if changed else htmltxt

    platform = (link_row.get("target_platform") or "tg").lower()
    link_type = (link_row.get("link_type") or "channel").lower()
    if platform == "max" and link_type == "chat":
        sender_name = build_sender_name_from_tg(items[0])
        if sender_name:
            name_html = f"<b><u>{html.escape(sender_name)}</u></b>"
            if caption:
                caption = name_html + "\n" + caption
            else:
                caption = name_html

    sem = asyncio.Semaphore(max(1, _ALBUM_CONC))

    async def one(m: Message):
        async with sem:
            return await build_max_attachment_from_msg(m)

    built = await asyncio.gather(*[one(m) for m in items], return_exceptions=True)
    attachments: List[Dict[str, Any]] = []
    for b in built:
        if isinstance(b, Exception):
            log.warning("album: one part failed: %s", b)
            continue
        if b:
            attachments.append(b)

    if not attachments and not caption:
        log.info("album: nothing to send")
        return

    link_sem = _get_link_sem(link_id)
    async with link_sem:
        try:
            reply_to_mid: Optional[str] = None
            if items and items[0].reply_to_message:
                rows = await aquery(
                    "select max_mid from cross_message_map where link_id=%s and tg_msg_id=%s",
                    (link_id, int(items[0].reply_to_message.message_id)),
                )
                if rows:
                    row = rows[0]
                    max_mid = row.get("max_mid") if isinstance(row, dict) else row[0]
                    if max_mid:
                        reply_to_mid = str(max_mid)

            text_for_max = (caption or "") or ""
            text_for_max = text_for_max.replace("<u>", "<ins>").replace("</u>", "</ins>")

            # --- отправка альбома в MAX с повышенной устойчивостью ---
            # Идея: 2 попытки отправить альбом целиком; если не получилось —
            # отправляем по одному, пропуская проблемные вложения, и уведомляем.
            def _parse_max_send_error(e: Exception) -> tuple[int | None, str]:
                s = str(e)
                m = re.search(r"failed\s+(\d+):", s)
                status = int(m.group(1)) if m else None
                return status, s

            async def _max_send_once(att: Optional[list], txt_payload: str, rmid: Optional[str]) -> Dict[str, Any]:
                # MAX лимитирует request.text 4000 символами. Подрежем с запасом (как и для одиночных сообщений).
                MAX_TEXT_LIMIT = 3900
                _trimmed_original_len: Optional[int] = None
                if txt_payload and len(txt_payload) > MAX_TEXT_LIMIT:
                    _trimmed_original_len = len(txt_payload)
                    log.warning(
                        "album: trimming caption for MAX chat %s from %d to %d chars",
                        target_chat_id,
                        _trimmed_original_len,
                        MAX_TEXT_LIMIT,
                    )
                    txt_payload = txt_payload[: MAX_TEXT_LIMIT - 1] + "…"

                try:
                    res = await max_send_message(
                        chat_id=target_chat_id,
                        text=txt_payload,
                        attachments=att or None,
                        fmt="html",
                        disable_link_preview=False,
                        reply_to_mid=rmid,
                    )
                except TypeError:
                    # совместимость со старой сигнатурой max_send_message
                    res = await max_send_message(
                        chat_id=target_chat_id,
                        text=txt_payload,
                        attachments=att or None,
                        fmt="html",
                        disable_link_preview=False,
                    )

                if _trimmed_original_len is not None:
                    try:
                        res = res or {}
                        res["_meta"] = res.get("_meta") or {}
                        res["_meta"]["trimmed_text"] = {
                            "original_len": int(_trimmed_original_len),
                            "sent_len": int(len(txt_payload or "")),
                        }
                    except Exception:
                        pass

                return res

            async def _max_send_with_retries(att: list, txt_payload: str, rmid: Optional[str]) -> Dict[str, Any]:
                last_err: Optional[Exception] = None
                for attempt in range(1, 3):  # 2 попытки
                    try:
                        return await _max_send_once(att, txt_payload, rmid)
                    except MaxSendError as e:
                        last_err = e
                        status, es = _parse_max_send_error(e)
                        # Неретраимые кейсы — сразу выходим на fallback
                        if status == 400 and "Must be only one audio attachment" in es:
                            break
                        if status == 404 and "chat.not.found" in es:
                            raise
                        # Для proto.payload/Failed to upload image и прочих 4xx иногда помогает повтор
                        if attempt < 2:
                            await asyncio.sleep(1.0 * attempt)
                            continue
                        break
                assert last_err is not None
                raise last_err

            res: Dict[str, Any]
            # MAX ограничение: в одном сообщении допускается только одно аудио-вложение.
            # Если у нас больше 1 аудио (или аудио-файл, помеченный как _audio_like),
            # не тратим попытки на заведомо невалидную отправку — сразу идём в fallback.
            audioish = [a for a in attachments if (a or {}).get("type") == "audio" or (a or {}).get("_audio_like")]
            force_audio_fallback = len(audioish) > 1

            try:
                if force_audio_fallback:
                    raise MaxSendError("failed 400: Must be only one audio attachment in message (precheck)")
                res = await _max_send_with_retries(attachments, text_for_max, reply_to_mid)
                # Если MAX потребовал укоротить текст — уведомим владельца и админов
                if (res or {}).get("_meta", {}).get("trimmed_text"):
                    try:
                        await _notify_text_too_long_max(bot, link_row, int(res["_meta"]["trimmed_text"].get("original_len") or 0))
                    except Exception:
                        pass
            except MaxSendError as e:
                # Fallback: по одному вложению, пропуская проблемные.
                status, es = _parse_max_send_error(e)

                # Спец-кейс MAX: в одном сообщении допускается только 1 audio
                audios = [a for a in attachments if (a or {}).get("type") == "audio" or (a or {}).get("_audio_like")]
                others = [a for a in attachments if not ((a or {}).get("type") == "audio" or (a or {}).get("_audio_like"))]

                skipped: list[dict] = []
                sent_any = False

                async def _try_send_single(att: dict, txt_payload: str, rmid: Optional[str]) -> bool:
                    nonlocal sent_any
                    try:
                        await _max_send_once([att], txt_payload, rmid)
                        sent_any = True
                        return True
                    except MaxSendError as ee:
                        st, ess = _parse_max_send_error(ee)
                        # 404 chat.not.found — прекращаем сразу (фатальная конфигурация)
                        if st == 404 and "chat.not.found" in ess:
                            raise

                        # Спец-кейс: MAX иногда принимает только "нормальные" JPEG/PNG.
                        # Если упали на 'Failed to upload image' — пробуем один раз перекодировать и пере-загрузить.
                        if (att or {}).get("type") == "image" and ("Failed to upload image" in ess or "proto.payload" in ess):
                            tg_file_id = (att or {}).get("_tg_file_id")
                            if tg_file_id:
                                try:
                                    new_payload = await _reupload_tg_image_as_jpeg(
                                        tg_file_id,
                                        (att or {}).get("_tg_filename") or "photo.jpg",
                                    )
                                    att2 = dict(att)
                                    att2["payload"] = new_payload
                                    await _max_send_once([att2], txt_payload, rmid)
                                    sent_any = True
                                    return True
                                except Exception as e2:
                                    log.warning("image repair retry failed for link %s: %s", link_id, e2)

                        skipped.append(att)
                        return False


                # 1) Пробуем отправить не-audio вложения одним сообщением (с подписью).
                if others or caption:
                    try:
                        await _max_send_once(others or None, text_for_max, reply_to_mid)
                        sent_any = True
                    except MaxSendError as ee:
                        st, ess = _parse_max_send_error(ee)
                        if st == 404 and "chat.not.found" in ess:
                            raise
                        # если пачка не ушла — пробуем по одному
                        if others:
                            first = True
                            for att in others:
                                await _try_send_single(att, text_for_max if first else "", reply_to_mid if first else None)
                                first = False

                # 2) Аудио — всегда по одному (если их больше одного или если MAX ругался)
                if audios:
                    first_audio = (not sent_any)
                    for att in audios:
                        await _try_send_single(att, text_for_max if first_audio else "", reply_to_mid if first_audio else None)
                        first_audio = False

                # 3) Уведомление о пропущенных вложениях: только админу и владельцу в Telegram
                if skipped:
                    kind_counts: Dict[str, int] = {}
                    for a in skipped:
                        k = (a or {}).get("type") or "unknown"
                        kind_counts[k] = kind_counts.get(k, 0) + 1
                    kinds = ", ".join([f"{k}×{v}" for k, v in sorted(kind_counts.items())])

                    link_name = (link_row or {}).get("name") or ""
                    owner_id = (link_row or {}).get("owner_tg_user_id")

                    # Укороченное описание причины (чтобы не слать огромные payload'ы)
                    cause = (es or "").strip()
                    if len(cause) > 220:
                        cause = cause[:220] + "…"

                    tg_note = (
                        "⚠️ Частичная отправка альбома в MAX\n"
                        f"Связка {link_id}" + (f" («{link_name}»)" if link_name else "") + "\n"
                        f"Пропущено {len(skipped)}/{len(attachments)} вложений ({kinds}).\n"
                        + (f"Причина: {cause}" if cause else "")
                    )

                    await notify_admin_throttled(f"max_album_partial_{link_id}", tg_note)
                    if owner_id:
                        with contextlib.suppress(Exception):
                            await bot.send_message(int(owner_id), tg_note)

# Если совсем ничего не отправили — пробрасываем исходную ошибку вверх,
                # чтобы сработали существующие алерты/учёт ошибок.
                if not sent_any:
                    raise e

                # Дальше код ожидает res с mid; если отправляли пачкой или по одному — mid может быть не нужен.
                res = {"message": {"body": {"mid": None}}}
            try:
                mid = ((((res or {}).get("message") or {}).get("body") or {}).get("mid"))
                if mid and items:
                    for m in items:
                        try:
                            save_tg_to_max(
                                link_id=int(link_id),
                                tg_msg_id=int(m.message_id),
                                max_mid=str(mid),
                            )
                        except Exception:
                            pass
            except Exception:
                pass

            _METRICS["max_send_ok"] += 1
            log.info("album: sent %d parts to %s", len(attachments), target_chat_id)

        except MaxSendError as e:
            _METRICS["max_send_err"] += 1
            log.error("album: MAX send failed: %s", e)
            await notify_admin_throttled(
                "max_send_failed",
                f"⚠️ Ошибка отправки альбома в MAX для связки {link_id}: {e}",
            )
            await _register_max_error(link_id, e)
        except Exception as e:
            _METRICS["max_send_err"] += 1
            log.exception("album: unexpected error: %s", e)
            await notify_admin_throttled(
                "mirror_unexpected",
                f"⚠️ Неожиданная ошибка зеркалирования альбома (link_id={link_id}): {e}",
            )
            await _register_max_error(link_id, e)


async def get_active_links_for_source(source_chat_id: int, link_type: str = "channel") -> List[dict]:
    return await cached_get_links_for_source(source_chat_id, link_type)


async def _max_send_with_optional_reply(
    chat_id: int,
    text: str,
    attachments: Optional[List[dict]],
    fmt: str,
    disable_link_preview: bool,
    reply_to_mid: Optional[str],
):
    # 1) Защита от пустого payload: нет ни текста, ни вложений
    if not (text and text.strip()) and not (attachments and len(attachments) > 0):
        log.info(
            "max_send: skip sending empty message to MAX (chat_id=%s)",
            chat_id,
        )
        return {}

    # 2) Ограничение длины текста для MAX (у них лимит 4000 символов)
    # На проде встречалась ошибка:
    #   Field 'request.text' size (...) must be at most 4000
    # Поэтому тут заранее подрезаем текст с небольшим запасом.
    MAX_TEXT_LIMIT = 3900  # небольшой запас, чтобы не попасть в ограничение
    _trimmed_original_len: Optional[int] = None

    if text and len(text) > MAX_TEXT_LIMIT:
        _trimmed_original_len = len(text)
        log.warning(
            "max_send: trimming text for MAX chat %s from %d to %d chars",
            chat_id,
            _trimmed_original_len,
            MAX_TEXT_LIMIT,
        )
        # простое обрезание; возможны разрывы HTML-тегов, но MAX это переживёт
        text = text[: MAX_TEXT_LIMIT - 1] + "…"

    # 3) Небольшой retry для ошибки attachment.not.ready (видео ещё не обработано)
    max_attempts = 3
    last_exc: Optional[Exception] = None

    for attempt in range(1, max_attempts + 1):
        try:
            if reply_to_mid:
                res = await max_send_message(
                    chat_id=chat_id,
                    text=text,
                    attachments=attachments or None,
                    fmt=fmt,
                    disable_link_preview=disable_link_preview,
                    reply_to_mid=reply_to_mid,
                )
            else:
                res = await max_send_message(
                    chat_id=chat_id,
                    text=text,
                    attachments=attachments or None,
                    fmt=fmt,
                    disable_link_preview=disable_link_preview,
                )

            # прокидываем наружу факт обрезки текста (для уведомления владельца/админов)
            if _trimmed_original_len is not None:
                try:
                    res = res or {}
                    res["_meta"] = res.get("_meta") or {}
                    res["_meta"]["trimmed_text"] = {
                        "original_len": int(_trimmed_original_len),
                        "sent_len": int(len(text or "")),
                    }
                except Exception:
                    pass

            return res
        except MaxSendError as e:
            s = str(e)
            # attachment.not.ready — MAX говорит "вложение ещё не готово"
            if "attachment.not.ready" in s and attempt < max_attempts:
                log.warning(
                    "max_send: attachment.not.ready for chat %s, "
                    "attempt %d/%d, retrying...",
                    chat_id,
                    attempt,
                    max_attempts,
                )
                # чуть-чуть ждём и пробуем ещё раз
                await asyncio.sleep(2 * attempt)
                last_exc = e
                continue

            # для всех остальных ошибок (или последней попытки) — отдаём наверх
            raise

    # теоретически сюда не дойдём, но на всякий случай:
    if last_exc:
        raise last_exc
    return {}


async def mirror_message(bot: Bot, msg: Message, link_row: dict):
    target_chat_id = int(link_row["target_chat_id"])
    platform = (link_row.get("target_platform") or "tg").lower()
    link_type = (link_row.get("link_type") or "channel").lower()

    plain, htmltxt, is_caption = get_text_and_html(msg)
    log.info(
        "mirror: target=%s platform=%s link_type=%s is_caption=%s has_text=%s",
        target_chat_id,
        platform,
        link_type,
        is_caption,
        bool(plain or htmltxt),
    )

    link_id = int(link_row["id"])

    # --- исключения ---
    excl = await aget_exclusions_for_link(link_id)
    if exclusions_hit(plain, excl):
        log.info("mirror: skipped by exclusion")
        return

    # --- правила замены ---
    rules = await aget_rules_for_link(link_id)
    log.info("mirror: rules_count=%d", len(rules))

    preview_disabled = disable_preview_from_source(msg)

    html_new, changed = apply_rules_to_html(htmltxt, rules) if rules else (htmltxt, False)
    log.info("mirror: changed=%s", changed)

    # --- вставка имени отправителя для чатов TG↔MAX ---
    if platform == "max" and link_type == "chat":
        sender_name = build_sender_name_from_tg(msg)
        if sender_name:
            name_html = f"<b><u>{html.escape(sender_name)}</u></b>"
            if changed:
                base_html = html_new
            else:
                base_html = htmltxt
            if base_html:
                base_html = name_html + "\n" + base_html
            else:
                base_html = name_html
            if changed:
                html_new = base_html
            else:
                htmltxt = base_html

    # --- зеркалирование в Telegram ---
    if platform == "tg":
        if not rules:
            # без правил — максимально близкое копирование
            if is_caption:
                await bot.copy_message(
                    target_chat_id,
                    msg.chat.id,
                    msg.message_id,
                    parse_mode=ParseMode.HTML,
                )
            else:
                await send_text(bot, target_chat_id, htmltxt, preview_disabled)
            return

        # с правилами — либо модифицированный текст, либо как есть
        if changed:
            if is_caption:
                await bot.copy_message(
                    target_chat_id,
                    msg.chat.id,
                    msg.message_id,
                    caption=html_new,
                    parse_mode=ParseMode.HTML,
                )
            else:
                await send_text(bot, target_chat_id, html_new, preview_disabled)
        else:
            if is_caption:
                await bot.copy_message(
                    target_chat_id,
                    msg.chat.id,
                    msg.message_id,
                    parse_mode=ParseMode.HTML,
                )
            else:
                await send_text(bot, target_chat_id, htmltxt, preview_disabled)

        return

    # --- зеркалирование в MAX ---
    if platform == "max":
        reply_to_mid: Optional[str] = None

        # --- поиск сообщения, на которое был reply ---
        if msg.reply_to_message:
            base_msg_id = int(msg.reply_to_message.message_id)

            rows = await aquery(
                "select max_mid from cross_message_map where link_id=%s and tg_msg_id=%s",
                (link_id, base_msg_id),
            )

            # fallback для альбомов: ищем в небольшом диапазоне id
            if (not rows) and getattr(msg.reply_to_message, "media_group_id", None):
                from_id = max(1, base_msg_id - 10)
                to_id = base_msg_id + 10
                rows = await aquery(
                    """
                    select max_mid
                    from cross_message_map
                    where link_id=%s
                      and tg_msg_id between %s and %s
                    order by id desc
                    limit 1
                    """,
                    (link_id, from_id, to_id),
                )

            if rows:
                row = rows[0]
                max_mid = row.get("max_mid") if isinstance(row, dict) else row[0]
                if max_mid:
                    reply_to_mid = str(max_mid)

        # --- альбомы ---
        if msg.media_group_id:
            key = f"{link_row['id']}::{msg.media_group_id}"
            buf = _ALBUM_BUF.get(key)
            if not buf:
                buf = {"items": [], "task": None}
                _ALBUM_BUF[key] = buf

            buf["items"].append(msg)

            # переносим flush на "от последнего сообщения"
            old_task = buf.get("task")
            if old_task and not old_task.done():
                old_task.cancel()

            async def _flush(local_key: str, local_buf: dict):
                try:
                    await asyncio.sleep(_ALBUM_DELAY_SEC)
                except asyncio.CancelledError:
                    return

                items = local_buf.get("items") or []
                local_buf["items"] = []
                local_buf["task"] = None

                if items:
                    try:
                        await _album_flush(link_row, items)
                    finally:
                        _ALBUM_BUF.pop(local_key, None)
                else:
                    _ALBUM_BUF.pop(local_key, None)

            buf["task"] = asyncio.create_task(_flush(key, buf))
            return

        # --- одиночное сообщение с/без вложения ---
        attachment: Optional[dict] = None
        try:
            attachment = await build_max_attachment_from_msg(msg)
        except TelegramBadRequest as e:
            # ключевой кейс: "Bad Request: invalid file_id" и подобные
            log.warning(
                "mirror: skip attachment due to TelegramBadRequest for msg %s: %s",
                getattr(msg, "message_id", None),
                e,
            )
            attachment = None
        except Exception as e:
            # любые другие ошибки построения вложения НЕ роняют апдейт
            log.exception(
                "mirror: build_max_attachment_from_msg failed for msg %s: %s",
                getattr(msg, "message_id", None),
                e,
            )
            attachment = None

        text_for_max = (html_new if changed else htmltxt) or ""
        text_for_max = text_for_max.replace("<u>", "<ins>").replace("</u>", "</ins>")

        # если нет ни текста, ни вложения — просто ничего не отправляем
        if not text_for_max and not attachment:
            log.info(
                "mirror: nothing to send for msg %s (empty text and no attachment)",
                getattr(msg, "message_id", None),
            )
            return

        link_sem = _get_link_sem(link_id)
        async with link_sem:
            try:
                res = await _max_send_with_optional_reply(
                    chat_id=target_chat_id,
                    text=text_for_max,
                    attachments=[attachment] if attachment else None,
                    fmt="html",
                    disable_link_preview=preview_disabled,
                    reply_to_mid=reply_to_mid,
                )
                if (res or {}).get("_meta", {}).get("trimmed_text"):
                    try:
                        await _notify_text_too_long_max(bot, link_row, int(res["_meta"]["trimmed_text"].get("original_len") or 0))
                    except Exception:
                        pass


                # сохраняем маппинг TG → MAX для reply
                try:
                    mid = ((((res or {}).get("message") or {}).get("body") or {}).get("mid"))
                    if mid:
                        save_tg_to_max(
                            link_id=int(link_id),
                            tg_msg_id=int(msg.message_id),
                            max_mid=str(mid),
                        )
                except Exception:
                    pass

                _METRICS["max_send_ok"] += 1
            except MaxSendError as e:
                _METRICS["max_send_err"] += 1
                log.error("mirror: MAX send failed: %s", e)

                s = str(e)
                # Читабельное уведомление при превышении лимита текста MAX (4000)
                if "Field 'request.text' size" in s and "4000" in s:
                    m = re.search(r"size \((\d+)\)", s)
                    orig_len = int(m.group(1)) if m else 0
                    await _notify_text_too_long_max(bot, link_row, orig_len or len(text_for_max or ""))
                    await notify_admin_throttled(
                        f"max_text_limit_{link_id}",
                        f"⚠️ MAX отклонил сообщение по лимиту текста (4000) для связки {link_id}: {s}",
                        min_interval_sec=600,
                    )
                else:
                    await notify_admin_throttled(
                        "max_send_failed",
                        f"⚠️ Ошибка отправки в MAX для связки {link_id}: {e}",
                    )

                await _register_max_error(link_id, e)
            except Exception as e:
                _METRICS["max_send_err"] += 1
                log.exception("mirror: unexpected error: %s", e)
                await notify_admin_throttled(
                    "mirror_unexpected",
                    f"⚠️ Неожиданная ошибка зеркалирования (link_id={link_id}): {e}",
                )
                await _register_max_error(link_id, e)

    else:
        log.warning("mirror: unknown target_platform=%s", platform)


@dp.channel_post(F.chat.type == ChatType.CHANNEL)
async def handle_channel_post(msg: Message):
    _METRICS["tg_updates"] += 1
    _METRICS["tg_channel_posts"] += 1
    src_chat_id = int(msg.chat.id)
    links = await get_active_links_for_source(src_chat_id, link_type="channel")
    if not links:
        return
    log.info("channel_post: source=%s links=%d", src_chat_id, len(links))

    for link_row in links:
        if (link_row.get("target_platform") or "tg").lower() == "tg":
            await mirror_message(bot, msg, link_row)
        elif (link_row.get("target_platform") or "tg").lower() == "max":
            await mirror_message(bot, msg, link_row)


@dp.message(F.chat.type.in_({ChatType.SUPERGROUP, ChatType.GROUP}))
async def handle_chat_message(msg: Message):
    _METRICS["tg_updates"] += 1
    _METRICS["tg_chat_msgs"] += 1
    src_chat_id = int(msg.chat.id)

    links = await get_active_links_for_source(src_chat_id, link_type="chat")
    if not links:
        return

    log.info("chat_message: source=%s links=%d", src_chat_id, len(links))

    for link_row in links:
        await mirror_message(bot, msg, link_row)


async def handle_update(request: web.Request):
    """
    Отвечаем Telegram мгновенно (200 OK), а тяжёлую обработку апдейта выполняем в фоне.
    Это снижает шанс 504/повторов при пересылке альбомов и больших файлов.
    """
    try:
        data = await request.json()
        update = Update.model_validate(data)
    except Exception as e:
        # на всякий случай: не заставляем Telegram ретраить бесконечно
        log.warning("handle_update: bad update payload: %s", e)
        return web.Response(text="ok")

    t = asyncio.create_task(_process_update(update))
    _track_task(t)
    return web.Response(text="ok")


def _get_real_ip(request: web.Request) -> Optional[str]:
    hdr = request.headers
    ip = hdr.get("X-Real-IP")
    if ip:
        return ip.strip()

    xff = hdr.get("X-Forwarded-For")
    if xff:
        return xff.split(",")[0].strip()

    return request.remote


async def yookassa_webhook(request: web.Request) -> web.Response:
    ip_str = _get_real_ip(request)
    if ip_str:
        try:
            ip_obj = ipaddress.ip_address(ip_str)
            if not any(ip_obj in net for net in _YK_IP_RANGES):
                log.warning(
                    "yookassa_webhook_ip_mismatch",
                    extra={"ip": ip_str},
                )
        except ValueError:
            log.warning("yookassa_webhook_ip_invalid", extra={"ip": ip_str})

    try:
        payload = await request.json()
    except Exception:
        payload = {}

    try:
        await asyncio.to_thread(handle_yookassa_webhook, payload)
    except Exception as e:
        log.exception("yookassa_webhook_failed: %s", e)
        return web.Response(status=500, text="error")

    try:
        obj = payload.get("object") or {}
        if obj.get("status") != "succeeded":
            return web.Response(text="ok")

        meta = obj.get("metadata") or {}
        link_id = int(meta.get("link_id"))
        tg_user_id = int(meta.get("tg_user_id"))
    except Exception:
        return web.Response(text="ok")

    try:
        rows = await aquery(
            "select paid_until from channel_links where id=%s",
            (link_id,),
        )
        if not rows:
            return web.Response(text="ok")

        paid_until = rows[0]["paid_until"]
        if paid_until is None:
            return web.Response(text="ok")

        dt = paid_until
        if getattr(dt, "tzinfo", None) is None:
            dt = dt.replace(tzinfo=timezone.utc)
        dt_local = dt.astimezone(timezone.utc)
        text_date = dt_local.strftime("%d.%m.%Y %H:%M (UTC)")

        text = (
            "✅ Оплата подписки успешно проведена.\n"
            f"Подписка теперь активна до <b>{text_date}</b>.\n\n"
            "Вы находитесь в меню настроек связки."
        )

        await bot.send_message(
            tg_user_id,
            text,
            reply_markup=kb_link_menu(link_id),
        )
    except Exception as e:
        log.exception("yookassa_webhook_notify_failed: %s", e)

    return web.Response(text="ok")


async def on_startup(app: web.Application):
    alerts_set_bot(bot)
    alerts_set_recipients(ADMIN_IDS)

    with db() as conn, conn.cursor() as cur:
        from app.migrations import apply_migrations
        apply_migrations(cur)

    base = Cfg.PUBLIC_BASE_URL.rstrip("/")
    secret = Cfg.WEBHOOK_SECRET
    url = f"{base}/tg/{secret}"

    if USE_CLOUD_WEBHOOK:
        with contextlib.suppress(Exception):
            await bot.delete_webhook(drop_pending_updates=True)

        await bot.set_webhook(
            url,
            secret_token=secret,
            drop_pending_updates=True,
            allowed_updates=[
                "message",
                "callback_query",
                "channel_post",
                "edited_channel_post",
                "my_chat_member",
                "chat_member",
            ],
        )
        log.info("Webhook set to %s", url)

    if YK_WEBHOOK_SECRET:
        yk_url = f"{base}/yookassa/{YK_WEBHOOK_SECRET}"
        log.info("YooKassa webhook endpoint is %s", yk_url)
    else:
        log.warning("YooKassa webhook secret is empty: set YOOKASSA_WEBHOOK or WEBHOOK_SECRET")

    if start_max_inbox:
        try:
            app["max_inbox"], app["max_inbox_task"] = await start_max_inbox(bot)
            log.info("MAX inbox worker started")
        except Exception as e:
            log.warning("MAX inbox worker did not start: %s", e)

    t = MC.start_cleaner_task()
    if t:
        app["media_cleaner_task"] = t

    t = start_autopay_task()
    if t:
        app["autopay_task"] = t
        log.info("Autopay worker started")
    t = start_tg_big_cleaner_task()
    if t:
        app["tg_big_cleaner_task"] = t

    # уведомления за 24 часа до окончания триала/оплаты для связок без автоплатежа
    try:
        t = asyncio.create_task(expiry_notifier_worker(bot))
        app["expiry_notifier_task"] = t
        log.info("Expiry notifier worker started")
    except Exception as e:
        log.warning("Expiry notifier worker did not start: %s", e)

async def on_cleanup(app: web.Application):
    worker = app.get("max_inbox")
    task = app.get("max_inbox_task")
    if worker:
        with contextlib.suppress(Exception):
            await worker.close()
    if task:
        task.cancel()
        with contextlib.suppress(Exception):
            await task

    task = app.get("autopay_task")
    if task:
        task.cancel()
        with contextlib.suppress(Exception):
            await task

    task = app.get("expiry_notifier_task")
    if task:
        task.cancel()
        with contextlib.suppress(Exception):
            await task

    with contextlib.suppress(Exception):
        t = app.get("media_cleaner_task")
        if t:
            t.cancel()
            await t

    # аккуратно отменяем фоновые задачи (если есть), чтобы не оставлять висящие обработчики
    for t in list(_BG_TASKS):
        t.cancel()
    for t in list(_BG_TASKS):
        with contextlib.suppress(Exception):
            await t
    _BG_TASKS.clear()

    with contextlib.suppress(Exception):
        await close_http_sessions()
    # закрываем основную HTTP-сессию aiogram бота
    with contextlib.suppress(Exception):
        await bot.session.close()

    # закрываем отдельного бота (если был создан)
    if bot_local:
        with contextlib.suppress(Exception):
            await bot_local.session.close()

    task = app.get("tg_big_cleaner_task")
    if task:
        task.cancel()
        with contextlib.suppress(Exception):
            await task

async def healthz(request: web.Request) -> web.Response:
    return web.Response(text="ok")


async def readyz(request: web.Request) -> web.Response:
    try:
        with db() as conn, conn.cursor() as cur:
            cur.execute("select 1")
            cur.fetchone()
    except Exception as e:
        return web.Response(status=500, text=f"pg: {e}")

    try:
        from app.dedup_store import _s3_client, S3_BUCKET
        s3 = _s3_client()
        try:
            s3.head_object(Bucket=S3_BUCKET, Key=_S3_CANARY_KEY)
        except Exception:
            with contextlib.suppress(Exception):
                s3.put_object(Bucket=S3_BUCKET, Key=_S3_CANARY_KEY, Body=b"ok", ContentType="text/plain")
                s3.head_object(Bucket=S3_BUCKET, Key=_S3_CANARY_KEY)
    except Exception:
        pass

    return web.Response(text="ok")


async def metrics(request: web.Request) -> web.Response:
    return web.json_response(_METRICS)


def make_app():
    app = web.Application()
    app.router.add_get("/healthz", healthz)
    app.router.add_get("/readyz", readyz)
    app.router.add_get("/metrics", metrics)
    app.router.add_post(f"/tg/{Cfg.WEBHOOK_SECRET}", handle_update)
    app.router.add_post(f"/yookassa/{YK_WEBHOOK_SECRET}", yookassa_webhook)
    app.on_startup.append(on_startup)
    app.on_cleanup.append(on_cleanup)
    return app


if __name__ == "__main__":
    web.run_app(make_app(), port=Cfg.APP_PORT)

