import os
import threading
import time
import logging
from typing import Dict, List, Optional

from app.db import db, aquery

log = logging.getLogger(__name__)

# TTL для кэша правил/исключений.
# 0 или отрицательное значение = без TTL (кэш живёт до инвалидирования/рестарта).
LINK_CACHE_TTL_SEC = int(os.getenv("LINK_CACHE_TTL_SEC", "600"))

_RULES_CACHE: Dict[int, List[dict]] = {}
_RULES_TS: Dict[int, float] = {}

_EXCL_CACHE: Dict[int, List[str]] = {}
_EXCL_TS: Dict[int, float] = {}

_LOCK = threading.Lock()


def _now_mono() -> float:
    return time.monotonic()


def _is_fresh(ts: Optional[float]) -> bool:
    """
    Проверка, что отметка времени ещё не устарела.
    При LINK_CACHE_TTL_SEC <= 0 TTL по сути отключён: считаем всегда свежим.
    """
    if ts is None:
        return False
    if LINK_CACHE_TTL_SEC <= 0:
        return True
    return (_now_mono() - ts) < LINK_CACHE_TTL_SEC


# ---- Правила (rules) ----
def get_rules_for_link(link_id: int) -> List[dict]:
    """
    Синхронное получение правил для link_id.
    Используется редко (основной путь — aget_rules_for_link),
    но пригодно для служебных задач.
    """
    with _LOCK:
        cached = _RULES_CACHE.get(link_id)
        ts = _RULES_TS.get(link_id)
        if cached is not None and _is_fresh(ts):
            return cached

    # читаем из БД (синхронно)
    with db() as conn, conn.cursor() as cur:
        cur.execute(
            """
            select id, link_id, idx, type, data
              from rules
             where link_id=%s
             order by idx
            """,
            (link_id,),
        )
        rows = cur.fetchall() or []

    with _LOCK:
        _RULES_CACHE[link_id] = rows
        _RULES_TS[link_id] = _now_mono()

    return rows


async def aget_rules_for_link(link_id: int) -> List[dict]:
    """
    Асинхронное получение правил.
    Основной путь, используемый в обработке сообщений.
    """
    with _LOCK:
        cached = _RULES_CACHE.get(link_id)
        ts = _RULES_TS.get(link_id)
        if cached is not None and _is_fresh(ts):
            return cached

    # нет кэша или устарел — читаем из БД асинхронно
    rows = await aquery(
        """
        select id, link_id, idx, type, data
          from rules
         where link_id=%s
         order by idx
        """,
        (link_id,),
    ) or []

    with _LOCK:
        _RULES_CACHE[link_id] = rows
        _RULES_TS[link_id] = _now_mono()

    return rows


# ---- Исключения (link_exclusions) ----
def get_exclusions_for_link(link_id: int) -> List[str]:
    """
    Синхронное получение списка токенов-исключений для link_id.
    """
    with _LOCK:
        cached = _EXCL_CACHE.get(link_id)
        ts = _EXCL_TS.get(link_id)
        if cached is not None and _is_fresh(ts):
            return cached

    with db() as conn, conn.cursor() as cur:
        cur.execute(
            """
            select token
              from link_exclusions
             where link_id=%s
             order by id
            """,
            (link_id,),
        )
        rows = cur.fetchall() or []
        tokens = [r["token"] for r in rows]

    with _LOCK:
        _EXCL_CACHE[link_id] = tokens
        _EXCL_TS[link_id] = _now_mono()

    return tokens


async def aget_exclusions_for_link(link_id: int) -> List[str]:
    """
    Асинхронное получение списка токенов-исключений.
    """
    with _LOCK:
        cached = _EXCL_CACHE.get(link_id)
        ts = _EXCL_TS.get(link_id)
        if cached is not None and _is_fresh(ts):
            return cached

    rows = await aquery(
        """
        select token
          from link_exclusions
         where link_id=%s
         order by id
        """,
        (link_id,),
    ) or []
    tokens = [r["token"] for r in rows]

    with _LOCK:
        _EXCL_CACHE[link_id] = tokens
        _EXCL_TS[link_id] = _now_mono()

    return tokens


# ---- Инвалидация ----
def invalidate_rules_for_link(link_id: int) -> None:
    """
    Полностью сбрасывает кэш правил для указанной связки.
    Вызывается после добавления/удаления/редактирования правил.
    """
    with _LOCK:
        _RULES_CACHE.pop(link_id, None)
        _RULES_TS.pop(link_id, None)


def invalidate_exclusions_for_link(link_id: int) -> None:
    """
    Полностью сбрасывает кэш исключений для указанной связки.
    Вызывается после добавления/удаления правила исключения.
    """
    with _LOCK:
        _EXCL_CACHE.pop(link_id, None)
        _EXCL_TS.pop(link_id, None)


def invalidate_all_for_link(link_id: int) -> None:
    """
    Сбрасывает и правила, и исключения для связки.
    Используется, например, при удалении связки.
    """
    with _LOCK:
        _RULES_CACHE.pop(link_id, None)
        _RULES_TS.pop(link_id, None)
        _EXCL_CACHE.pop(link_id, None)
        _EXCL_TS.pop(link_id, None)

