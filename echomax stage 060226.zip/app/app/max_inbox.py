#app/app/max_inbox.py
import os
import io
import asyncio
import logging
import html
import contextlib
import tempfile
import shutil
import time
import json
from typing import Any, Dict, List, Optional, Tuple

import aiohttp
from aiogram import Bot
from aiogram.types import (
    LinkPreviewOptions,
    InputMediaPhoto,
    InputMediaVideo,
    BufferedInputFile,
    ReplyParameters,
)

from app.db import aquery
from app.link_cache import aget_rules_for_link, aget_exclusions_for_link
from app.max_send import (
    get_max_http_session,
    MAX_API_BASE,
    MAX_BOT_TOKEN,
    send_text_to_chat,
)
from app.message_map import save_max_to_tg
from app.alerts import notify_admin_throttled  # <--- добавили импорт

log = logging.getLogger(__name__)

_UPDATES_TIMEOUT = int(os.getenv("MAX_INBOX_TIMEOUT", "30"))
_UPDATES_LIMIT = int(os.getenv("MAX_INBOX_LIMIT", "100"))
_DEFAULT_TYPES = ["message_created", "message_edited"]
_UPDATES_TYPES = [
    t.strip()
    for t in os.getenv("MAX_INBOX_TYPES", ",".join(_DEFAULT_TYPES)).split(",")
    if t.strip()
]

_TG_CAPTION_LIMIT = 1024
_DL_MAX_BYTES = int(os.getenv("MAX_INBOX_DOWNLOAD_MAX_BYTES", str(64 * 1024 * 1024)))
_VIDEO_FALLBACK_DL_MAX = int(os.getenv("MAX_INBOX_VIDEO_FALLBACK_DL_MAX", str(25 * 1024 * 1024)))
_FORCE_VOICE = os.getenv("MAX_INBOX_FORCE_VOICE", "0") not in ("0", "false", "no", "")
_FFMPEG_BIN = os.getenv("FFMPEG_BIN", "ffmpeg")

_MAX_ROUTER_TTL = float(os.getenv("MAX_ROUTER_CACHE_TTL", "5.0"))
_MAX_ROUTER_CACHE: Dict[int, Tuple[List[dict], float]] = {}

# --- кеш определения типа чата (группа / диалог) ---
_CHAT_KIND_TTL = float(os.getenv("MAX_CHAT_KIND_TTL", "600"))  # секунды
# value: (is_group: bool, ts: float)
_CHAT_KIND_CACHE: Dict[int, Tuple[bool, float]] = {}


async def _is_max_group_chat(chat_id: int) -> bool:
    """
    Возвращает True, если chat_id выглядит как *групповой* чат MAX.

    Логика:
    - пробуем GET /chats/{chatId}/members (эндпоинт только для групп);
    - если статус 200 -> считаем группой;
    - 404/400 и прочие «не ок» → считаем НЕ группой (диалог), чтобы визитка
      могла отправляться только в личке;
    - при сетевых ошибках консервативно считаем группой (чтобы не спамить).
    """
    now = time.time()
    cached = _CHAT_KIND_CACHE.get(chat_id)
    if cached is not None:
        val, ts = cached
        if now - ts < _CHAT_KIND_TTL:
            return val

    sess = get_max_http_session()
    headers = {"Authorization": MAX_BOT_TOKEN} if MAX_BOT_TOKEN else {}
    url = f"{MAX_API_BASE}/chats/{chat_id}/members"
    params = {"count": "1"}

    try:
        async with sess.get(url, headers=headers, params=params) as resp:
            txt = await resp.text()
            if resp.status == 200:
                log.debug("MAX inbox: chat %s detected as GROUP (members ok)", chat_id)
                _CHAT_KIND_CACHE[chat_id] = (True, now)
                return True

            # 404/400 и т.п. – считаем, что это не групповой чат (скорее диалог)
            log.debug(
                "MAX inbox: chat %s members resp %s: %s; treat as NOT-GROUP",
                chat_id,
                resp.status,
                txt[:200],
            )
            _CHAT_KIND_CACHE[chat_id] = (False, now)
            return False
    except Exception as e:
        # если вообще не смогли определить – лучше не слать визитку, чтобы не спамить группы
        log.warning(
            "MAX inbox: failed to detect chat kind for %s: %s (default: GROUP)",
            chat_id,
            e,
        )
        _CHAT_KIND_CACHE[chat_id] = (True, now)
        return True



class MediaPack:
    def __init__(self) -> None:
        self.photos: List[str] = []
        self.videos_urls: List[str] = []
        self.video_bytes: Optional[bytes] = None
        self.video_filename: Optional[str] = None
        self.docs: List[Dict[str, Any]] = []
        self.audios: List[Dict[str, Any]] = []

    def album_len(self) -> int:
        return len(self.photos) + len(self.videos_urls)

    def short_stats(self) -> str:
        return (
            f"photos={len(self.photos)} "
            f"videos={len(self.videos_urls)} "
            f"docs={len(self.docs)} "
            f"audios={len(self.audios)}"
        )


class MaxInboxWorker:
    def __init__(self, bot: Bot) -> None:
        self.bot = bot
        self._stopping = asyncio.Event()
        self._task: Optional[asyncio.Task] = None
        self._marker: Optional[int] = None
        self._poll_num: int = 0
        # новое состояние для backoff
        self._error_streak: int = 0
        self._backoff_sec: float = 1.0

    async def close(self) -> None:
        self._stopping.set()
        if self._task:
            self._task.cancel()
            with contextlib.suppress(Exception):
                await self._task

    async def run(self) -> None:
        sess = get_max_http_session()
        headers = {"Authorization": MAX_BOT_TOKEN} if MAX_BOT_TOKEN else {}
        params_base: Dict[str, str] = {
            "timeout": str(max(0, min(_UPDATES_TIMEOUT, 90))),
            "limit": str(max(1, min(_UPDATES_LIMIT, 1000))),
        }
        if _UPDATES_TYPES:
            params_base["types"] = ",".join(_UPDATES_TYPES)

        log.info("MAX inbox: starting long-poll loop, types=%s", params_base.get("types"))

        while not self._stopping.is_set():
            params = dict(params_base)
            if self._marker is not None:
                params["marker"] = str(self._marker)

            try:
                async with sess.get(f"{MAX_API_BASE}/updates", params=params, headers=headers) as resp:
                    txt = await resp.text()

                    if resp.status == 405:
                        log.warning(
                            "MAX inbox: /updates -> 405 NotAllowed (включён WebHook). Останавливаю воркер."
                        )
                        # отправим алерт админам, т.к. это постоянная ошибка конфигурации
                        try:
                            await notify_admin_throttled(
                                "max_inbox_405",
                                "⚠️ MAX inbox: /updates вернул 405 NotAllowed. "
                                "Похоже, включён WebHook на стороне MAX. Воркер остановлен.",
                            )
                        except Exception:
                            log.exception("MAX inbox: failed to notify admins about 405")
                        return

                    if resp.status == 401:
                        log.error("MAX inbox: 401 Unauthorized. Проверьте MAX_BOT_TOKEN")
                        await self._handle_poll_error("401 Unauthorized", fixed_delay=5.0)
                        continue

                    if resp.status >= 300:
                        log.warning("MAX inbox: bad response %s: %s", resp.status, txt[:500])
                        await self._handle_poll_error(f"HTTP {resp.status}")
                        continue

                    try:
                        data = await resp.json()
                    except Exception:
                        import json as _json
                        try:
                            data = _json.loads(txt)
                        except Exception:
                            log.warning("MAX inbox: non-JSON response: %s", txt[:400])
                            await self._handle_poll_error("non-JSON response")
                            continue
            except asyncio.CancelledError:
                log.info("MAX inbox: cancelled")
                return
            except asyncio.TimeoutError:
                # Для long-poll таймаут чтения — нормальная ситуация (нет апдейтов/сеть).
                # Не считаем это ошибкой и не увеличиваем error_streak, чтобы не спамить логами.
                log.debug("MAX inbox: poll timeout (no updates yet)")
                continue
            except Exception as e:
                # логируем traceback только на первой ошибке подряд, чтобы не спамить
                exc_info_flag = (self._error_streak == 0)
                await self._handle_poll_error("exception", exc=e, exc_info=exc_info_flag)
                continue

            # если мы сюда дошли — poll прошёл успешно
            self._error_streak = 0
            self._backoff_sec = 1.0

            updates = (data or {}).get("updates") or []
            marker = (data or {}).get("marker")
            if marker is not None:
                try:
                    self._marker = int(marker)
                except Exception:
                    self._marker = None

            self._poll_num += 1
            log.info(
                "MAX inbox: poll ok #%d: count=%d, marker=%s",
                self._poll_num,
                len(updates),
                self._marker,
            )

            if not updates:
                continue

            for upd in updates:
                with contextlib.suppress(Exception):
                    await self._handle_update(upd)

    async def _handle_poll_error(
        self,
        label: str,
        exc: Optional[Exception] = None,
        fixed_delay: Optional[float] = None,
        exc_info: bool = False,
    ) -> None:
        """
        Обработчик ошибок long-poll запроса к MAX /updates:
        - считает подряд идущие ошибки;
        - даёт экспоненциальный backoff до 16 сек;
        - шлёт алерт после 6 подряд неудач.
        """
        self._error_streak += 1

        if fixed_delay is not None:
            delay = float(fixed_delay)
        else:
            if self._backoff_sec < 1.0:
                self._backoff_sec = 1.0
            delay = float(self._backoff_sec)
            # рост до 16 секунд максимум
            self._backoff_sec = min(16.0, self._backoff_sec * 2.0)

        if exc:
            log.warning(
                "MAX inbox: poll error (%s), streak=%d, sleep=%.1fs: %s",
                label,
                self._error_streak,
                delay,
                repr(exc),
                exc_info=exc_info,
            )
        else:
            log.warning(
                "MAX inbox: poll error (%s), streak=%d, sleep=%.1fs",
                label,
                self._error_streak,
                delay,
                exc_info=exc_info,
            )

        # алерт после 6 подряд ошибок
        if self._error_streak == 6:
            try:
                await notify_admin_throttled(
                    "max_inbox_poll_error",
                    f"⚠️ MAX inbox: {self._error_streak} ошибок подряд при poll /updates. "
                    f"Последняя: {label}{': ' + repr(exc) if exc else ''}",
                )
            except Exception:
                log.exception("MAX inbox: failed to notify admins about poll errors")

        await asyncio.sleep(delay)

    async def _handle_update(self, upd: Dict[str, Any]) -> None:
        # по swagger: discriminator propertyName = update_type
        utype = (upd.get("update_type") or "").lower()
        if utype not in ("message_created", "message_edited"):
            return

        msg = upd.get("message") or {}
        recipient = msg.get("recipient") or {}
        chat_id = recipient.get("chat_id")
        if not chat_id:
            return

        sender = msg.get("sender") or {}
        if sender.get("is_bot"):
            return

        # Пытаемся понять, является ли чат личным диалогом с ботом.
        # В MAX удобного флага "private"/"group" в апдейте нет, поэтому используем
        # простую эвристику: в личке chat_id совпадает с id отправителя.
        sender_id = sender.get("id")
        is_private_dialog = False
        try:
            if sender_id is not None and chat_id is not None:
                is_private_dialog = int(sender_id) == int(chat_id)
        except Exception:
            # На всякий случай: при любой ошибке считаем, что это НЕ личка,
            # чтобы не спамить визиткой в чаты.
            is_private_dialog = False

        body = msg.get("body") or {}
        text = body.get("text") or ""
        markup = body.get("markup") or []
        attachments = body.get("attachments") or []

        htmltxt = max_markup_to_html(text, markup)

        # асинхронно получаем связанные TG-чаты
        links = await resolve_tg_targets_for_max_chat(int(chat_id))

        # --- Автоответ-визитка в MAX, если чат не участвует ни в одной связке ---
        # Условия:
        # - новое сообщение (message_created);
        # - живой пользователь (sender.is_bot уже отфильтрован выше);
        # - чат не привязан ни к одной связке (links пустой);
        # - чат НЕ является групповым (визитку шлём ТОЛЬКО в личные диалоги).
        if not links and utype == "message_created":
            # сначала определяем тип чата
            is_group = await _is_max_group_chat(int(chat_id))
            if is_group:
                log.info(
                    "MAX inbox: no links for chat %s but it is GROUP -> skip intro",
                    chat_id,
                )
                return

            # это не group (считаем личным диалогом) – можно слать визитку
            if text or attachments:
                reply_text = (
                    "Добрый день! Я бот EchoMAX для автопостинга из Telegram в ваш канал в мессенджере MAX.\n"
                    "Также я могу дублировать чаты между мессенджерами. Вся настройка происходит в боте Telegram. "
                    "Пожалуйста начните с ним диалог по ссылке https://t.me/tgechomax_bot"
                )
                try:
                    await send_text_to_chat(
                        chat_id=int(chat_id),
                        text=reply_text,
                        fmt="text",
                        disable_link_preview=False,
                        reply_to_mid=None,
                    )
                    log.info(
                        "MAX inbox: sent intro reply to PRIVATE chat %s (no links configured)",
                        chat_id,
                    )
                except Exception as e:
                    log.warning(
                        "MAX inbox: failed to send intro reply to PRIVATE chat %s: %s",
                        chat_id,
                        e,
                    )
            else:
                log.info(
                    "MAX inbox: no links for PRIVATE chat %s and empty body (skip intro reply)",
                    chat_id,
                )
            return

        # Если связок нет и это не случай для автоответа — просто выходим, как раньше
        if not links:
            log.info("MAX inbox: no TG targets matched for MAX chat %s", chat_id)
            return

        sender_name = build_sender_name(sender)
        media = await collect_media_from_attachments(attachments)

        # reply-инфа приходит в body.link или message.link
        link_obj = (body.get("link") or msg.get("link") or {}) or {}
        # текущий mid берём из body.mid (см. swagger MessageBody.mid)
        current_mid = body.get("mid")

        for lk in links:
            try:
                final_html = htmltxt
                if lk["link_type"] == "chat" and sender_name:
                    name_html = f"<b><u>{html.escape(sender_name)}</u></b>"
                    if final_html:
                        final_html = name_html + "\n" + final_html
                    else:
                        final_html = name_html

                link_id = int(lk["id"])
                excl = await aget_exclusions_for_link(link_id)
                if exclusions_hit(text, excl):
                    log.info("MAX inbox: skipped by exclusion (link=%s)", link_id)
                    continue

                rules = await aget_rules_for_link(link_id)
                if rules and final_html:
                    # используем тот же движок правил, но локальную версию,
                    # чтобы не импортировать app.main и не создавать второй Dispatcher
                    final_html, _ = apply_rules_to_html(final_html, rules)

                # найдём родителя в TG (если это reply в MAX)
                reply_to_id: Optional[int] = None
                try:
                    ltype = (link_obj.get("type") or "").lower()
                    if ltype == "reply":
                        reply_mid = link_obj.get("mid") or ((link_obj.get("message") or {}).get("mid"))
                        if reply_mid:
                            rows = await aquery(
                                "select tg_msg_id from cross_message_map where link_id=%s and max_mid=%s",
                                (link_id, str(reply_mid)),
                            )
                            if rows:
                                row = rows[0]
                                tg_msg_id = row.get("tg_msg_id") if isinstance(row, dict) else row[0]
                                if tg_msg_id:
                                    reply_to_id = int(tg_msg_id)
                except Exception:
                    reply_to_id = None

                sent = await self._send_to_tg(
                    chat_id=int(lk["dest_tg_chat_id"]),
                    text_html=final_html,
                    media=media,
                    reply_to_id=reply_to_id,
                )
                log.info(
                    "MAX inbox: sent to TG chat %s via link %s (mode=%s) media=%s reply_to=%s",
                    lk["dest_tg_chat_id"],
                    link_id,
                    lk["mode"],
                    media.short_stats(),
                    reply_to_id,
                )

                # сохраним соответствие MAX mid → TG message_id
                try:
                    if current_mid and sent:
                        save_max_to_tg(
                            link_id=int(link_id),
                            max_mid=str(current_mid),
                            tg_msg_id=int(sent.message_id),
                        )
                except Exception:
                    pass

            except Exception as e:
                log.exception("MAX inbox: send failed for link %s: %s", lk.get("id"), e)

    async def _send_to_tg(
        self,
        chat_id: int,
        text_html: str,
        media: "MediaPack",
        reply_to_id: Optional[int] = None,
    ):
        caption = truncate_caption(text_html, _TG_CAPTION_LIMIT) if text_html else None

        async def _call(method, *args, **kwargs):
            if reply_to_id:
                try:
                    kwargs["reply_parameters"] = ReplyParameters(message_id=reply_to_id)
                    return await method(*args, **kwargs)
                except TypeError:
                    kwargs.pop("reply_parameters", None)
                    kwargs["reply_to_message_id"] = reply_to_id
                    return await method(*args, **kwargs)
            return await method(*args, **kwargs)

        last_msg = None

        # если есть "альбом" — отправим группой
        if media.album_len() >= 2:
            group: List[object] = []
            first_caption_set = False

            for url in media.photos:
                if not first_caption_set and caption:
                    group.append(InputMediaPhoto(media=url, caption=caption, parse_mode="HTML"))
                    first_caption_set = True
                else:
                    group.append(InputMediaPhoto(media=url))
                if len(group) >= 10:
                    break

            if len(group) < 10:
                for url in media.videos_urls:
                    if not first_caption_set and caption:
                        group.append(InputMediaVideo(media=url, caption=caption, parse_mode="HTML"))
                        first_caption_set = True
                    else:
                        group.append(InputMediaVideo(media=url))
                    if len(group) >= 10:
                        break

            if group:
                res = await _call(self.bot.send_media_group, chat_id, media=group)
                if caption is None and text_html:
                    await _call(
                        self.bot.send_message,
                        chat_id,
                        text_html,
                        link_preview_options=LinkPreviewOptions(is_disabled=False),
                    )
                return res[0] if res else None

        # одиночные медиа
        if media.photos:
            last_msg = await _call(
                self.bot.send_photo,
                chat_id,
                media.photos[0],
                caption=caption,
                parse_mode="HTML" if caption else None,
            )
            caption = None

        if media.videos_urls:
            url = media.videos_urls[0]
            try:
                last_msg = await _call(
                    self.bot.send_video,
                    chat_id,
                    url,
                    caption=caption,
                    parse_mode="HTML" if caption else None,
                )
                caption = None
            except Exception as e:
                log.warning("MAX inbox: send_video by URL failed, try download fallback: %s", e)
                if media.video_bytes is not None:
                    vf = BufferedInputFile(media.video_bytes, filename=media.video_filename or "video.mp4")
                    last_msg = await _call(
                        self.bot.send_video,
                        chat_id,
                        vf,
                        caption=caption,
                        parse_mode="HTML" if caption else None,
                    )
                    caption = None

        for doc in media.docs:
            bf = BufferedInputFile(doc["data"], filename=doc.get("filename") or "file.bin")
            last_msg = await _call(
                self.bot.send_document,
                chat_id,
                bf,
                caption=caption,
                parse_mode="HTML" if caption else None,
            )
            caption = None

        for au in media.audios:
            data = au["data"]
            fname = au.get("filename") or ("voice.ogg" if au.get("is_voice") else "audio.ogg")
            bf = BufferedInputFile(data, filename=fname)
            if au.get("is_voice"):
                last_msg = await _call(
                    self.bot.send_voice,
                    chat_id,
                    bf,
                    caption=caption,
                    parse_mode="HTML" if caption else None,
                )
            else:
                last_msg = await _call(
                    self.bot.send_audio,
                    chat_id,
                    bf,
                    caption=caption,
                    parse_mode="HTML" if caption else None,
                )
            caption = None

        if last_msg is None and text_html:
            last_msg = await _call(
                self.bot.send_message,
                chat_id,
                text_html,
                link_preview_options=LinkPreviewOptions(is_disabled=False),
            )

        return last_msg


async def collect_media_from_attachments(atts: List[Dict[str, Any]]) -> "MediaPack":
    pack = MediaPack()
    if not atts:
        return pack

    sess = get_max_http_session()

    async def resolve_video_url(payload: Dict[str, Any]) -> Optional[str]:
        url = (payload or {}).get("url")
        if url:
            return url
        token = (payload or {}).get("token")
        if not token:
            return None
        data: Optional[Dict[str, Any]] = None
        headers = {"Authorization": MAX_BOT_TOKEN} if MAX_BOT_TOKEN else {}
        try:
            async with sess.get(f"{MAX_API_BASE}/videos/{token}", headers=headers) as resp:
                txt = await resp.text()
                if resp.status != 200:
                    log.warning("MAX inbox: /videos/%s -> %s %s", token, resp.status, txt[:200])
                    return None
                try:
                    data = await resp.json()
                except Exception:
                    import json as _json
                    try:
                        data = _json.loads(txt)
                    except Exception:
                        log.warning("MAX inbox: non-JSON /videos response: %s", txt[:200])
                        return None
        except Exception as e:
            log.warning("MAX inbox: resolve video token failed: %s", e)
            return None

        urls = (data or {}).get("urls") or {}
        for key in ("mp4_720", "mp4_480", "mp4_360", "mp4"):
            u = urls.get(key)
            if u:
                return u
        return None

    async def download_bytes(
        url: str, max_bytes: int, filename_hint: str = "file.bin"
    ) -> Tuple[Optional[bytes], str, Optional[str]]:
        headers = {"Authorization": MAX_BOT_TOKEN} if MAX_BOT_TOKEN else {}
        try:
            async with sess.get(url, headers=headers) as resp:
                if resp.status != 200:
                    txt = await resp.text()
                    log.warning("MAX inbox: download failed %s (%s): %s", url, resp.status, txt[:200])
                    return None, filename_hint, resp.headers.get("Content-Type")
                ctype = resp.headers.get("Content-Type")
                fname = filename_from_headers(resp.headers) or filename_from_url(url) or filename_hint
                total = 0
                chunks: List[bytes] = []
                async for chunk in resp.content.iter_chunked(65536):
                    if not chunk:
                        break
                    total += len(chunk)
                    if total > max_bytes:
                        log.warning(
                            "MAX inbox: download too large: %s > %s (%s)",
                            total,
                            max_bytes,
                            url,
                        )
                        return None, fname, ctype
                    chunks.append(chunk)
                return b"".join(chunks), fname, ctype
        except Exception as e:
            log.warning("MAX inbox: download error %s: %s", url, e)
            return None, filename_hint, None

    def filename_from_headers(h) -> Optional[str]:
        try:
            cd = h.get("Content-Disposition") or ""
            import re

            m = re.search(r"filename\*=UTF-8''([^;]+)", cd)
            if m:
                from urllib.parse import unquote

                return unquote(m.group(1))
            m = re.search(r'filename="([^"]+)"', cd)
            if m:
                return m.group(1)
            m = re.search(r"filename=([^;]+)", cd)
            if m:
                return m.group(1)
        except Exception:
            return None
        return None

    def filename_from_url(u: str) -> Optional[str]:
        try:
            from urllib.parse import urlparse

            p = urlparse(u)
            base = os.path.basename(p.path)
            return base or None
        except Exception:
            return None

    def is_probably_voice(fname: Optional[str], content_type: Optional[str]) -> bool:
        f = (fname or "").lower()
        ct = (content_type or "").lower()
        return f.endswith(".ogg") or f.endswith(".opus") or "ogg" in ct or "opus" in ct

    async def ffmpeg_convert_to_opus_ogg(src_bytes: bytes) -> Optional[bytes]:
        tmpdir = tempfile.mkdtemp(prefix="mxv_")
        inpath = os.path.join(tmpdir, "in")
        outpath = os.path.join(tmpdir, "out.ogg")
        try:
            with open(inpath, "wb") as f:
                f.write(src_bytes)
            proc = await asyncio.create_subprocess_exec(
                _FFMPEG_BIN,
                "-y",
                "-i",
                inpath,
                "-vn",
                "-ac",
                "1",
                "-c:a",
                "libopus",
                "-b:a",
                "24k",
                outpath,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            _, stderr = await proc.communicate()
            if proc.returncode != 0:
                log.warning(
                    "ffmpeg convert failed rc=%s stderr=%s",
                    proc.returncode,
                    (stderr or b"")[:400].decode(errors="ignore"),
                )
                return None
            with open(outpath, "rb") as f:
                return f.read()
        except Exception as e:
            log.warning("ffmpeg convert exception: %s", e)
            return None
        finally:
            with contextlib.suppress(Exception):
                shutil.rmtree(tmpdir)

    for a in atts:
        atype = (a.get("type") or "").lower()
        payload = a.get("payload") or {}

        if atype in ("photo", "image", "sticker"):
            u = payload.get("url")
            if u:
                pack.photos.append(u)

        elif atype == "video":
            u = payload.get("url") or await resolve_video_url(payload)
            if u:
                pack.videos_urls.append(u)
                vdata, vname, _ = await download_bytes(u, _VIDEO_FALLBACK_DL_MAX, "video.mp4")
                if vdata:
                    pack.video_bytes = vdata
                    pack.video_filename = vname

        elif atype == "file":
            u = payload.get("url")
            if u:
                data, fname, _ = await download_bytes(u, _DL_MAX_BYTES, "file.bin")
                if data:
                    pack.docs.append({"data": data, "filename": fname})

        elif atype == "audio":
            u = payload.get("url")
            if u:
                data, fname, ctype = await download_bytes(u, _DL_MAX_BYTES, "audio.ogg")
                if data:
                    is_voice = is_probably_voice(fname, ctype)
                    if not is_voice and _FORCE_VOICE:
                        v = await ffmpeg_convert_to_opus_ogg(data)
                        if v:
                            data = v
                            fname = "voice.ogg"
                            is_voice = True
                    pack.audios.append({"data": data, "filename": fname, "is_voice": is_voice})

        else:
            continue

    return pack


async def resolve_tg_targets_for_max_chat(max_chat_id: int) -> List[dict]:
    """
    Возвращает список TG-назначений для чата MAX.
    Результат кэшируется на короткое время (_MAX_ROUTER_TTL),
    чтобы не долбить Postgres на каждое входящее сообщение.

    ВАЖНО:
    - Для входящих сообщений из MAX нас интересуют только чатовые связки
      (link_type = 'chat'), чтобы не превращать канал-линки в двусторонние.
    """
    max_chat_id = int(max_chat_id)

    # --- кэш-попадание ---
    now = time.monotonic()
    cached = _MAX_ROUTER_CACHE.get(max_chat_id)
    if cached is not None:
        rows, ts = cached
        if now - ts < _MAX_ROUTER_TTL:
            return rows

    out: List[dict] = []

    # 1) "native" режим: MAX-чат как source_chat_id (на будущее или если такие записи появятся)
    rows = await aquery(
        """
        select id, link_type, target_chat_id, enabled, paid_until, trial_until
          from channel_links
         where enabled = true
           and coalesce(target_platform, 'tg') = 'tg'
           and source_chat_id = %s
           and link_type = 'chat'
        """,
        (max_chat_id,),
    )
    for r in rows or []:
        if not _is_link_paid_or_trial_active(r):
            continue
        out.append(
            {
                "id": int(r["id"]),
                "link_type": (r.get("link_type") or "channel"),
                "dest_tg_chat_id": int(r["target_chat_id"]),
                "mode": "native",
            }
        )

    # 2) "reverse" режим: TG→MAX, а сюда летит MAX→TG по target_chat_id
    rows = await aquery(
        """
        select id, link_type, source_chat_id, enabled, paid_until, trial_until
          from channel_links
         where enabled = true
           and coalesce(target_platform, 'tg') = 'max'
           and target_chat_id = %s
           and link_type = 'chat'
        """,
        (max_chat_id,),
    )
    for r in rows or []:
        if not _is_link_paid_or_trial_active(r):
            continue
        out.append(
            {
                "id": int(r["id"]),
                "link_type": (r.get("link_type") or "channel"),
                "dest_tg_chat_id": int(r["source_chat_id"]),
                "mode": "reverse",
            }
        )

    _MAX_ROUTER_CACHE[max_chat_id] = (out, now)
    return out


def build_sender_name(sender: Dict[str, Any]) -> str:
    try:
        first = sender.get("first_name") or ""
        last = sender.get("last_name") or ""
        username = sender.get("username") or ""
        name = (first + " " + last).strip()
        if not name:
            name = ("@" + username) if username else ""
        return name
    except Exception:
        return ""


def _utf16_to_py_index(s: str, u16_index: int) -> int:
    """
    Преобразовать индекс в UTF-16 код-юнитах (как часто бывает в API)
    в индекс по символам Python-строки.
    """
    if u16_index <= 0:
        return 0
    count = 0
    i = 0
    n = len(s)
    while i < n and count < u16_index:
        cp = ord(s[i])
        if cp >= 0x10000:
            count += 2
        else:
            count += 1
        i += 1
    return i


def _utf16_range_to_py_slice(s: str, offset_u16: int, length_u16: int) -> Tuple[int, int]:
    """
    Диапазон [offset, offset+length) в UTF-16 → (start, end) по Python-индексам.
    """
    start = _utf16_to_py_index(s, offset_u16)
    end = _utf16_to_py_index(s, offset_u16 + max(0, length_u16))
    start = max(0, min(start, len(s)))
    end = max(start, min(end, len(s)))
    return start, end


def max_markup_to_html(text: str, markup: List[Dict[str, Any]]) -> str:
    """
    Конвертация text + markup из MAX в HTML для Telegram.

    ВАЖНО: MAX (как и Telegram) может давать offset/length в UTF-16 код-юнитах.
    Поэтому используем _utf16_range_to_py_slice, чтобы не съезжать на эмодзи.
    """
    if not text:
        return ""
    if not markup:
        return html.escape(text)

    n = len(text)
    opens: Dict[int, List[str]] = {}
    closes: Dict[int, List[str]] = {}

    def add_span(start: int, end: int, etype: str, url: Optional[str]):
        open_tag, close_tag = tag_for_entity(text[start:end], etype, url)
        if open_tag or close_tag:
            opens.setdefault(start, []).append(open_tag)
            closes.setdefault(end, []).append(close_tag)

    for m in markup:
        try:
            et = (m.get("type") or "").lower()
            off = int(m.get("from", 0))
            ln = int(m.get("length", 0))
            url = m.get("url")
        except Exception:
            continue
        if ln <= 0:
            continue

        # исправлено: оффсеты считаем как UTF-16, а не как Python-индексы
        start, end = _utf16_range_to_py_slice(text, off, ln)
        if start >= end or start >= n:
            continue

        add_span(start, end, et, url)

    out: List[str] = []
    for i, ch in enumerate(text):
        if i in opens:
            out.extend(opens[i])
        out.append(html.escape(ch))
        if (i + 1) in closes:
            for tag in reversed(closes[i + 1]):
                out.append(tag)
    return "".join(out)


def tag_for_entity(segment_text: str, etype: str, url: Optional[str]) -> Tuple[str, str]:
    et = (etype or "").lower()
    if et in ("bold", "strong"):
        return "<b>", "</b>"
    if et in ("italic", "em"):
        return "<i>", "</i>"
    if et in ("underline", "ins"):
        return "<u>", "</u>"
    if et in ("strikethrough", "s", "del"):
        return "<s>", "</s>"
    if et in ("code", "pre"):
        return "<code>", "</code>"
    if et in ("link", "text_link", "url"):
        href = url or segment_text
        if href:
            return f'<a href="{html.escape(href, quote=True)}">', "</a>"
    return "", ""


def _is_link_paid_or_trial_active(link_row: dict) -> bool:
    from datetime import datetime, timezone

    now = datetime.now(timezone.utc)
    pu = link_row.get("paid_until")
    if pu:
        try:
            if getattr(pu, "tzinfo", None) is None:
                pu = pu.replace(tzinfo=timezone.utc)
            if now <= pu:
                return True
        except Exception:
            pass
    tu = link_row.get("trial_until")
    if tu:
        try:
            if getattr(tu, "tzinfo", None) is None:
                tu = tu.replace(tzinfo=timezone.utc)
            if now <= tu:
                return True
        except Exception:
            pass
    return False

def ensure_json(data: Any) -> dict:
    """
    Аккуратно приводим поле data к dict.
    Поддерживаем строку с JSON и уже готовый dict.
    """
    if isinstance(data, dict):
        return data
    if isinstance(data, str):
        try:
            return json.loads(data)
        except Exception:
            return {}
    return {}


def apply_rules_to_html(htmltxt: str, rules: List[dict]) -> Tuple[str, bool]:
    """
    Применение "простых" правил замены к HTML-тексту.
    Логика 1в1 как в main.py, чтобы TG→MAX и MAX→TG использовали один движок.
    """
    if not htmltxt:
        return htmltxt, False

    cur = htmltxt
    changed_any = False

    for r in rules:
        try:
            typ = r["type"]
            data = ensure_json(r.get("data"))
        except Exception:
            continue

        if typ != "simple":
            continue

        from_html = (data.get("from_html") or "").strip()
        to_html = data.get("to_html") or ""

        from_plain = (data.get("from_plain") or data.get("from") or "").strip()
        to_plain = data.get("to_plain") or data.get("to") or ""

        before = cur

        if from_html:
            cur = cur.replace(from_html, to_html)
        elif from_plain:
            cur = cur.replace(from_plain, to_plain)

        if cur != before:
            changed_any = True

    return cur, changed_any


def exclusions_hit(text: str, tokens: List[str]) -> bool:
    t = text or ""
    return any(tok and tok in t for tok in tokens)


def truncate_caption(text_html: str, limit: int) -> str:
    if len(text_html) <= limit:
        return text_html
    return text_html[: limit - 1] + "…"


async def start(bot: Bot):
    worker = MaxInboxWorker(bot)
    task = asyncio.create_task(worker.run())
    return worker, task

