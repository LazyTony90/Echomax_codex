#app/app/link_router_cache.py
import os
import time
import logging
from typing import Dict, Tuple, List
from datetime import datetime, timezone

from app.db import aquery

log = logging.getLogger(__name__)

_TTL_SECONDS = float(os.getenv("LINK_ROUTER_CACHE_TTL", "5.0"))

# key: (source_chat_id, link_type) -> (rows, ts_monotonic)
_LINKS_BY_SOURCE: Dict[Tuple[int, str], Tuple[List[dict], float]] = {}


def _now() -> float:
    return time.monotonic()


def _is_link_paid_or_trial_active(link_row: dict) -> bool:
    now = datetime.now(timezone.utc)

    pu = link_row.get("paid_until")
    if pu:
        try:
            if getattr(pu, "tzinfo", None) is None:
                pu = pu.replace(tzinfo=timezone.utc)
            if now <= pu:
                return True
        except Exception:
            pass

    tu = link_row.get("trial_until")
    if tu:
        try:
            if getattr(tu, "tzinfo", None) is None:
                tu = tu.replace(tzinfo=timezone.utc)
            if now <= tu:
                return True
        except Exception:
            pass


    # Старые данные: is_trial=true, но trial_until/paid_until не заполнены.
    # Считаем связку активной, чтобы не заблокировать клиентов при несовпадении схем.
    try:
        if bool(link_row.get("is_trial")) and (not link_row.get("trial_until")) and (not link_row.get("paid_until")):
            return True
    except Exception:
        pass
    return False


async def _load_links_for_source(source_chat_id: int, link_type: str) -> List[dict]:
    """
    Реальный запрос к БД для получения активных связок для данного source_chat_id и типа.
    """
    source_chat_id = int(source_chat_id)
    link_type = (link_type or "channel")

    try:
        rows = await aquery(
            """
            select id,
                   owner_tg_user_id,
                   source_chat_id,
                   target_chat_id,
                   enabled,
                   paid_until,
                   name,
                   trial_until,
                   is_trial,
                   coalesce(target_platform, 'tg') as target_platform,
                   coalesce(link_type, 'channel')   as link_type
              from channel_links
             where source_chat_id = %s
               and enabled = true
               and coalesce(link_type, 'channel') = %s
             order by id
            """,
            (source_chat_id, link_type),
        )
        rows = rows or []
    except Exception as e:
        # Фоллбек на старую схему (без trial/target_platform/link_type),
        # чтобы не упасть, если миграции ещё не доехали.
        log.warning(
            "link_router_cache: primary query failed, fallback to legacy, err=%s",
            e,
        )
        rows = await aquery(
            """
            select id,
                   owner_tg_user_id,
                   source_chat_id,
                   target_chat_id,
                   enabled,
                   paid_until,
                   name,
                   null::timestamp with time zone as trial_until,
                   false as is_trial,
                   'tg' as target_platform,
                   'channel' as link_type
              from channel_links
             where source_chat_id = %s
               and enabled = true
             order by id
            """,
            (source_chat_id,),
        )
        rows = rows or []

    # Отфильтруем по триалу/оплате
    return [r for r in rows if _is_link_paid_or_trial_active(r)]


async def get_links_for_source(source_chat_id: int, link_type: str = "channel") -> List[dict]:
    """
    Основной API: получить список активных связок для source_chat_id и типа (channel/chat)
    с небольшим TTL-кэшем в памяти.
    """
    key = (int(source_chat_id), (link_type or "channel"))
    now = _now()
    cached = _LINKS_BY_SOURCE.get(key)
    if cached is not None:
        rows, ts = cached
        if now - ts < _TTL_SECONDS:
            return rows

    rows = await _load_links_for_source(source_chat_id, link_type)
    _LINKS_BY_SOURCE[key] = (rows, now)
    return rows


def invalidate_source_links(source_chat_id: int) -> None:
    """
    Инвалидируем все кэшированные записи для данного source_chat_id (для всех типов).
    Вызывать после изменений в channel_links, которые касаются этого source_chat_id.
    """
    source_chat_id = int(source_chat_id)
    to_del = [k for k in _LINKS_BY_SOURCE.keys() if k[0] == source_chat_id]
    for k in to_del:
        _LINKS_BY_SOURCE.pop(k, None)
    if to_del:
        log.info(
            "link_router_cache: invalidated %d entries for source_chat_id=%s",
            len(to_del),
            source_chat_id,
        )
