#app/app/max_send.py
import os
import re
import asyncio
import logging
import json
import contextlib
import uuid
import random
from typing import Optional, Dict, Any, Tuple, Iterable

import aiohttp
from aiohttp import ClientTimeout, FormData, TCPConnector

log = logging.getLogger(__name__)

# -------- Конфигурация из ENV --------
MAX_API_BASE = os.getenv("MAX_API_BASE", "https://platform-api.max.ru")
MAX_BOT_TOKEN = os.getenv("MAX_BOT_TOKEN", "")

_MAX_RETRIES = int(os.getenv("MAX_API_RETRIES", "4"))
_BACKOFF_BASE = float(os.getenv("MAX_API_BACKOFF_BASE", "0.4"))  # сек
_BACKOFF_MAX = float(os.getenv("MAX_API_BACKOFF_MAX", "6.0"))    # сек

# Лимиты и таймауты для HTTP-сессий
_MAX_HTTP_LIMIT = int(os.getenv("MAX_HTTP_LIMIT", "64"))
_TG_HTTP_LIMIT = int(os.getenv("TG_HTTP_LIMIT", "32"))
# Ограничение параллелизма запросов в MAX (защита от всплесков нагрузки)
_MAX_API_CONCURRENCY = int(os.getenv("MAX_API_CONCURRENCY", "24"))
_MAX_API_SEM: asyncio.Semaphore | None = None

def _max_api_sem() -> asyncio.Semaphore:
    global _MAX_API_SEM
    if _MAX_API_SEM is None:
        # Lazy init: semaphore must be created inside event loop context.
        _MAX_API_SEM = asyncio.Semaphore(max(1, _MAX_API_CONCURRENCY))
    return _MAX_API_SEM


# Ограничение параллельных upload'ов (особенно важно при альбомах/видео под нагрузкой)
_MAX_UPLOAD_CONCURRENCY = int(os.getenv("MAX_UPLOAD_CONCURRENCY", "12"))
_MAX_UPLOAD_SEM: asyncio.Semaphore | None = None

def _max_upload_sem() -> asyncio.Semaphore:
    global _MAX_UPLOAD_SEM
    if _MAX_UPLOAD_SEM is None:
        _MAX_UPLOAD_SEM = asyncio.Semaphore(max(1, _MAX_UPLOAD_CONCURRENCY))
    return _MAX_UPLOAD_SEM

# Ограничение параллельных конвертаций (ffmpeg)
_MEDIA_CONVERT_CONCURRENCY = int(os.getenv("MEDIA_CONVERT_CONCURRENCY", "3"))
_MEDIA_CONVERT_SEM: asyncio.Semaphore | None = None

def _media_convert_sem() -> asyncio.Semaphore:
    global _MEDIA_CONVERT_SEM
    if _MEDIA_CONVERT_SEM is None:
        _MEDIA_CONVERT_SEM = asyncio.Semaphore(max(1, _MEDIA_CONVERT_CONCURRENCY))
    return _MEDIA_CONVERT_SEM



_MAX_HTTP_TIMEOUT_TOTAL = float(os.getenv("MAX_HTTP_TIMEOUT_TOTAL", "30"))
_MAX_UPLOAD_TIMEOUT_TOTAL = float(os.getenv("MAX_UPLOAD_TIMEOUT_TOTAL", "600"))
_MAX_UPLOAD_CONNECT_TIMEOUT = float(os.getenv("MAX_UPLOAD_CONNECT_TIMEOUT", "20"))
_MAX_UPLOAD_SOCK_READ = float(os.getenv("MAX_UPLOAD_SOCK_READ", "600"))
_MAX_HTTP_CONNECT_TIMEOUT = float(os.getenv("MAX_HTTP_CONNECT_TIMEOUT", "10"))

_TG_HTTP_TIMEOUT_TOTAL = float(os.getenv("TG_HTTP_TIMEOUT_TOTAL", "180"))
_TG_HTTP_CONNECT_TIMEOUT = float(os.getenv("TG_HTTP_CONNECT_TIMEOUT", "10"))

# Предварительная перекодировка "голосов" в mp3 при необходимости
_AUDIO_PREEMPT = os.getenv("MAX_AUDIO_PREEMPT_TRANSCODE", "1").lower() not in ("0", "false", "no")

# -------- Глобальные клиентские сессии (keep-alive) --------
_MAX_SESS: Optional[aiohttp.ClientSession] = None
_TG_SESS: Optional[aiohttp.ClientSession] = None


def _mask_url(u: str) -> str:
    try:
        out = re.sub(r"(apiToken=)[^&]+", r"\1***", u)
        out = re.sub(r"(sig=)[^&]+", r"\1***", out)
        return out
    except Exception:
        return u


def _build_session(limit: int, total_timeout: float, connect_timeout: float) -> aiohttp.ClientSession:
    connector = TCPConnector(limit=limit, ttl_dns_cache=300, enable_cleanup_closed=True)
    timeout = ClientTimeout(total=total_timeout, connect=connect_timeout)
    return aiohttp.ClientSession(connector=connector, timeout=timeout)


def get_max_http_session() -> aiohttp.ClientSession:
    global _MAX_SESS
    if _MAX_SESS is None or _MAX_SESS.closed:
        _MAX_SESS = _build_session(_MAX_HTTP_LIMIT, _MAX_HTTP_TIMEOUT_TOTAL, _MAX_HTTP_CONNECT_TIMEOUT)
    return _MAX_SESS


def _upload_timeout() -> ClientTimeout:
    # Uploads can take much longer than ordinary API calls.
    return ClientTimeout(
        total=_MAX_UPLOAD_TIMEOUT_TOTAL,
        connect=_MAX_UPLOAD_CONNECT_TIMEOUT,
        sock_read=_MAX_UPLOAD_SOCK_READ,
    )


def get_tg_http_session() -> aiohttp.ClientSession:
    global _TG_SESS
    if _TG_SESS is None or _TG_SESS.closed:
        _TG_SESS = _build_session(_TG_HTTP_LIMIT, _TG_HTTP_TIMEOUT_TOTAL, _TG_HTTP_CONNECT_TIMEOUT)
    return _TG_SESS


async def close_http_sessions():
    global _MAX_SESS, _TG_SESS
    for sess in (_MAX_SESS, _TG_SESS):
        if sess and not sess.closed:
            with contextlib.suppress(Exception):
                await sess.close()


class MaxSendError(Exception):
    pass


def _auth_headers() -> Dict[str, str]:
    token = MAX_BOT_TOKEN
    if not token:
        raise MaxSendError("MAX_BOT_TOKEN is not configured")
    return {"Authorization": token}


def _retryable(status: int) -> bool:
    return status == 429 or 500 <= status <= 599


async def _sleep_backoff(attempt: int):
    base = min(_BACKOFF_MAX, _BACKOFF_BASE * (2 ** attempt))
    jitter = base * (0.5 - random.random()) * 0.5  # ±25%
    await asyncio.sleep(max(0.05, base + jitter))


def _with_request_id(headers: Optional[Dict[str, str]]) -> Dict[str, str]:
    h = dict(headers or {})
    h.setdefault("X-Request-ID", uuid.uuid4().hex)
    return h


async def _request_json(
    method: str,
    url: str,
    *,
    params: Optional[Dict[str, str]] = None,
    headers: Optional[Dict[str, str]] = None,
    json_body: Optional[Dict[str, Any]] = None,
    data: Any = None,
    ok_status: Iterable[int] | int = 200,
) -> Dict[str, Any]:
    ok_set = {ok_status} if isinstance(ok_status, int) else set(ok_status)
    sess = get_max_http_session()
    attempt = 0
    hdrs = _with_request_id(_auth_headers() | dict(headers or {}))

    while True:
        try:
            async with _max_api_sem():
                async with sess.request(method, url, params=params, headers=hdrs, json=json_body, data=data) as resp:
                    txt = await resp.text()
                    if resp.status not in ok_set:
                        if _retryable(resp.status) and attempt < _MAX_RETRIES:
                            log.warning("MAX %s %s -> %s, retrying... body=%s",
                                        method, _mask_url(url), resp.status, txt[:500])
                            attempt += 1
                            await _sleep_backoff(attempt)
                            continue
                        raise MaxSendError(f"MAX {method} {_mask_url(url)} failed {resp.status}: {txt[:500]}")
                    try:
                        return await resp.json()
                    except Exception:
                        try:
                            return json.loads(txt)
                        except Exception:
                            raise MaxSendError(f"MAX {method} {_mask_url(url)} returned non-JSON: {txt[:400]}")
        except asyncio.CancelledError:
            raise
        except Exception as e:
            if attempt < _MAX_RETRIES:
                    log.warning("MAX %s %s exception %s, retrying...", method, _mask_url(url), e)
                    attempt += 1
                    await _sleep_backoff(attempt)
                    continue
            raise


# ========================= Отправка сообщений =========================

async def send_text_to_chat(
    chat_id: int,
    text: str,
    fmt: Optional[str] = None,
    disable_link_preview: bool = False,
    reply_to_mid: Optional[str] = None,
) -> Dict[str, Any]:
    """Отправка текстового сообщения в MAX.

    Если при наличии reply_to_mid API MAX отвечает 500 internal.error,
    пробуем повторить запрос без поля link (без reply), чтобы не ломать зеркалирование.
    """
    payload: Dict[str, Any] = {
        "text": text or "",
        "attachments": None,
        "link": {"type": "reply", "mid": reply_to_mid} if reply_to_mid else None,
        "notify": True,
    }
    if fmt in ("html", "markdown"):
        payload["format"] = fmt

    params = {"chat_id": str(chat_id)}
    if disable_link_preview:
        params["disable_link_preview"] = "true"

    try:
        return await _request_json(
            "POST",
            f"{MAX_API_BASE}/messages",
            params=params,
            json_body=payload,
            ok_status=(200, 201),
        )
    except MaxSendError as e:
        # если падение только из-за reply_to_mid — пробуем без него
        if reply_to_mid and "failed 500" in str(e):
            log.warning(
                    "MAX send_text_to_chat reply failed with 500, retrying without reply_to_mid"
            )
            payload["link"] = None
            return await _request_json(
                    "POST",
                    f"{MAX_API_BASE}/messages",
                    params=params,
                    json_body=payload,
                    ok_status=(200, 201),
            )
        raise

async def send_message(
    chat_id: int,
    text: str,
    attachments: Optional[list] = None,
    fmt: Optional[str] = None,
    disable_link_preview: bool = False,
    reply_to_mid: Optional[str] = None,
) -> Dict[str, Any]:
    """Отправка сообщения (текст + вложения) в MAX.

    Аналогично send_text_to_chat: если при наличии reply_to_mid API MAX
    отвечает 500 internal.error, пробуем отправить без reply_to_mid.
    """
    payload: Dict[str, Any] = {
        "text": text or "",
        "attachments": attachments or None,
        "link": {"type": "reply", "mid": reply_to_mid} if reply_to_mid else None,
        "notify": True,
    }
    if fmt in ("html", "markdown"):
        payload["format"] = fmt

    params = {"chat_id": str(chat_id)}
    if disable_link_preview:
        params["disable_link_preview"] = "true"

    try:
        return await _request_json(
            "POST",
            f"{MAX_API_BASE}/messages",
            params=params,
            json_body=payload,
            ok_status=(200, 201),
        )
    except MaxSendError as e:
        if reply_to_mid and "failed 500" in str(e):
            log.warning(
                    "MAX send_message reply failed with 500, retrying without reply_to_mid"
            )
            payload["link"] = None
            return await _request_json(
                    "POST",
                    f"{MAX_API_BASE}/messages",
                    params=params,
                    json_body=payload,
                    ok_status=(200, 201),
            )
        raise


# ========================= Upload API (эндпоинты/тикеты) =========================

async def _get_upload_endpoint(file_type: str) -> Dict[str, Any]:
    return await _request_json(
        "POST",
        f"{MAX_API_BASE}/uploads",
        params={"type": file_type},
        ok_status=200,
    )


async def _get_upload_ticket(kind: str) -> Tuple[str, Optional[str]]:
    data = await _request_json(
        "POST",
        f"{MAX_API_BASE}/uploads",
        params={"type": kind},
        ok_status=200,
    )
    up_url = data.get("url")
    up_token = data.get("token")
    if not up_url:
        raise MaxSendError(f"MAX uploads ticket has no url for kind={kind}: {data}")
    log.info("MAX upload endpoint for %s: %s", kind, _mask_url(up_url))
    if up_token:
        log.info("MAX upload token for %s obtained from ticket", kind)
    return up_url, up_token


# ========================= Фактическая загрузка бинарей =========================

async def _upload_binary_to_url_once(
    url: str,
    data: bytes,
    *,
    field_name: str = "data",
    content_type: Optional[str] = None,
) -> Tuple[int, str]:
    sess = get_max_http_session()

    async with _max_upload_sem():

        # 1) multipart/form-data
        form = FormData()
        form.add_field(field_name, data, filename="file", content_type=content_type or "application/octet-stream")
        async with sess.post(url, data=form, timeout=_upload_timeout()) as r1:
            s1 = r1.status
            t1 = await r1.text()
        if s1 == 200:
            return s1, t1

        # 2) raw POST
        async with sess.post(url, data=data, headers={"Content-Type": content_type or "application/octet-stream"}) as r2:
            s2 = r2.status
            t2 = await r2.text()
        if s2 == 200:
            return s2, t2

        # 3) raw PUT
        async with sess.put(url, data=data, headers={"Content-Type": content_type or "application/octet-stream"}) as r3:
            s3 = r3.status
            t3 = await r3.text()
        return s3, t3


async def _upload_binary_with_retries(
    url: str,
    data: bytes,
    *,
    field_name: str = "data",
    content_type: Optional[str] = None,
) -> Tuple[int, str]:
    attempt = 0
    while True:
        try:
            status, txt = await _upload_binary_to_url_once(
                    url, data, field_name=field_name, content_type=content_type
            )
            if status == 200:
                    return status, txt
            if _retryable(status) and attempt < _MAX_RETRIES:
                    log.warning("MAX upload %s -> %s, retrying...", _mask_url(url), status)
                    attempt += 1
                    await _sleep_backoff(attempt)
                    continue
            return status, txt
        except asyncio.CancelledError:
            raise
        except Exception as e:
            if attempt < _MAX_RETRIES:
                    log.warning("MAX upload %s exception %s, retrying...", _mask_url(url), e)
                    attempt += 1
                    await _sleep_backoff(attempt)
                    continue
            raise


# ========================= Upload из файла (stream, без RAM) =========================

async def _upload_path_to_url_once(
    url: str,
    file_path: str,
    *,
    field_name: str = "data",
    content_type: Optional[str] = None,
    filename: Optional[str] = None,
) -> Tuple[int, str]:
    """
    Важно: для upload.do используем отдельную сессию с force_close,
    чтобы не переиспользовать "битые" SSL keep-alive соединения.
    """
    timeout = _upload_timeout()
    connector = TCPConnector(
        limit=4,
        limit_per_host=4,
        ttl_dns_cache=300,
        enable_cleanup_closed=True,
        force_close=True,          # ключевое: не держим keep-alive
    )

    async with aiohttp.ClientSession(connector=connector, timeout=timeout) as sess:
        # 1) multipart/form-data
        try:
            form = FormData()
            with open(file_path, "rb") as f:
                    form.add_field(
                        field_name,
                        f,
                        filename=filename or "file",
                        content_type=content_type or "application/octet-stream",
                    )
                    async with sess.post(url, data=form) as r1:
                        s1 = r1.status
                        t1 = await r1.text()
            if s1 == 200:
                    return s1, t1
        except Exception as e:
            log.debug("MAX upload multipart failed for %s: %s", _mask_url(url), e)

        # 2) raw POST
        try:
            with open(file_path, "rb") as f:
                    async with sess.post(
                        url,
                        data=f,
                        headers={"Content-Type": content_type or "application/octet-stream"},
                    ) as r2:
                        s2 = r2.status
                        t2 = await r2.text()
            if s2 == 200:
                    return s2, t2
        except Exception as e:
            log.debug("MAX upload raw POST failed for %s: %s", _mask_url(url), e)

        # 3) raw PUT
        with open(file_path, "rb") as f:
            async with sess.put(
                    url,
                    data=f,
                    headers={"Content-Type": content_type or "application/octet-stream"},
            ) as r3:
                    s3 = r3.status
                    t3 = await r3.text()
        return s3, t3



# ========================= Resumable upload for big files =========================
_MAX_RESUMABLE = os.getenv("MAX_RESUMABLE", "1") not in ("0", "false", "False", "no", "NO")
_MAX_RESUMABLE_CHUNK_MB = int(os.getenv("MAX_RESUMABLE_CHUNK_MB", "16"))
_MAX_RESUMABLE_CHUNK_BYTES = max(1, _MAX_RESUMABLE_CHUNK_MB) * 1024 * 1024

def _resumable_enabled_for_size(size_bytes: Optional[int]) -> bool:
    if not _MAX_RESUMABLE:
        return False
    if not size_bytes:
        return True  # если размер неизвестен — лучше пробовать
    # включаемся только для "больших" файлов, иначе обычный upload быстрее
    return size_bytes >= 32 * 1024 * 1024

async def _upload_path_resumable_to_url_once(
    url: str,
    file_path: str,
    *,
    content_type: Optional[str] = None,
    filename: Optional[str] = None,
    chunk_bytes: int = _MAX_RESUMABLE_CHUNK_BYTES,
) -> Tuple[int, str]:
    """
    Resumable upload по частям. Предполагается, что загрузчик MAX принимает raw body с заголовком Content-Range.
    Если сервер не поддерживает — вернёт 4xx/5xx, и мы откатимся на обычную загрузку.
    """
    sess = get_max_http_session()

    async with _max_upload_sem():

        async with _max_upload_sem():
            total = os.path.getsize(file_path)
            ctype = content_type or "application/octet-stream"

            # Важно: читаем с диска кусками, не держим весь файл в RAM.
            with open(file_path, "rb") as f:
                offset = 0
                last_status = 0
                last_text = ""
                while offset < total:
                    end = min(offset + chunk_bytes, total) - 1
                    f.seek(offset)
                    chunk = f.read(end - offset + 1)
                    headers = {
                            "Content-Type": ctype,
                            "Content-Length": str(len(chunk)),
                            # RFC 7233 style
                            "Content-Range": f"bytes {offset}-{end}/{total}",
                    }
                    # Некоторые загрузчики любят имя файла, но это не стандарт; отправим мягко.
                    if filename:
                            headers["X-File-Name"] = filename

                    async with sess.post(url, data=chunk, headers=headers, timeout=_upload_timeout()) as r:
                            last_status = r.status
                            last_text = await r.text()

                    # 308 — часто используется как "Resume Incomplete"
                    if last_status in (200, 201, 202, 204, 308):
                            offset = end + 1
                            continue

                    # Любой другой статус — выходим, чтобы внешний код решил (fallback/retry)
                    return last_status, last_text

                return last_status, last_text

async def _upload_path_resumable_with_retries(
    url: str,
    file_path: str,
    *,
    content_type: Optional[str] = None,
    filename: Optional[str] = None,
) -> Tuple[int, str]:
    attempt = 0
    while True:
        try:
            status, txt = await _upload_path_resumable_to_url_once(
                    url, file_path, content_type=content_type, filename=filename
            )
            if status == 200:
                    return status, txt
            # 308 после последнего чанка некоторые сервера тоже могут вернуть — считаем успехом и отдаём тело
            if status == 308:
                    return status, txt
            # если сервер не поддерживает чанки (400/405/415) — сразу fallback на обычную загрузку
            if status in (400, 401, 403, 404, 405, 413, 415):
                    return status, txt
            if _retryable(status) and attempt < _MAX_RETRIES:
                    log.warning("MAX resumable upload %s -> %s, retrying...", _mask_url(url), status)
                    attempt += 1
                    await _sleep_backoff(attempt)
                    continue
            return status, txt
        except asyncio.CancelledError:
            raise
        except Exception as e:
            if attempt < _MAX_RETRIES:
                    log.warning("MAX resumable upload %s exception %s, retrying...", _mask_url(url), e)
                    attempt += 1
                    await _sleep_backoff(attempt)
                    continue
            raise


async def _upload_path_with_retries(
    url: str,
    file_path: str,
    *,
    field_name: str = "data",
    content_type: Optional[str] = None,
    filename: Optional[str] = None,
) -> Tuple[int, str]:
    attempt = 0
    last_exc: Optional[Exception] = None

    while True:
        try:
            status, txt = await _upload_path_to_url_once(
                    url,
                    file_path,
                    field_name=field_name,
                    content_type=content_type,
                    filename=filename,
            )
            if status == 200:
                    return status, txt

            # некоторые CDN могут рвать коннект и отдавать 5xx/429 — ретраим
            if _retryable(status) and attempt < _MAX_RETRIES:
                    log.warning("MAX upload(path) %s -> %s, retrying.", _mask_url(url), status)
                    attempt += 1
                    await _sleep_backoff(attempt)
                    continue

            return status, txt

        except asyncio.CancelledError:
            raise
        except Exception as e:
            last_exc = e
            if attempt < _MAX_RETRIES:
                    log.warning("MAX upload(path) %s exception %s, retrying...", _mask_url(url), e)
                    attempt += 1
                    await _sleep_backoff(attempt)
                    continue
            raise last_exc


async def upload_image_path(file_path: str, filename: str, mime_hint: Optional[str] = None) -> Dict[str, Any]:
    ep = await _get_upload_endpoint("image")
    url = ep.get("url")
    if not url:
        raise MaxSendError("Не удалось получить upload URL для image")
    log.info("MAX upload endpoint for image: %s", _mask_url(url))
    status, txt = await _upload_path_with_retries(
        url,
        file_path,
        field_name="data",
        content_type=mime_hint or "image/jpeg",
        filename=filename,
    )
    if status != 200:
        raise MaxSendError(f"Неожиданный ответ загрузчика изображения ({status}): {txt[:400]}")
    try:
        js = json.loads(txt)
    except Exception:
        raise MaxSendError(f"Неожиданный ответ загрузчика изображения (JSON): {txt[:400]}")
    if isinstance(js, dict) and ("photos" in js or "token" in js or "url" in js):
        return js
    raise MaxSendError(f"Неожиданный ответ загрузчика изображения (нет 'photos'/'token'/'url'): {js}")


async def upload_file_path(file_path: str, filename: str, mime_hint: Optional[str] = None) -> str:
    ep = await _get_upload_endpoint("file")
    url = ep.get("url")
    if not url:
        raise MaxSendError("Не удалось получить upload URL для file")
    log.info("MAX upload endpoint for file: %s", _mask_url(url))
    size_bytes = None
    try:
        size_bytes = os.path.getsize(file_path)
    except Exception:
        size_bytes = None

    if _resumable_enabled_for_size(size_bytes):
        status, txt = await _upload_path_resumable_with_retries(
            url,
            file_path,
            content_type=mime_hint or "application/octet-stream",
            filename=filename,
        )
        # Если сервер не поддерживает resumable — откатимся на обычную загрузку
        if status != 200 and status in (400, 401, 403, 404, 405, 413, 415):
            status, txt = await _upload_path_with_retries(
                    url,
                    file_path,
                    field_name="data",
                    content_type=mime_hint or "application/octet-stream",
                    filename=filename,
            )
    else:
        status, txt = await _upload_path_with_retries(
            url,
            file_path,
            field_name="data",
            content_type=mime_hint or "application/octet-stream",
            filename=filename,
        )
    if status != 200:
        raise MaxSendError(f"Загрузка file провалилась ({status}): {txt[:400]}")
    try:
        js = json.loads(txt)
    except Exception:
        raise MaxSendError(f"Не удалось получить token файла из ответа: {txt[:400]}")
    token = js.get("token")
    if not token:
        raise MaxSendError(f"Не удалось получить token файла после upload: {js}")
    return token


async def upload_audio_path(file_path: str, filename: str, mime_hint: Optional[str] = None) -> str:
    # Для больших файлов не делаем preemptive transcode (это потребует чтения в RAM).
    url, token = await _get_upload_ticket("audio")
    size_bytes = None
    try:
        size_bytes = os.path.getsize(file_path)
    except Exception:
        size_bytes = None

    if _resumable_enabled_for_size(size_bytes):
        status, txt = await _upload_path_resumable_with_retries(
            url,
            file_path,
            content_type=mime_hint or "audio/mpeg",
            filename=filename,
        )
        # Если сервер не поддерживает resumable — откатимся на обычную загрузку
        if status != 200 and status in (400, 401, 403, 404, 405, 413, 415):
            status, txt = await _upload_path_with_retries(
                    url,
                    file_path,
                    field_name="data",
                    content_type=mime_hint or "audio/mpeg",
                    filename=filename,
            )
    else:
        status, txt = await _upload_path_with_retries(
            url,
            file_path,
            field_name="data",
            content_type=mime_hint or "audio/mpeg",
            filename=filename,
        )
    if status != 200:
        raise MaxSendError(f"Загрузка audio провалилась ({status}): {txt[:400]}")

    if not token:
        try:
            js = json.loads(txt)
            token = js.get("token")
        except Exception:
            token = None

    if not token:
        raise MaxSendError(f"MAX audio upload ok but no token from ticket/response: {txt[:300]}")

    return token


async def upload_video_path(file_path: str, filename: str, mime_hint: Optional[str] = None) -> str:
    url, token = await _get_upload_ticket("video")
    size_bytes = None
    try:
        size_bytes = os.path.getsize(file_path)
    except Exception:
        size_bytes = None

    if _resumable_enabled_for_size(size_bytes):
        status, txt = await _upload_path_resumable_with_retries(
            url,
            file_path,
            content_type=mime_hint or "video/mp4",
            filename=filename,
        )
        # Если сервер не поддерживает resumable — откатимся на обычную загрузку
        if status != 200 and status in (400, 401, 403, 404, 405, 413, 415):
            status, txt = await _upload_path_with_retries(
                    url,
                    file_path,
                    field_name="data",
                    content_type=mime_hint or "video/mp4",
                    filename=filename,
            )
    else:
        status, txt = await _upload_path_with_retries(
            url,
            file_path,
            field_name="data",
            content_type=mime_hint or "video/mp4",
            filename=filename,
        )
    if status != 200:
        raise MaxSendError(f"Загрузка video провалилась ({status}): {txt[:400]}")

    if not token:
        try:
            js = json.loads(txt)
            token = js.get("token")
        except Exception:
            token = None

    if not token:
        raise MaxSendError(f"MAX video upload ok but no token from ticket/response: {txt[:300]}")

    return token

# ========================= Предварительная перекодировка аудио =========================

def _needs_transcode_audio(filename: str, mime_hint: Optional[str]) -> bool:
    name = (filename or "").lower()
    if "ogg" in (mime_hint or "").lower() or "opus" in (mime_hint or "").lower():
        return True
    return name.endswith(".ogg") or name.endswith(".oga") or name.endswith(".opus")


async def _ffmpeg_transcode_to_mp3(data: bytes) -> bytes:
    import tempfile, os as _os
    with tempfile.NamedTemporaryFile(suffix=".ogg", delete=False) as src:
        src.write(data)
        src.flush()
        src_path = src.name
    dst_path = src_path + ".mp3"
    try:
        async with _media_convert_sem():
            cmd = ["ffmpeg", "-y", "-i", src_path, "-vn", "-acodec", "libmp3lame", "-b:a", "128k", dst_path]
            proc = await asyncio.create_subprocess_exec(*cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            _out, _err = await proc.communicate()
            if proc.returncode != 0:
                raise Exception(f"ffmpeg transcode failed: code={proc.returncode}")
            with open(dst_path, "rb") as f:
                return f.read()
    finally:
        for p in (src_path, dst_path):
            with contextlib.suppress(Exception):
                    _os.remove(p)


# ========================= Публичные upload-помощники =========================

async def upload_image_bytes(data: bytes, filename: str, mime_hint: Optional[str] = None) -> Dict[str, Any]:
    ep = await _get_upload_endpoint("image")
    url = ep.get("url")
    if not url:
        raise MaxSendError("Не удалось получить upload URL для image")
    log.info("MAX upload endpoint for image: %s", _mask_url(url))
    status, txt = await _upload_binary_with_retries(
        url, data, field_name="data", content_type=mime_hint or "image/jpeg"
    )
    if status != 200:
        raise MaxSendError(f"Неожиданный ответ загрузчика изображения ({status}): {txt[:400]}")
    try:
        js = json.loads(txt)
    except Exception:
        raise MaxSendError(f"Неожиданный ответ загрузчика изображения (JSON): {txt[:400]}")
    if isinstance(js, dict) and ("photos" in js or "token" in js or "url" in js):
        return js
    raise MaxSendError(f"Неожиданный ответ загрузчика изображения (нет 'photos'/'token'/'url'): {js}")


async def upload_file_bytes(data: bytes, filename: str, mime_hint: Optional[str] = None) -> str:
    ep = await _get_upload_endpoint("file")
    url = ep.get("url")
    if not url:
        raise MaxSendError("Не удалось получить upload URL для file")
    log.info("MAX upload endpoint for file: %s", _mask_url(url))
    status, txt = await _upload_binary_with_retries(
        url, data, field_name="data", content_type=mime_hint or "application/octet-stream"
    )
    if status != 200:
        raise MaxSendError(f"Загрузка file провалилась ({status}): {txt[:400]}")
    try:
        js = json.loads(txt)
    except Exception:
        raise MaxSendError(f"Не удалось получить token файла из ответа: {txt[:400]}")
    token = js.get("token")
    if not token:
        raise MaxSendError(f"Не удалось получить token файла после upload: {js}")
    return token


async def upload_audio_bytes(data: bytes, filename: str, mime_hint: Optional[str] = None) -> str:
    if _AUDIO_PREEMPT and _needs_transcode_audio(filename, mime_hint):
        try:
            data = await _ffmpeg_transcode_to_mp3(data)
            mime_hint = "audio/mpeg"
        except Exception as e:
            log.warning("Preemptive transcode failed, will try raw upload: %s", e)

    url, token = await _get_upload_ticket("audio")
    status, txt = await _upload_binary_with_retries(
        url, data, field_name="data", content_type=mime_hint or "audio/mpeg"
    )
    if status != 200:
        raise MaxSendError(f"Загрузка audio провалилась ({status}): {txt[:400]}")

    if not token:
        try:
            js = json.loads(txt)
            token = js.get("token")
        except Exception:
            token = None

    if not token:
        raise MaxSendError(f"MAX audio upload ok but no token from ticket/response: {txt[:300]}")

    return token


async def upload_video_bytes(data: bytes, filename: str, mime_hint: Optional[str] = None) -> str:
    url, token = await _get_upload_ticket("video")
    status, txt = await _upload_binary_with_retries(
        url, data, field_name="data", content_type=mime_hint or "video/mp4"
    )
    if status != 200:
        raise MaxSendError(f"Загрузка video провалилась ({status}): {txt[:400]}")

    if not token:
        try:
            js = json.loads(txt)
            token = js.get("token")
        except Exception:
            token = None

    if not token:
        raise MaxSendError(f"MAX video upload ok but no token from ticket/response: {txt[:300]}")

    return token


