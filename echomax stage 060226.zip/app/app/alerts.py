# app/app/alerts.py
import os
import time
import contextlib
from typing import Optional, Dict, List, Tuple
from collections import deque
from datetime import datetime, timezone

from aiogram import Bot

# Включение/выключение отправки алертов в Telegram
_ENABLED = os.getenv("ADMIN_ALERTS", "1").lower() not in ("0", "false", "no")

_BOT: Optional[Bot] = None
_ADMIN_CHAT_IDS: List[int] = []          # список получателей
_COOLDOWNS: Dict[str, float] = {}        # key -> next_allowed_ts (общий на событие, а не на каждого админа)

# Небольшой кольцевой буфер последних алертов для диагностики
_MAX_RECENT = int(os.getenv("ADMIN_ALERTS_BUFFER", "50"))
_RECENT_ALERTS: deque[Tuple[float, str, str]] = deque(maxlen=_MAX_RECENT)
# элементы: (ts_epoch, key, text)


def set_bot(bot: Bot) -> None:
    """
    Сохранить ссылку на бота, чтобы можно было отправлять сообщения админам.
    """
    global _BOT
    _BOT = bot


def set_recipients(chat_ids: List[int]) -> None:
    """
    Список Telegram chat_id админов, которым будут уходить алерты.
    """
    global _ADMIN_CHAT_IDS
    _ADMIN_CHAT_IDS = [int(c) for c in chat_ids or []]


def _can_send(key: str, min_interval_sec: int) -> bool:
    """
    Проверка троттлинга по ключу события.
    """
    now = time.monotonic()
    next_allowed = _COOLDOWNS.get(key, 0.0)
    if now < next_allowed:
        return False
    _COOLDOWNS[key] = now + max(1, min_interval_sec)
    return True


def _store_alert(key: str, text: str) -> None:
    """
    Записать алерт во внутренний буфер для последующей диагностики.
    """
    ts = time.time()
    # ограничим длину текста, чтобы не держать слишком много в памяти
    short_text = text[:4096]
    _RECENT_ALERTS.append((ts, key, short_text))


def get_recent_alerts(limit: int = 20) -> List[dict]:
    """
    Получить список последних алертов (до `limit` штук) в виде:
    [
      {"ts": datetime, "key": str, "text": str},
      ...
    ]
    Отсортировано по убыванию времени (самый свежий первым).
    """
    if limit <= 0:
        return []

    items = list(_RECENT_ALERTS)[-limit:]
    items.reverse()  # свежие первыми

    result: List[dict] = []
    for ts, key, text in items:
        dt = datetime.fromtimestamp(ts, tz=timezone.utc)
        result.append({"ts": dt, "key": key, "text": text})
    return result


async def notify_admin_throttled(key: str, text: str, min_interval_sec: int = 300) -> None:
    """
    Троттлинг по ключу события: одно уведомление на key не чаще, чем раз в min_interval_sec.
    Если «можно», отправляется всем администраторам.
    Дополнительно сохраняет событие в буфер для последующей диагностики.
    """
    # Всегда пишем в буфер, даже если отправка отключена — это полезно для диагностики.
    _store_alert(key, text)

    if not _ENABLED or _BOT is None or not _ADMIN_CHAT_IDS:
        return
    if not _can_send(key, min_interval_sec):
        return

    for chat_id in _ADMIN_CHAT_IDS:
        with contextlib.suppress(Exception):
            await _BOT.send_message(chat_id, text[:4096])

