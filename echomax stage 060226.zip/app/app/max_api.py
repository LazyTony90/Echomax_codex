import os
import re
from typing import Tuple, List, Dict, Optional
import aiohttp

BASE_URL = os.getenv("MAX_API_BASE_URL", "https://platform-api.max.ru")
TOKEN = os.getenv("MAX_BOT_TOKEN", "")

class MaxApiError(Exception):
    pass

def _auth_headers() -> dict:
    """
    MAX ожидает заголовок Authorization: <token> (без 'Bearer ').
    """
    if not TOKEN:
        raise MaxApiError("MAX_BOT_TOKEN is not configured")
    return {"Authorization": TOKEN}

def _strip_zws(s: str) -> str:
    return (s or "").replace("\u200b", "").strip()

def normalize_chat_link(raw: str) -> str:
    """
    Принимаем формы: @alias, alias, https://max.ru/alias
    Возвращаем alias без @ и без URL-обёртки.
    """
    s = _strip_zws(raw)
    if not s:
        raise MaxApiError("Empty chat link")
    if s.startswith("http://") or s.startswith("https://"):
        try:
            from urllib.parse import urlparse
            p = urlparse(s)
            comp = p.path.strip("/").split("/")[-1]
            s = comp
        except Exception:
            pass
    if s.startswith("@"):
        s = s[1:]
    return s

def normalize_full_link(raw: str) -> str:
    """
    Приводим ссылку к виду без завершающих слэшей и в нижнем регистре.
    Если введён просто 'alias' — приводим к URL для сравнения с полем 'link'.
    """
    s = _strip_zws(raw)
    if not s:
        return s
    if s.startswith("http://") or s.startswith("https://"):
        s = s.rstrip("/")
    else:
        s = f"https://max.ru/{s}"
    return s.lower()

async def get_chat_by_link(session: aiohttp.ClientSession, link: str) -> dict:
    """
    GET /chats/{chatLink} — ищем публичный канал по алиасу.
    """
    link_norm = normalize_chat_link(link)
    url = f"{BASE_URL}/chats/{link_norm}"
    async with session.get(url, headers=_auth_headers(), timeout=aiohttp.ClientTimeout(total=15)) as resp:
        if resp.status == 200:
            return await resp.json()
        if resp.status == 404:
            raise MaxApiError("Чат не найден по ссылке/юзернейму (возможно, канал не публичный)")
        if resp.status == 401:
            raise MaxApiError("Не авторизовано: проверьте MAX_BOT_TOKEN")
        text = await resp.text()
        raise MaxApiError(f"Ошибка MAX API {resp.status}: {text}")

async def get_my_membership(session: aiohttp.ClientSession, chat_id: int) -> dict:
    """
    GET /chats/{chatId}/members/me — проверяем, состоит ли бот и есть ли права постить.
    """
    url = f"{BASE_URL}/chats/{chat_id}/members/me"
    async with session.get(url, headers=_auth_headers(), timeout=aiohttp.ClientTimeout(total=15)) as resp:
        if resp.status == 200:
            return await resp.json()
        if resp.status == 404:
            raise MaxApiError("Бот не является участником этого чата (добавьте бота в канал MAX)")
        if resp.status == 401:
            raise MaxApiError("Не авторизовано: проверьте MAX_BOT_TOKEN")
        text = await resp.text()
        raise MaxApiError(f"Ошибка MAX API {resp.status}: {text}")

async def list_my_chats(
    session: aiohttp.ClientSession,
    per_page: int = 100,
    fetch_all: bool = True,
    max_pages: int = 100
) -> List[Dict]:
    """
    GET /chats?count=&marker= — список чатов, где состоит бот, с пагинацией.
    - per_page: 1..100 (ограничение API)
    - fetch_all: если True — идём по marker до конца (или до max_pages)
    - max_pages: страховка от бесконечного цикла
    """
    per_page = max(1, min(int(per_page or 100), 100))
    timeout = aiohttp.ClientTimeout(total=20)

    chats: List[Dict] = []
    marker: Optional[int] = None
    pages = 0

    while True:
        url = f"{BASE_URL}/chats?count={per_page}"
        if marker is not None:
            url += f"&marker={marker}"

        async with session.get(url, headers=_auth_headers(), timeout=timeout) as resp:
            if resp.status == 200:
                data = await resp.json()
                part = data.get("chats") or []
                chats.extend(part)
                marker = data.get("marker")
            elif resp.status == 401:
                text = await resp.text()
                raise MaxApiError("Не авторизовано: проверьте MAX_BOT_TOKEN")
            else:
                text = await resp.text()
                raise MaxApiError(f"Ошибка MAX API {resp.status}: {text}")

        pages += 1
        if not fetch_all or not marker or pages >= max_pages:
            break

    return chats

def can_post_from_membership(member: dict) -> bool:
    """
    Для упрощения: права постинга считаем достаточными, если бот владелец/админ
    или если в permissions присутствуют 'post'/'write'.
    """
    if not member:
        return False
    if member.get("is_owner") or member.get("is_admin"):
        return True
    perms = member.get("permissions") or []
    needed = {"post", "write"}
    return any(p in needed or (isinstance(p, dict) and p.get("name") in needed) for p in perms)

_NUMERIC_RE = re.compile(r"^-?\d+$")

def _score_chat(row: Dict) -> tuple:
    """
    Сортировка кандидатов: публичные выше, больше участников выше, более свежие выше.
    """
    is_public = 1 if row.get("is_public") else 0
    participants = int(row.get("participants_count") or 0)
    last_ts = int(row.get("last_event_time") or 0)
    return (is_public, participants, last_ts)

async def resolve_destination(session: aiohttp.ClientSession, raw: str) -> Tuple[int, dict]:
    """
    Универсальное разрешение назначения для MAX:
    - если raw — число, считаем это chat_id и сразу проверяем членство/права;
    - иначе — пытаемся как алиас/URL (/chats/{link}); при 404 пробуем найти через /chats
      по полю link/alias, затем по title (точно/содержит), проходя все страницы.
    Возвращает (chat_id, membership).
    """
    s = _strip_zws(raw)
    if not s:
        raise MaxApiError("Пустое значение назначения")

    # 1) Числовой chat_id сразу
    if _NUMERIC_RE.fullmatch(s):
        chat_id = int(s)
        member = await get_my_membership(session, chat_id)
        return chat_id, member

    # 2) Пробуем публичный алиас напрямую
    try:
        chat = await get_chat_by_link(session, s)
        chat_id = int(chat["chat_id"])
        member = await get_my_membership(session, chat_id)
        return chat_id, member
    except MaxApiError:
        # пойдём в список чатов
        pass

    # 3) Фолбэк: ищем среди ВСЕХ чатов, где бот состоит (с пагинацией)
    chats = await list_my_chats(session, per_page=100, fetch_all=True, max_pages=100)
    if not chats:
        raise MaxApiError("Список чатов пуст. Добавьте бота в канал MAX и повторите ввод.")

    # 3.a) Сравнение по полному URL
    link_norm = normalize_full_link(s)  # может быть url или alias → приведём к url
    cand = [c for c in chats if _strip_zws((c.get("link") or "")).rstrip("/").lower() == link_norm]
    if not cand:
        # 3.b) По алиасу в конце ссылки
        alias = normalize_chat_link(s).lower()
        cand = [c for c in chats
                if _strip_zws((c.get("link") or "")).rstrip("/").lower().endswith("/" + alias)]

    # 3.c) По title — точное (без регистра), затем "содержит"
    if not cand:
        title_in = s.lower()
        exact = [c for c in chats if (c.get("title") or "").lower() == title_in]
        if exact:
            cand = exact
        else:
            contains = [c for c in chats if title_in in (c.get("title") or "").lower()]
            if contains:
                cand = contains

    if not cand:
        raise MaxApiError("Канал не найден. Укажите публичную ссылку, точное имя канала или числовой chat_id.")

    # Если кандидатов несколько — выберем лучший
    cand.sort(key=_score_chat, reverse=True)
    chosen = cand[0]
    chat_id = int(chosen["chat_id"])
    member = await get_my_membership(session, chat_id)
    return chat_id, member

