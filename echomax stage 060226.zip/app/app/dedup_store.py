#app/app/dedup_store.py
import os
import hashlib
import mimetypes
import logging
from typing import Optional, Dict, Any

import asyncio
import boto3
from botocore.exceptions import ClientError
from botocore.config import Config

from app.db import aquery
from app import max_send  # используем uploadдля первичной заливки в MAX

log = logging.getLogger(__name__)

S3_ENDPOINT_URL = os.getenv("S3_ENDPOINT_URL")
S3_BUCKET = os.getenv("S3_BUCKET", "media")
S3_REGION = os.getenv("S3_REGION")
S3_ACCESS_KEY_ID = os.getenv("S3_ACCESS_KEY_ID")
S3_SECRET_ACCESS_KEY = os.getenv("S3_SECRET_ACCESS_KEY")
S3_PATH_STYLE = os.getenv("S3_PATH_STYLE", "1").lower() not in ("0", "false", "no")
S3_PRESIGN_TTL = int(os.getenv("S3_PRESIGN_TTL", "21600"))  # 6h по умолчанию

# Виды медиа для MAX
TYPE_IMAGE = "image"
TYPE_FILE  = "file"
TYPE_AUDIO = "audio"
TYPE_VIDEO = "video"

_session = None
_s3 = None


def _s3_client():
    global _session, _s3
    if _s3:
        return _s3
    _session = boto3.session.Session()
    _s3 = _session.client(
        "s3",
        endpoint_url=S3_ENDPOINT_URL,
        aws_access_key_id=S3_ACCESS_KEY_ID,
        aws_secret_access_key=S3_SECRET_ACCESS_KEY,
        region_name=S3_REGION,
        config=Config(s3={"addressing_style": "path" if S3_PATH_STYLE else "virtual"}),
    )
    return _s3


def _sha256(data: bytes) -> str:
    h = hashlib.sha256()
    h.update(data)
    return h.hexdigest()


def _guess_ext(filename: Optional[str], mime_hint: Optional[str]) -> str:
    if filename and "." in filename and len(filename.split(".")[-1]) <= 5:
        return "." + filename.split(".")[-1].lower()
    if mime_hint:
        ext = mimetypes.guess_extension(mime_hint)
        if ext:
            return ext
    return ".bin"


def _hash_key(sha_hex: str, ext: str) -> str:
    return f"tg-cache/sha256/{sha_hex[:2]}/{sha_hex}{ext}"


def _head_exists(bucket: str, key: str) -> bool:
    """
    Синхронная проверка существования объекта в S3.
    Используется только из асинхронной оболочки _head_exists_async.
    """
    s3 = _s3_client()
    try:
        s3.head_object(Bucket=bucket, Key=key)
        return True
    except ClientError as e:
        code = e.response.get("ResponseMetadata", {}).get("HTTPStatusCode")
        if code in (404, 403):
            return False
        log.warning("S3 head_object error on %s: %s", key, e)
        return False


def _put_object(bucket: str, key: str, data: bytes, content_type: Optional[str]):
    """
    Синхронная запись объекта в S3.
    Используется только из асинхронной оболочки _put_object_async.
    """
    s3 = _s3_client()
    s3.put_object(
        Bucket=bucket,
        Key=key,
        Body=data,
        ContentType=content_type or (mimetypes.guess_type(key)[0] or "application/octet-stream"),
    )


def _presigned_url(bucket: str, key: str, ttl: int) -> str:
    """
    Генерация presigned URL. Это локальная операция (без сетевого запроса),
    поэтому её безопасно вызывать прямо из event loop.
    """
    s3 = _s3_client()
    return s3.generate_presigned_url(
        ClientMethod="get_object",
        Params={"Bucket": bucket, "Key": key},
        ExpiresIn=ttl,
    )


async def _head_exists_async(bucket: str, key: str) -> bool:
    """
    Асинхронная оболочка над _head_exists, чтобы не блокировать event loop.
    """
    return await asyncio.to_thread(_head_exists, bucket, key)


async def _put_object_async(bucket: str, key: str, data: bytes, content_type: Optional[str]):
    """
    Асинхронная оболочка над _put_object, чтобы не блокировать event loop.
    """
    await asyncio.to_thread(_put_object, bucket, key, data, content_type)


async def _upsert_row(
    sha_hex: str,
    size: int,
    s3_key: str,
    max_type: str,
    tg_unique_id: Optional[str] = None,
    max_token: Optional[str] = None,
    max_payload: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    rows = await aquery(
        """
        INSERT INTO media_dedup(sha256, size_bytes, s3_key, max_type, tg_unique_id, max_token, max_payload)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
        ON CONFLICT (sha256, max_type) DO UPDATE
          SET size_bytes   = EXCLUDED.size_bytes,
              s3_key       = EXCLUDED.s3_key,
              tg_unique_id = COALESCE(media_dedup.tg_unique_id, EXCLUDED.tg_unique_id),
              last_used_at = now(),
              max_token    = COALESCE(EXCLUDED.max_token, media_dedup.max_token),
              max_payload  = COALESCE(EXCLUDED.max_payload, media_dedup.max_payload)
        RETURNING id, sha256, size_bytes, s3_key, max_type, tg_unique_id, max_token, max_payload;
        """,
        (sha_hex, size, s3_key, max_type, tg_unique_id, max_token, max_payload),
    )
    return rows[0]



async def save_token_only(
    sha_hex: str,
    size: int,
    max_type: str,
    max_token: str,
    *,
    tg_unique_id: Optional[str] = None,
) -> None:
    """
    Сохраняем ТОЛЬКО max_token в БД (для случаев, когда файл слишком большой и мы не хотим хранить байты в S3).
    Важно: schema требует s3_key NOT NULL — используем синтетический ключ token-only/...
    """
    s3_key = f"token-only/{max_type}/{sha_hex}"
    await _upsert_row(
        sha_hex,
        size,
        s3_key,
        max_type,
        tg_unique_id=tg_unique_id,
        max_token=max_token,
    )


async def _get_row_by_sha(sha_hex: str, max_type: str) -> Optional[Dict[str, Any]]:
    rows = await aquery(
        """
        SELECT id, sha256, size_bytes, s3_key, max_type, tg_unique_id, max_token, max_payload
        FROM media_dedup
        WHERE sha256 = %s AND max_type = %s
        LIMIT 1
        """,
        (sha_hex, max_type),
    )
    return rows[0] if rows else None


# ---------- ПУБЛИЧНЫЕ ХЕЛПЕРЫ ----------


async def ensure_image_attachment(
    data: bytes,
    filename: Optional[str],
    mime_hint: Optional[str] = None,
    tg_unique_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Возвращает attachment для MAX:
      {"type": "image", "payload": {"url": "<presigned>"}}
    """
    sha_hex = _sha256(data)
    ext = _guess_ext(filename, mime_hint)
    s3_key = _hash_key(sha_hex, ext)

    row = await _get_row_by_sha(sha_hex, TYPE_IMAGE)
    if not row:
        # 1) Если в S3 такого объекта ещё нет — кладём
        if not await _head_exists_async(S3_BUCKET, s3_key):
            await _put_object_async(S3_BUCKET, s3_key, data, mime_hint)
        # 2) Обновляем/создаём запись в БД
        row = await _upsert_row(sha_hex, len(data), s3_key, TYPE_IMAGE, tg_unique_id=tg_unique_id)

    # На всякий случай проверяем, что объект по s3_key реально существует
    if not await _head_exists_async(S3_BUCKET, row["s3_key"]):
        await _put_object_async(S3_BUCKET, row["s3_key"], data, mime_hint)

    url = _presigned_url(S3_BUCKET, row["s3_key"], S3_PRESIGN_TTL)
    return {"type": "image", "payload": {"url": url}}


async def get_or_upload_token(
    max_kind: str,            # "file" | "audio" | "video"
    data: bytes,
    filename: Optional[str],
    mime_hint: Optional[str] = None,
    tg_unique_id: Optional[str] = None,
) -> str:
    """
    Возвращает token для file/audio/video.
    Сначала ищет по (sha256, type). Если нет — вызывает upload_* в MAX,
    кладёт объект в S3 по ключу-хэшу и сохраняет token.
    """
    if max_kind not in (TYPE_FILE, TYPE_AUDIO, TYPE_VIDEO):
        raise ValueError("max_kind must be file|audio|video")

    sha_hex = _sha256(data)
    ext = _guess_ext(filename, mime_hint)
    s3_key = _hash_key(sha_hex, ext)

    # Попробуем найти уже закэшированную запись
    row = await _get_row_by_sha(sha_hex, max_kind)
    if row and row.get("max_token"):
        await aquery("UPDATE media_dedup SET last_used_at = now() WHERE id = %s", (row["id"],))
        return row["max_token"]

    # Новой token ещё нет — загружаем в MAX
    if max_kind == TYPE_FILE:
        token = await max_send.upload_file_bytes(data, filename or f"file{ext}", mime_hint)
    elif max_kind == TYPE_AUDIO:
        token = await max_send.upload_audio_bytes(data, filename or f"audio{ext}", mime_hint)
    else:
        token = await max_send.upload_video_bytes(data, filename or f"video{ext}", mime_hint)

    # Сохраняем байты в S3 (если ещё не лежат)
    if not await _head_exists_async(S3_BUCKET, s3_key):
        await _put_object_async(S3_BUCKET, s3_key, data, mime_hint)

    # Обновляем/создаём запись в БД с max_token
    await _upsert_row(
        sha_hex,
        len(data),
        s3_key,
        max_kind,
        tg_unique_id=tg_unique_id,
        max_token=token,
    )
    return token

