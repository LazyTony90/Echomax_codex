#app/app/menu.py
import os
import re
import json
import html
import logging
import random
import string
import asyncio
from datetime import datetime, timezone
from typing import Optional, Tuple, List

from aiogram import Router, F
from aiogram.filters import CommandStart
from aiogram.enums import ChatType
from aiogram.fsm.state import StatesGroup, State
from aiogram.fsm.context import FSMContext
from aiogram.types import (
    Message, CallbackQuery, InlineKeyboardMarkup, MessageEntity, ChatMemberUpdated
)
from aiogram.utils.keyboard import InlineKeyboardBuilder

from app.config import Cfg
from app.db import db, aquery
from app.link_cache import (
    invalidate_exclusions_for_link,
    invalidate_rules_for_link,
    invalidate_all_for_link,
)
from app.link_router_cache import invalidate_source_links

# MAX API
import aiohttp
from aiohttp import ClientSession, ClientTimeout, TCPConnector
from app.max_send import get_max_http_session
from app.max_api import (
    resolve_destination,
    can_post_from_membership,
    MaxApiError
)

from app.payments_yookassa import (
    get_or_ask_email_for_user,
    save_user_email,
    create_initial_payment_for_link,
    disable_autopay_for_link,
    YK_SUBSCRIPTION_PRICE_RUB,
)

log = logging.getLogger(__name__)
router = Router()

TRIAL_DAYS = Cfg.TRIAL_DAYS
RULES_MAX = Cfg.LIMITS["max_rules_per_link"]
EXCL_MAX = Cfg.LIMITS["max_exclusions_per_link"]

# ------------------ FSM ------------------
class CreateLink(StatesGroup):
    name = State()
    source = State()
    platform = State()
    target_tg = State()
    target_max = State()

class CreateChatLink(StatesGroup):
    name = State()
    source_tg = State()
    target_max = State()

class AddExclusion(StatesGroup):
    waiting_text = State()

class AddRule(StatesGroup):
    input_from = State()
    input_to = State()

class PayEmail(StatesGroup):
    waiting_email = State()

# ------------------ Helpers ------------------
def kb_root(owner_id: int) -> InlineKeyboardMarkup:
    with db() as conn, conn.cursor() as cur:
        cur.execute("""
          select id,
                 coalesce(name, concat('Связка #', id)) as title,
                 coalesce(link_type, 'channel')          as link_type
            from channel_links
           where owner_tg_user_id = %s
           order by id
        """, (owner_id,))
        rows = cur.fetchall()

    kb = InlineKeyboardBuilder()
    kb.button(text="➕ Создать связку каналов", callback_data="link:create")
    kb.button(text="💬 Создать связку чатов TG-MAX", callback_data="chatlink:create")

    if rows:
        kb.button(text="—", callback_data="noop")
        for r in rows:
            lt = (r.get("link_type") or "channel").lower()
            title = r["title"]
            if lt == "chat":
                title = f"{title} (ЧАТЫ)"
            kb.button(text=title, callback_data=f"link:{r['id']}:menu")

    kb.adjust(1)
    return kb.as_markup()

async def ensure_user(tg_id: int) -> None:
    """
    Гарантируем наличие записи о пользователе в таблице users.
    Переведено на aquery, чтобы не блокировать event loop.
    """
    try:
        await aquery(
            "insert into users(tg_user_id) values (%s) on conflict do nothing",
            (tg_id,),
        )
    except Exception as e:
        # Это не критичная операция, поэтому ограничимся варнингом
        log.warning("ensure_user failed for %s: %s", tg_id, e)

@router.my_chat_member()
async def on_my_chat_member(event: ChatMemberUpdated):
    """
    Фиксируем в known_chats все чаты, куда бота добавили/удалили.
    Это нужно, чтобы приватные чаты можно было «тихо» находить по точному названию
    (try_resolve_chat_by_title_for_user использует known_chats).
    """
    try:
        chat = event.chat
        if not chat or not getattr(chat, "id", None):
            return

        new_member = getattr(event, "new_chat_member", None)
        new_status = ""
        try:
            new_status = str(getattr(new_member, "status", "")).lower()
        except Exception:
            new_status = ""

        is_member = new_status not in ("left", "kicked")

        chat_id = int(chat.id)
        chat_type = str(getattr(chat, "type", "") or "")
        title = getattr(chat, "title", None) or ""
        username = getattr(chat, "username", None) or None

        # upsert в known_chats
        await aquery(
            """
            INSERT INTO known_chats(chat_id, type, title, username, is_member, last_seen)
            VALUES (%s, %s, %s, %s, %s, now())
            ON CONFLICT (chat_id) DO UPDATE
                SET type = EXCLUDED.type,
                    title = EXCLUDED.title,
                    username = EXCLUDED.username,
                    is_member = EXCLUDED.is_member,
                    last_seen = now()
            """,
            (chat_id, chat_type, title, username, is_member),
        )

        log.info(
            "known_chats upsert via my_chat_member: chat_id=%s title=%r is_member=%s status=%s",
            chat_id, title, is_member, new_status,
        )
    except Exception as e:
        log.warning("on_my_chat_member failed: %s", e)

def extract_channel_from_forward(msg: Message) -> Optional[Tuple[int, str]]:
    # aiogram v3: forward_origin.chat.id
    fo = getattr(msg, "forward_origin", None)
    try:
        chat = getattr(fo, "chat", None)
        if chat and getattr(chat, "id", None):
            cid = chat.id
            title = getattr(chat, "title", None) or getattr(chat, "username", None) or str(cid)
            return (cid, title)
    except Exception:
        pass
    # старый путь: чаще срабатывает для каналов
    if getattr(msg, "forward_from_chat", None):
        try:
            cid = msg.forward_from_chat.id
            title = msg.forward_from_chat.title or msg.forward_from_chat.username or str(cid)
            return (cid, title)
        except Exception:
            pass
    return None

def _entity_type_str(e) -> str:
    """
    Аккуратно берём тип сущности как строку (учитываем Enum.value).
    """
    try:
        t = getattr(e, "type", None)
        return t.value if hasattr(t, "value") else str(t)
    except Exception:
        return ""


def first_text_link_url(msg: Message) -> Optional[str]:
    """
    Возвращает URL из первой «ссылочной» сущности в сообщении:
    - text_link (вшитая ссылка)
    - url (обычный http(s)-линк в тексте)
    """
    ents = getattr(msg, "entities", None) or []
    text = msg.text or ""

    for e in ents:
        etype = _entity_type_str(e).lower()

        # Вшитая ссылка: url хранится в e.url
        if etype == "text_link" and getattr(e, "url", None):
            return e.url

        # Обычный URL
        if etype == "url":
            url = getattr(e, "url", None)
            if url:
                return url

            # Иногда Telegram не заполняет e.url — достанем из текста
            try:
                off = int(getattr(e, "offset", 0))
                ln = int(getattr(e, "length", 0))
                if ln > 0:
                    return text[off : off + ln]
            except Exception:
                continue

    return None


def first_text_link_text(msg: Message) -> Optional[str]:
    """
    Возвращает текст первой «ссылочной» сущности (text_link/url).
    Например, для «Просто текст без ссылки <a href=...>ссылка</a>»
    вернёт 'ссылка'.
    """
    ents = getattr(msg, "entities", None) or []
    text = msg.text or ""

    for e in ents:
        etype = _entity_type_str(e).lower()
        if etype in ("text_link", "url"):
            try:
                off = int(getattr(e, "offset", 0))
                ln = int(getattr(e, "length", 0))
                if ln > 0:
                    return text[off : off + ln]
            except Exception:
                continue

    return None

async def bot_is_admin_in_channel(bot, chat_id: int) -> bool:
    try:
        admins = await bot.get_chat_administrators(chat_id)
        me = await bot.get_me()
        return any(a.user.id == me.id for a in admins)
    except Exception as e:
        log.warning("get_chat_administrators failed for %s: %s", chat_id, e)
        return False

def snip(s: str, n: int = 30) -> str:
    s = (s or "").replace("\n", " ")
    return (s[:n] + "…") if len(s) > n else s

def label_for_rule(r) -> str:
    typ = r["type"]
    idx = r["idx"]
    data = r["data"] or {}

    # Новая схема: храним from_plain/to_plain
    frm = data.get("from_plain") or data.get("from") or ""
    to = data.get("to_plain") or data.get("to") or ""

    if typ == "simple":
        return f"Правило {idx}: 📝 «{snip(frm)}» → «{snip(to)}»"
    if typ == "url_swap":
        return f"Правило {idx}: 🔗 {snip(data.get('from', ''))} → {snip(data.get('to', ''))}"
    if typ == "regex":
        return f"Правило {idx}: .* Regex"
    if typ == "hashtag_map":
        return f"Правило {idx}: #️⃣ Hashtags"
    return f"Правило {idx}: {typ}"


# --- Разбор источника для ЧАТОВ ---
_USERNAME_RE = re.compile(r'(?:^|[\s,])@([A-Za-z0-9_]{5,})\b')
_TME_USER_RE = re.compile(r'(?:https?://)?t\.me/([A-Za-z0-9_]{5,})\b', re.IGNORECASE)
_TME_C_RE = re.compile(r'(?:https?://)?t\.me/c/(\d+)/\d+\b', re.IGNORECASE)

async def try_resolve_chat_from_message(msg: Message) -> Optional[Tuple[int, str]]:
    """
    Пытаемся определить чат-источник:
      1) форвард с открытым источником (forward_origin.chat)
      2) ссылка t.me/c/<internal>/<msg> -> -100<internal> (если бот уже в этом чате)
      3) @username / t.me/<username> (публичные чаты)
      4) явный числовой id (-100...)
    """
    fx = extract_channel_from_forward(msg)
    if fx:
        return fx

    raw = (msg.text or "").strip()
    url = first_text_link_url(msg) or ""
    probe = url or raw

    # t.me/c/<id>/<msg>
    m = _TME_C_RE.search(probe)
    if m:
        internal = m.group(1)
        try:
            chat_id = int(f"-100{internal}")
            return (chat_id, f"t.me/c/{internal}")
        except Exception:
            pass

    # @username / t.me/<username>
    m2 = _USERNAME_RE.search(raw) or _TME_USER_RE.search(probe)
    if m2:
        uname = m2.group(1)
        try:
            ch = await msg.bot.get_chat(f"@{uname}")
            if ch and getattr(ch, "id", None):
                title = getattr(ch, "title", None) or getattr(ch, "username", None) or str(ch.id)
                return (ch.id, title)
        except Exception as e:
            log.info("get_chat by username failed (%s): %s", uname, e)

    # явный -100... id
    if raw and re.fullmatch(r'-100\d{5,}', raw):
        try:
            return (int(raw), raw)
        except Exception:
            pass

    return None

# --- «Тихий» поиск по названию без утечки приватных данных ---
def _norm(s: str) -> str:
    return re.sub(r'\s+', ' ', (s or '').strip().lower())

async def try_resolve_chat_by_title_for_user(msg: Message, title: str) -> Optional[int]:
    """
    Ищем ровно один чат с заданным названием, где:
      - бот состоит (known_chats.is_member = true),
      - и сам пользователь msg.from_user.id состоит (get_chat_member не left/kicked).
    Пользователю ничего не показываем; при неоднозначности/нуле — вернём None.
    """
    tnorm = _norm(title)
    if not tnorm:
        return None

    # Раньше здесь был блокирующий with db(), теперь — асинхронный запрос
    try:
        rows = await aquery(
            """
            select chat_id, title
              from known_chats
             where is_member = true
            """
        ) or []
    except Exception as e:
        log.warning("try_resolve_chat_by_title_for_user: DB query failed: %s", e)
        return None

    cands: List[int] = []
    for r in rows:
        if _norm(r.get("title") or "") == tnorm:
            cands.append(int(r["chat_id"]))
    if not cands:
        for r in rows:
            if tnorm in _norm(r.get("title") or ""):
                cands.append(int(r["chat_id"]))

    valid: List[int] = []
    for chat_id in cands[:25]:
        try:
            cm = await msg.bot.get_chat_member(chat_id, msg.from_user.id)
            st = str(getattr(cm, "status", "")).lower()
            if st not in ("left", "kicked"):
                valid.append(chat_id)
        except Exception:
            continue

    if len(valid) == 1:
        return valid[0]
    return None



# ------------------ Тексты/клавиатуры ------------------
def link_info_text(link_id: int) -> str:
    """
    Текст шапки настроек связки.
    По link_id сам ходит в БД за данными по связке и количеством правил/исключений.
    """
    with db() as conn, conn.cursor() as cur:
        # Основная информация о связке + названия чатов из known_chats
        cur.execute(
            """
            select cl.id,
                   cl.name,
                   cl.link_type,
                   cl.target_platform,
                   cl.enabled,
                   cl.paid_until,
                   cl.trial_until,
                   cl.is_trial,
                   cl.source_chat_id,
                   cl.target_chat_id,
                   sc.title as source_title,
                   tc.title as target_title
              from channel_links cl
         left join known_chats sc on sc.chat_id = cl.source_chat_id
         left join known_chats tc on tc.chat_id = cl.target_chat_id
             where cl.id = %s
            """,
            (link_id,),
        )
        link = cur.fetchone()

        if not link:
            return "Связка не найдена."

        # Количество правил замены
        cur.execute("select count(*) as c from rules where link_id = %s", (link_id,))
        rules_row = cur.fetchone()
        rules_count = int(rules_row["c"]) if rules_row and rules_row.get("c") is not None else 0

        # Количество исключений
        cur.execute(
            "select count(*) as c from link_exclusions where link_id = %s",
            (link_id,),
        )
        excl_row = cur.fetchone()
        excl_count = int(excl_row["c"]) if excl_row and excl_row.get("c") is not None else 0

    name = link.get("name") or f"Связка #{link_id}"
    link_type = (link.get("link_type") or "channel").lower()
    target_platform = (link.get("target_platform") or "tg").lower()
    enabled = bool(link.get("enabled"))

    paid_until = link.get("paid_until")
    trial_until = link.get("trial_until")
    is_trial = bool(link.get("is_trial"))

    src_id = link.get("source_chat_id")
    dst_id = link.get("target_chat_id")
    src_title = link.get("source_title") or ""
    dst_title = link.get("target_title") or ""

    now = datetime.now(timezone.utc)

    def _fmt(dt: Optional[datetime]) -> str:
        if not dt:
            return "—"
        if getattr(dt, "tzinfo", None) is None:
            dt = dt.replace(tzinfo=timezone.utc)
        local = dt.astimezone(timezone.utc)
        return local.strftime("%Y-%m-%d %H:%M UTC")

    lines: list[str] = []
    lines.append(f"<b>Настройки связки</b> «{html.escape(name)}» (#{link_id})")

    # Тип связки + платформа приёмника
    if link_type == "chat":
        lt_label = "ЧАТЫ TG ↔ MAX"
    else:
        lt_label = "КАНАЛЫ"

    if target_platform == "tg":
        dst_label = "Telegram"
    elif target_platform == "max":
        dst_label = "MAX"
    else:
        dst_label = target_platform.upper()

    lines.append(f"Тип: {lt_label}, приёмник: {dst_label}")

    # Информация об источнике/приёмнике
    if src_id or dst_id:
        lines.append("")

        if link_type == "chat":
            lines.append("<b>Чаты:</b>")
            if src_id:
                suffix = f" — {html.escape(src_title)}" if src_title else ""
                lines.append(f"• Telegram: <code>{src_id}</code>{suffix}")
            if dst_id:
                suffix = f" — {html.escape(dst_title)}" if dst_title else ""
                lines.append(f"• MAX: <code>{dst_id}</code>{suffix}")
        else:
            lines.append("<b>Каналы:</b>")
            if src_id:
                suffix = f" — {html.escape(src_title)}" if src_title else ""
                lines.append(f"• Источник: <code>{src_id}</code>{suffix}")
            if dst_id:
                suffix = f" — {html.escape(dst_title)}" if dst_title else ""
                lines.append(f"• Приёмник ({dst_label}): <code>{dst_id}</code>{suffix}")

    # Статус и оплата
    lines.append("")
    lines.append(f"Статус: {'⏩ активна(не на паузе)' if enabled else '⏸ на паузе'}")

    paid_str = _fmt(paid_until)
    trial_str = _fmt(trial_until)

    trial_active = False
    if is_trial:
        if trial_until is None:
            trial_active = True  # старые данные
        else:
            trial_active = trial_until > now

    # Сначала показываем активный триал (даже если paid_until заполнен триалом)
    if trial_active and trial_until:
        lines.append(f"🧪 Бесплатный пробный период до: <b>{trial_str}</b>")
    elif trial_active and trial_until is None:
        lines.append("🧪 Бесплатный пробный период: <b>активен</b> (старые данные)")
    elif paid_until:
        lines.append(f"Оплата действует до: <b>{paid_str}</b>")
    else:
        if is_trial and trial_until and trial_until <= now:
            lines.append("🧪 Пробный период завершён.")
        lines.append("Подписка: <b>не активна</b>")

    # Статистика по правилам
    lines.append("")
    lines.append(f"Правила замены: <b>{rules_count}</b>")
    lines.append(f"Правила исключения: <b>{excl_count}</b>")

    return "\n".join(lines)


def kb_link_menu(link_id: int) -> InlineKeyboardMarkup:
    with db() as conn, conn.cursor() as cur:
        cur.execute("select enabled, coalesce(link_type, 'channel') as link_type, source_chat_id from channel_links where id=%s", (link_id,))
        row = cur.fetchone()
    enabled = bool(row and row["enabled"]); link_type = (row.get("link_type") if row else "channel") or "channel"
    is_chat = link_type.lower() == "chat"
    kb = InlineKeyboardBuilder()
    kb.button(
        text="⏸ Поставить на паузу" if enabled else "▶️ Возобновить",
        callback_data=f"link:{link_id}:toggle",
    )
    if not is_chat:
        kb.button(text="🚫 Правила исключения", callback_data=f"link:{link_id}:excl")
        kb.button(text="🔁 Правила замены", callback_data=f"link:{link_id}:rules")
    kb.button(text="🗑 Удалить связку", callback_data=f"link:{link_id}:delete")
    kb.button(text="💳 Подписка", callback_data=f"pay:{link_id}:menu")
    kb.button(text="⬅️ Назад", callback_data="root")
    kb.adjust(1)
    return kb.as_markup()

def build_pay_menu_text_and_kb(link_id: int, tg_user_id: int) -> tuple[str, InlineKeyboardMarkup]:
    with db() as conn, conn.cursor() as cur:
        cur.execute(
            """
            select name, paid_until, trial_until, is_trial
              from channel_links
             where id = %s
            """,
            (link_id,),
        )
        link = cur.fetchone()

        if not link:
            text = "Связка не найдена."
            kb = InlineKeyboardBuilder()
            kb.button(text="⬅️ Назад", callback_data="root")
            kb.adjust(1)
            return text, kb.as_markup()

        cur.execute(
            """
            select la.enabled,
                   la.next_charge_at
              from link_autopay la
             where la.link_id = %s
               and la.tg_user_id = %s
             order by la.id desc
             limit 1
            """,
            (link_id, tg_user_id),
        )
        ap = cur.fetchone()

    name = link.get("name") or f"Связка #{link_id}"
    paid_until = link.get("paid_until")
    trial_until = link.get("trial_until")
    is_trial = bool(link.get("is_trial"))

    now = datetime.now(timezone.utc)

    def _fmt(dt: Optional[datetime]) -> str:
        if not dt:
            return "—"
        if getattr(dt, "tzinfo", None) is None:
            dt = dt.replace(tzinfo=timezone.utc)
        local = dt.astimezone(timezone.utc)
        return local.strftime("%Y-%m-%d %H:%M UTC")

    # Статус подписки
    if paid_until:
        paid_dt = paid_until if getattr(paid_until, "tzinfo", None) else paid_until.replace(tzinfo=timezone.utc)
        active_sub = now <= paid_dt
        paid_line = f"{'✅ активна' if active_sub else '❌ закончилась'} до {html.escape(_fmt(paid_until))}"
    else:
        paid_line = "не оплачена"

    # Статус триала — показываем строку только пока триал активен
    trial_block: list[str] = []
    if trial_until:
        trial_dt = trial_until if getattr(trial_until, "tzinfo", None) else trial_until.replace(tzinfo=timezone.utc)
        if now <= trial_dt:
            trial_block.append(f"Пробный период: ✅ активен до {html.escape(_fmt(trial_until))}")
    elif is_trial:
        # Старые связки, где is_trial=true, но нет trial_until — считаем триал активным
        trial_block.append("Пробный период: ✅ активен (старые данные)")

    # Статус автопродления (без деталей карты)
    ap_line = "не подключено"
    ap_enabled = False
    if ap:
        ap_enabled = bool(ap.get("enabled"))
        next_charge_at = ap.get("next_charge_at")
        if ap_enabled:
            ap_line = "✅ включено"
            if next_charge_at:
                ap_line += f", следующая попытка списания около {html.escape(_fmt(next_charge_at))}"
        else:
            ap_line = "⏸ отключено"

    lines: list[str] = [
        f"<b>Подписка для связки «{name}»</b>",
        "",
        f"Подписка: {paid_line}",
        f"Автопродление: {ap_line}",
    ]

    # Вставляем блок про триал только если он действительно активен
    if trial_block:
        lines.extend(trial_block)

    lines.extend(
        [
            "",
            "После оплаты будет подключено автопродление раз в 1 месяц.",
            "Автосписания можно отключить в этом меню.",
        ]
    )

    kb = InlineKeyboardBuilder()
    kb.button(
        text=f"Оплатить 1 месяц ({YK_SUBSCRIPTION_PRICE_RUB} ₽)",
        callback_data=f"pay:{link_id}:start",
    )
    if ap_enabled:
        kb.button(
            text="⛔ Остановить автопродление",
            callback_data=f"pay:{link_id}:stop_confirm",
        )
    kb.button(text="⬅️ Назад", callback_data=f"link:{link_id}:menu")
    kb.adjust(1)

    return "\n".join(lines), kb.as_markup()


# ------------------ Старт / корень ------------------
@router.message(CommandStart(), F.chat.type == ChatType.PRIVATE)
async def cmd_start(msg: Message, state: FSMContext):
    await ensure_user(msg.from_user.id)
    await state.clear()
    root_kb = await asyncio.to_thread(kb_root, msg.from_user.id)
    await msg.answer(
        "Привет! Я помогу зеркалировать посты между каналами и чатами.",
        reply_markup=root_kb,
    )

@router.callback_query(F.data == "root")
async def cb_root(cq: CallbackQuery):
    root_kb = await asyncio.to_thread(kb_root, cq.from_user.id)
    await cq.message.edit_text("Главное меню:", reply_markup=root_kb)
    await cq.answer()

# ------------------ Создание связки каналов ------------------
def kb_choose_platform() -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    kb.button(text="Telegram → Telegram", callback_data="cr:plat:tg")
    kb.button(text="Telegram → MAX", callback_data="cr:plat:max")
    kb.adjust(1); return kb.as_markup()

@router.callback_query(F.data == "link:create")
async def cb_link_create(cq: CallbackQuery, state: FSMContext):
    await state.set_state(CreateLink.name)
    await cq.message.edit_text("Дайте название связке (например, «Новости → Архив»).")
    await cq.answer()

@router.message(CreateLink.name, F.chat.type == ChatType.PRIVATE)
async def cr_name(msg: Message, state: FSMContext):
    name = (msg.text or "").strip()
    if not name:
        return await msg.answer("Название не должно быть пустым. Отправьте ещё раз.")
    await state.update_data(name=name)
    await state.set_state(CreateLink.source)
    await msg.answer(
        "Теперь добавьте меня админом в <b>канал-источник</b> и перешлите сюда ЛЮБОЕ сообщение из него.\n"
        "Важно: перешлите <u>с указанием автора</u>, чтобы я увидел ID канала."
    )

@router.message(CreateLink.source, F.chat.type == ChatType.PRIVATE)
async def cr_source(msg: Message, state: FSMContext):
    ch = extract_channel_from_forward(msg)
    if not ch:
        return await msg.answer("Не вижу данных форварда канала. Перешлите ещё раз, не скрывая источник.")
    src_id, src_title = ch
    await state.update_data(source_id=src_id, source_title=src_title)
    ok_src = await bot_is_admin_in_channel(msg.bot, src_id)
    txt_ok = "✅ вижу себя админом." if ok_src else "⚠️ не вижу себя админом — добавьте меня админо"
    await state.set_state(CreateLink.platform)
    await msg.answer(f"Источник: <code>{src_id}</code> — {txt_ok}\nВыберите, куда пересылать:", reply_markup=kb_choose_platform())

# ------------------ Создание связки ЧАТОВ TG-MAX ------------------
@router.callback_query(F.data == "chatlink:create")
async def cb_chatlink_create(cq: CallbackQuery, state: FSMContext):
    await state.set_state(CreateChatLink.name)
    await cq.message.edit_text(
        "Создание связки <b>чатов Telegram ↔ MAX</b>.\n"
        "Сначала дайте ей название (например, «Общий чат»)."
    )
    await cq.answer()

@router.message(CreateChatLink.name, F.chat.type == ChatType.PRIVATE)
async def cr_chat_name(msg: Message, state: FSMContext):
    name = (msg.text or "").strip()
    if not name:
        return await msg.answer("Название не должно быть пустым. Отправьте ещё раз.")
    await state.update_data(name=name)
    await state.set_state(CreateChatLink.source_tg)
    await msg.answer(
        "Теперь добавьте меня в <b>чат Telegram</b>, который хотите зеркалировать.\n"
        "Варианты (⚠️ для <u>публичных</u> чатов):\n"
        " • Переслать сюда сообщение <i>с открытым источником</i>,\n"
        " • Прислать ссылку на сообщение вида <code>https://t.me/c/XXXX/NNN</code>,\n"
        " • Прислать <b>@username</b> (или <code>t.me/username</code>).\n"
        "Для <u>приватных</u> чатов лучше прислать <b>точное название</b> чата (я определю его «тихо») или использовать <b>привязку по коду</b>."
    )
    # только кнопка кода (без «известных чатов»)
    kb = InlineKeyboardBuilder()
    kb.button(text="🔐 Привязать через код", callback_data="chatlink:gen_code")
    kb.adjust(1)
    await msg.answer("Дополнительно:", reply_markup=kb.as_markup())

@router.message(CreateChatLink.source_tg, F.chat.type == ChatType.PRIVATE)
async def cr_chat_source_tg(msg: Message, state: FSMContext):
    # 1) пробуем автоматически (форвард/ссылка/юзернейм/-100id)
    ch = await try_resolve_chat_from_message(msg)

    # 2) «тихий» поиск по названию (для приватных)
    if not ch and (msg.text or "").strip():
        title = (msg.text or "").strip()

        # 1-я попытка сразу
        resolved = await try_resolve_chat_by_title_for_user(msg, title)

        # 2-я попытка с небольшой задержкой:
        # чтобы успел обработаться my_chat_member и чат появился в known_chats
        if not resolved:
            await asyncio.sleep(0.8)
            resolved = await try_resolve_chat_by_title_for_user(msg, title)

        if resolved:
            ch = (resolved, "by_title")

    if not ch:
        return await msg.answer(
            "Не удалось определить чат по вашему сообщению.\n"
            "Подсказка:\n"
            " • Публичные: форвард с источником / <code>t.me/c/...</code> / @username,\n"
            " • Приватные: точное <b>название</b> или «🔐 Привязать через код»."
        )

    src_id, _ = ch
    await state.update_data(source_id=src_id)

    ok_src = await bot_is_admin_in_channel(msg.bot, src_id)
    hint = "✅ Вижу себя админом/участником." if ok_src else "⚠️ Не вижу себя админом. Добавьте мен"

    await state.set_state(CreateChatLink.target_max)
    await msg.answer("Источник определён.\n" + hint + "\n\nТеперь добавьте бота администратором в чат MAX (ссылка на бота https://max.ru/id781146210711_bot ), и после этого пришлите сюда точное название или ссылку ил @username или ID чата MAX.")

# --- Привязка через код ---
def _gen_code(n: int = 6) -> str:
    alphabet = string.ascii_uppercase + string.digits
    return "".join(random.choices(alphabet, k=n))

@router.callback_query(F.data == "chatlink:gen_code")
async def cb_gen_code(cq: CallbackQuery):
    code = _gen_code()

    try:
        await aquery(
            """
            insert into pending_chat_links(code, owner_tg_user_id)
            values (%s,%s)
            on conflict (code) do nothing
            """,
            (code, cq.from_user.id),
        )
    except Exception as e:
        log.warning("cb_gen_code: failed to insert pending_chat_links: %s", e)

    kb = InlineKeyboardBuilder()
    kb.button(text="🔎 Проверить привязку", callback_data=f"chatlink:check_code:{code}")
    kb.button(text="Сгенерировать новый код", callback_data="chatlink:gen_code")
    kb.adjust(1)
    await cq.message.edit_text(
        "✅ Код сгенерирован.\n"
        f"1) Добавьте бота в нужный чат Telegram (если ещё не добавили);\n"
        f"2) Напишите в чат команду: <code>/bind {code}</code> (отправьте как обычное сообщение);\n"
        "3) Вернитесь сюда и нажмите «🔎 Проверить привязку».",
        reply_markup=kb.as_markup()
    )
    await cq.answer()

@router.callback_query(F.data.startswith("chatlink:check_code:"))
async def cb_check_code(cq: CallbackQuery, state: FSMContext):
    code = cq.data.split(":")[-1]
    try:
        rows = await aquery(
            "select source_chat_id from pending_chat_links where code=%s and owner_tg_user_id=%s",
            (code, cq.from_user.id),
        )
        row = rows[0] if rows else None
    except Exception as e:
        log.warning("cb_check_code: DB query failed: %s", e)
        row = None

    if not row:
        await cq.answer("Код не найден. Сгенерируйте новый.", show_alert=True); return
    if not row["source_chat_id"]:
        await cq.answer("Чат ещё не привязан. В нужном чате отправьте /bind КОД.", show_alert=True); return

    src_id = int(row["source_chat_id"])
    await state.update_data(source_id=src_id)
    await state.set_state(CreateChatLink.target_max)
    await cq.message.edit_text(
        f"Источник подтверждён через код: <code>{src_id}</code>\nТеперь укажите чат MAX (ссылка/@username/ID)."
    )
    await cq.answer()

# --- MAX приёмник для чатов: создаём связку и ВСЕГДА даём триал на 2 дня ---
@router.message(CreateChatLink.target_max, F.chat.type == ChatType.PRIVATE)
async def cr_chat_target_max(msg: Message, state: FSMContext):
    raw = (msg.text or "").strip()
    if not raw:
        return await msg.answer("Пусто. Пришлите ссылку/@username/название или числовой chat_id чата MAX.")
    data = await state.get_data()
    name = data["name"]; src_id = int(data["source_id"])
    ok_src = await bot_is_admin_in_channel(msg.bot, src_id)
    try:
        session = get_max_http_session()
        max_chat_id, member = await resolve_destination(session, raw)
        if not can_post_from_membership(member):
            return await msg.answer(
                "Я нашёл чат MAX, но у моего бота недостаточно прав для отправки сообщений.\n"
                "Добавьте бота администратором (или выдайте право писать сообщения) и попробуйте снова."
            )
    except MaxApiError as e:
        return await msg.answer(
            "Ошибка MAX API: " + str(e) +
            "\n\nПодсказка: добавьте моего бота в чат MAX и используйте точное название/ссылку/ID."
        )
    except Exception as e:
        log.exception("MAX API chat check failed: %s", e)
        return await msg.answer("Не удалось проверить чат MAX. Попробуйте ещё раз.")

    def _insert_chat_link() -> tuple[int, bool, bool]:
        """
        Создание связки ЧАТОВ TG ↔ MAX с учётом:
        - уже существующей связки (не создаём дубль),
        - истории триалов.
        Возвращает (link_id, created, trial_active_now).
        """
        now_utc = datetime.now(timezone.utc)
        with db() as conn, conn.cursor() as cur:
            # Сначала проверяем, нет ли уже такой связки
            cur.execute(
                """
                select id, is_trial, trial_until
                  from channel_links
                 where owner_tg_user_id = %s
                   and source_chat_id = %s
                   and target_chat_id = %s
                """,
                (msg.from_user.id, src_id, max_chat_id),
            )
            existing = cur.fetchone()
            if existing:
                tid = existing.get("trial_until")
                is_trial = bool(existing.get("is_trial"))
                trial_active = False
                if is_trial:
                    if tid is None:
                        trial_active = True
                    else:
                        dt = tid if getattr(tid, "tzinfo", None) else tid.replace(tzinfo=timezone.utc)
                        trial_active = now_utc <= dt
                return existing["id"], False, trial_active

            # Пытаемся зафиксировать первый триал для этой связки
            cur.execute(
                """
                insert into link_trials(
                    owner_tg_user_id,
                    source_chat_id,
                    target_chat_id,
                    target_platform,
                    link_type
                )
                values (%s, %s, %s, 'max', 'chat')
                on conflict (owner_tg_user_id, source_chat_id, target_chat_id, target_platform, link_type)
                    do nothing
                returning id
                """,
                (msg.from_user.id, src_id, max_chat_id),
            )
            trial_row = cur.fetchone()

            trial_active = False
            if trial_row:
                # Первый раз — даём триал, как раньше
                cur.execute(
                    """
                    insert into channel_links(
                        name, owner_tg_user_id,
                        source_chat_id, target_chat_id,
                        target_platform, enabled, link_type,
                        is_trial, trial_until, paid_until
                    )
                    values (%s, %s, %s, %s, 'max', true, 'chat',
                            true,
                            now() + (%s || ' days')::interval,
                            now() + (%s || ' days')::interval)
                    returning id, is_trial, trial_until
                    """,
                    (name, msg.from_user.id, src_id, max_chat_id, str(TRIAL_DAYS), str(TRIAL_DAYS)),
                )
                row = cur.fetchone()
                tid = row.get("trial_until")
                is_trial = bool(row.get("is_trial"))
                if is_trial:
                    if tid is None:
                        trial_active = True
                    else:
                        dt = tid if getattr(tid, "tzinfo", None) else tid.replace(tzinfo=timezone.utc)
                        trial_active = now_utc <= dt
                return row["id"], True, trial_active
            else:
                # Триал уже был — создаём связку без бесплатного периода
                cur.execute(
                    """
                    insert into channel_links(
                        name, owner_tg_user_id,
                        source_chat_id, target_chat_id,
                        target_platform, enabled, link_type,
                        is_trial, trial_until, paid_until
                    )
                    values (%s, %s, %s, %s, 'max', true, 'chat',
                            false, null, null)
                    returning id, is_trial, trial_until
                    """,
                    (name, msg.from_user.id, src_id, max_chat_id),
                )
                row = cur.fetchone()
                return row["id"], True, False

    link_id, created, trial_active = await asyncio.to_thread(_insert_chat_link)

    # Инвалидируем кэш по источнику
    try:
        invalidate_source_links(src_id)
    except Exception as e:
        log.warning("cr_chat_target_max: failed to invalidate cache: %s", e)

    warn = []
    if not ok_src:
        warn.append("• я не вижу себя админом/участником в чате Telegram")
    extra = ("\n\n⚠️ " + "\n".join(warn)) if warn else ""

    if created:
        head = (
            f"Создана связка <b>{name}</b> (чаты Telegram ↔ MAX)\n"
            f"Чат Telegram: <code>{src_id}</code>\n"
            f"Чат MAX: <code>{max_chat_id}</code>\n"
        )
    else:
        head = (
            f"Связка <b>{name}</b> (чаты Telegram ↔ MAX) уже существовала.\n"
            f"Чат Telegram: <code>{src_id}</code>\n"
            f"Чат MAX: <code>{max_chat_id}</code>\n"
        )

    if trial_active and created:
        trial_line = f"🔥 Активирован пробный период: <b>{TRIAL_DAYS} дн.</b>"
    elif trial_active and not created:
        trial_line = "Пробный период для этой связки всё ещё активен."
    else:
        trial_line = "Пробный период для этой связки уже был использован или завершён."

    await state.clear()
    link_kb = await asyncio.to_thread(kb_link_menu, link_id)
    await msg.answer(
        head + trial_line + extra,
        reply_markup=link_kb,
    )

# ------------------ Приёмники для связки каналов: всегда даём триал на 2 дня ------------------
@router.callback_query(F.data == "cr:plat:tg")
async def cr_choose_tg(cq: CallbackQuery, state: FSMContext):
    await state.set_state(CreateLink.target_tg)
    await cq.message.edit_text("Добавьте меня админом в <b>канал-приёмник</b> (Telegram) и перешлите сюда ЛЮБОЕ сообщение из него.")
    await cq.answer()

@router.callback_query(F.data == "cr:plat:max")
async def cr_choose_max(cq: CallbackQuery, state: FSMContext):
    await state.set_state(CreateLink.target_max)
    await cq.message.edit_text(
        "Ок. Теперь вам нужно добавить бота EchoMAX администратором в ваш канал MAX.\n"
        "Ссылка на бота в мессенджере MAX: https://max.ru/id781146210711_bot \n"
        "После этого пришлите ссылку/@username/название или числовой chat_id канала MAX.\n"
        "Я проверю наличие прав бота на публикацию."
    )
    await cq.answer()

@router.message(CreateLink.target_tg, F.chat.type == ChatType.PRIVATE)
async def cr_target_tg(msg: Message, state: FSMContext):
    ch = extract_channel_from_forward(msg)
    if not ch:
        return await msg.answer("Не вижу данных форварда канала. Перешлите ещё раз, не скрывая источник.")
    dst_id, _ = ch
    data = await state.get_data(); name = data["name"]; src_id = int(data["source_id"])
    ok_src = await bot_is_admin_in_channel(msg.bot, src_id)
    ok_dst = await bot_is_admin_in_channel(msg.bot, dst_id)

    def _insert_link() -> tuple[int, bool, bool]:
        """
        Создание связки КАНАЛОВ TG → TG с учётом:
        - уже существующей связки,
        - истории триалов.
        Возвращает (link_id, created, trial_active_now).
        """
        now_utc = datetime.now(timezone.utc)
        with db() as conn, conn.cursor() as cur:
            # Проверяем, нет ли уже такой связки
            cur.execute(
                """
                select id, is_trial, trial_until
                  from channel_links
                 where owner_tg_user_id = %s
                   and source_chat_id = %s
                   and target_chat_id = %s
                """,
                (msg.from_user.id, src_id, dst_id),
            )
            existing = cur.fetchone()
            if existing:
                tid = existing.get("trial_until")
                is_trial = bool(existing.get("is_trial"))
                trial_active = False
                if is_trial:
                    if tid is None:
                        trial_active = True
                    else:
                        dt = tid if getattr(tid, "tzinfo", None) else tid.replace(tzinfo=timezone.utc)
                        trial_active = now_utc <= dt
                return existing["id"], False, trial_active

            cur.execute(
                """
                insert into link_trials(
                    owner_tg_user_id,
                    source_chat_id,
                    target_chat_id,
                    target_platform,
                    link_type
                )
                values (%s, %s, %s, 'tg', 'channel')
                on conflict (owner_tg_user_id, source_chat_id, target_chat_id, target_platform, link_type)
                    do nothing
                returning id
                """,
                (msg.from_user.id, src_id, dst_id),
            )
            trial_row = cur.fetchone()

            if trial_row:
                cur.execute(
                    """
                    insert into channel_links(
                        name, owner_tg_user_id,
                        source_chat_id, target_chat_id,
                        enabled, link_type,
                        is_trial, trial_until, paid_until
                    )
                    values (%s, %s, %s, %s, true, 'channel',
                            true,
                            now() + (%s || ' days')::interval,
                            now() + (%s || ' days')::interval)
                    returning id, is_trial, trial_until
                    """,
                    (name, msg.from_user.id, src_id, dst_id, str(TRIAL_DAYS), str(TRIAL_DAYS)),
                )
                row = cur.fetchone()
                tid = row.get("trial_until")
                is_trial = bool(row.get("is_trial"))
                trial_active = False
                if is_trial:
                    if tid is None:
                        trial_active = True
                    else:
                        dt = tid if getattr(tid, "tzinfo", None) else tid.replace(tzinfo=timezone.utc)
                        trial_active = now_utc <= dt
                return row["id"], True, trial_active
            else:
                cur.execute(
                    """
                    insert into channel_links(
                        name, owner_tg_user_id,
                        source_chat_id, target_chat_id,
                        enabled, link_type,
                        is_trial, trial_until, paid_until
                    )
                    values (%s, %s, %s, %s, true, 'channel',
                            false, null, null)
                    returning id, is_trial, trial_until
                    """,
                    (name, msg.from_user.id, src_id, dst_id),
                )
                row = cur.fetchone()
                return row["id"], True, False

    link_id, created, trial_active = await asyncio.to_thread(_insert_link)

    # Инвалидируем кэш по источнику
    try:
        invalidate_source_links(src_id)
    except Exception as e:
        log.warning("cr_target_tg: failed to invalidate cache: %s", e)

    warn = []
    if not ok_src: warn.append("• я не вижу себя админом в канале-источнике (Telegram)")
    if not ok_dst: warn.append("• я не вижу себя админом в канале-приёмнике (Telegram)")
    extra = ("\n\n⚠️ " + "\n".join(warn)) if warn else ""

    if created:
        head = (
            f"Создана связка <b>{name}</b> (Telegram → Telegram)\n"
            f"Источник: <code>{src_id}</code>\n"
            f"Приёмник: <code>{dst_id}</code>\n"
        )
    else:
        head = (
            f"Связка <b>{name}</b> (Telegram → Telegram) уже существовала.\n"
            f"Источник: <code>{src_id}</code>\n"
            f"Приёмник: <code>{dst_id}</code>\n"
        )

    if trial_active and created:
        trial_line = f"🔥 Активирован пробный период: <b>{TRIAL_DAYS} дн.</b>"
    elif trial_active and not created:
        trial_line = "Пробный период для этой связки всё ещё активен."
    else:
        trial_line = "Пробный период для этой связки уже был использован или завершён."

    await state.clear()
    link_kb = await asyncio.to_thread(kb_link_menu, link_id)
    await msg.answer(
        head + trial_line + extra,
        reply_markup=link_kb,
    )

@router.message(CreateLink.target_max, F.chat.type == ChatType.PRIVATE)
async def cr_target_max(msg: Message, state: FSMContext):
    raw = (msg.text or "").strip()
    if not raw:
        return await msg.answer("Пусто. Пришлите ссылку/@username/название или числовой chat_id канала MAX.")
    data = await state.get_data()
    name = data["name"]; src_id = int(data["source_id"])
    ok_src = await bot_is_admin_in_channel(msg.bot, src_id)
    try:
        session = get_max_http_session()
        max_chat_id, member = await resolve_destination(session, raw)
        if not can_post_from_membership(member):
            return await msg.answer(
                "Я нашёл канал MAX, но у моего бота недостаточно прав для публикации.\n"
                "Добавьте бота администратором (или выдайте право писать сообщения) и попробуйте снова."
            )
    except MaxApiError as e:
        return await msg.answer(
            "Ошибка MAX API: " + str(e) +
            "\n\nПодсказка: добавьте моего бота в канал MAX и используйте точное название/ссылку/ID."
        )
    except Exception as e:
        log.exception("MAX check failed: %s", e)
        return await msg.answer("Не удалось проверить канал MAX. Попробуйте ещё раз через минуту.")

    def _insert_link() -> tuple[int, bool, bool]:
        """
        Создание связки КАНАЛОВ TG → MAX с учётом:
        - уже существующей связки,
        - истории триалов.
        Возвращает (link_id, created, trial_active_now).
        """
        now_utc = datetime.now(timezone.utc)
        with db() as conn, conn.cursor() as cur:
            # Проверяем существующую связку
            cur.execute(
                """
                select id, is_trial, trial_until
                  from channel_links
                 where owner_tg_user_id = %s
                   and source_chat_id = %s
                   and target_chat_id = %s
                """,
                (msg.from_user.id, src_id, max_chat_id),
            )
            existing = cur.fetchone()
            if existing:
                tid = existing.get("trial_until")
                is_trial = bool(existing.get("is_trial"))
                trial_active = False
                if is_trial:
                    if tid is None:
                        trial_active = True
                    else:
                        dt = tid if getattr(tid, "tzinfo", None) else tid.replace(tzinfo=timezone.utc)
                        trial_active = now_utc <= dt
                return existing["id"], False, trial_active

            cur.execute(
                """
                insert into link_trials(
                    owner_tg_user_id,
                    source_chat_id,
                    target_chat_id,
                    target_platform,
                    link_type
                )
                values (%s, %s, %s, 'max', 'channel')
                on conflict (owner_tg_user_id, source_chat_id, target_chat_id, target_platform, link_type)
                    do nothing
                returning id
                """,
                (msg.from_user.id, src_id, max_chat_id),
            )
            trial_row = cur.fetchone()

            if trial_row:
                cur.execute(
                    """
                    insert into channel_links(
                        name, owner_tg_user_id,
                        source_chat_id, target_chat_id,
                        target_platform, enabled, link_type,
                        is_trial, trial_until, paid_until
                    )
                    values (%s, %s, %s, %s, 'max', true, 'channel',
                            true,
                            now() + (%s || ' days')::interval,
                            now() + (%s || ' days')::interval)
                    returning id, is_trial, trial_until
                    """,
                    (name, msg.from_user.id, src_id, max_chat_id, str(TRIAL_DAYS), str(TRIAL_DAYS)),
                )
                row = cur.fetchone()
                tid = row.get("trial_until")
                is_trial = bool(row.get("is_trial"))
                trial_active = False
                if is_trial:
                    if tid is None:
                        trial_active = True
                    else:
                        dt = tid if getattr(tid, "tzinfo", None) else tid.replace(tzinfo=timezone.utc)
                        trial_active = now_utc <= dt
                return row["id"], True, trial_active
            else:
                cur.execute(
                    """
                    insert into channel_links(
                        name, owner_tg_user_id,
                        source_chat_id, target_chat_id,
                        target_platform, enabled, link_type,
                        is_trial, trial_until, paid_until
                    )
                    values (%s, %s, %s, %s, 'max', true, 'channel',
                            false, null, null)
                    returning id, is_trial, trial_until
                    """,
                    (name, msg.from_user.id, src_id, max_chat_id),
                )
                row = cur.fetchone()
                return row["id"], True, False

    link_id, created, trial_active = await asyncio.to_thread(_insert_link)

    # Инвалидируем кэш по источнику
    try:
        invalidate_source_links(src_id)
    except Exception as e:
        log.warning("cr_target_max: failed to invalidate cache: %s", e)

    warn = []
    if not ok_src: warn.append("• я не вижу себя админом в канале-источнике (Telegram)")
    extra = ("\n\n⚠️ " + "\n".join(warn)) if warn else ""

    if created:
        head = (
            f"Создана связка <b>{name}</b> (Telegram → MAX)\n"
            f"Источник (Telegram): <code>{src_id}</code>\n"
            f"Приёмник (MAX): <code>{max_chat_id}</code>\n"
        )
    else:
        head = (
            f"Связка <b>{name}</b> (Telegram → MAX) уже существовала.\n"
            f"Источник (Telegram): <code>{src_id}</code>\n"
            f"Приёмник (MAX): <code>{max_chat_id}</code>\n"
        )

    if trial_active and created:
        trial_line = f"🔥 Активирован пробный период: <b>{TRIAL_DAYS} дн.</b>"
    elif trial_active and not created:
        trial_line = "Пробный период для этой связки всё ещё активен."
    else:
        trial_line = "Пробный период для этой связки уже был использован или завершён."

    await state.clear()
    link_kb = await asyncio.to_thread(kb_link_menu, link_id)
    await msg.answer(
        head + trial_line + extra,
        reply_markup=link_kb,
    )

# ------------------ Исключения/Правила/Удаление/Оплата ------------------
@router.callback_query(F.data.startswith("link:") & F.data.endswith(":menu"))
async def cb_link_menu(cq: CallbackQuery):
    link_id = int(cq.data.split(":")[1])
    text = await asyncio.to_thread(link_info_text, link_id)
    kb = await asyncio.to_thread(kb_link_menu, link_id)
    await cq.message.edit_text(text, reply_markup=kb)
    await cq.answer()

@router.callback_query(F.data.startswith("link:") & F.data.endswith(":toggle"))
async def cb_link_toggle(cq: CallbackQuery):
    link_id = int(cq.data.split(":")[1])

    def _toggle():
        with db() as conn, conn.cursor() as cur:
            cur.execute(
                """
                update channel_links
                   set enabled = not enabled,
                       auto_paused = false
                 where id = %s
             returning enabled, source_chat_id
                """,
                (link_id,),
            )
            return cur.fetchone()

    row = await asyncio.to_thread(_toggle)
    if not row:
        return await cq.answer("Связка не найдена.")

    # Инвалидируем кэш по источнику
    try:
        invalidate_source_links(row["source_chat_id"])
    except Exception as e:
        log.warning("cb_link_toggle: failed to invalidate cache: %s", e)

    text = await asyncio.to_thread(link_info_text, link_id)
    kb = await asyncio.to_thread(kb_link_menu, link_id)
    await cq.message.edit_text(text, reply_markup=kb)
    await cq.answer("Включена" if row["enabled"] else "Поставлена на паузу")

def kb_excl_menu(link_id: int) -> InlineKeyboardMarkup:
    with db() as conn, conn.cursor() as cur:
        cur.execute("select id, token from link_exclusions where link_id=%s order by id", (link_id,))
        rows = cur.fetchall()
    kb = InlineKeyboardBuilder()
    kb.button(text="➕ Создать правило исключения", callback_data=f"link:{link_id}:excl:add")
    for i, r in enumerate(rows, start=1):
        kb.button(text=f"Правило {i}: {snip(r['token'], 32)}", callback_data=f"link:{link_id}:excl:item:{r['id']}")
    kb.button(text="⬅️ Назад", callback_data=f"link:{link_id}:menu")
    kb.adjust(1); return kb.as_markup()

@router.callback_query(F.data.startswith("link:") & F.data.endswith(":excl"))
async def cb_excl_root(cq: CallbackQuery):
    link_id = int(cq.data.split(":")[1])
    kb = await asyncio.to_thread(kb_excl_menu, link_id)
    text = (
        "<b>Правила исключения</b>\n\n"
        "Если в исходном сообщении встречается указанная строка/хэштег/эмодзи — "
        "такое сообщение <b>не пересылается</b>.\n"
        "Проверка идёт по простому вхождению текста.\n"
        "Максимальное количество правил исключения - <b>2</b>\n\n"
        "Ниже — список правил исключения для этой связки:"
    )
    await cq.message.edit_text(text, reply_markup=kb)
    await cq.answer()

@router.callback_query(F.data.startswith("link:") & F.data.endswith(":excl:add"))
async def cb_excl_add(cq: CallbackQuery, state: FSMContext):
    link_id = int(cq.data.split(":")[1])

    try:
        rows = await aquery(
            "select count(*) as c from link_exclusions where link_id=%s",
            (link_id,),
        )
        cnt = int(rows[0]["c"]) if rows else 0
    except Exception as e:
        log.warning("cb_excl_add: DB query failed: %s", e)
        cnt = EXCL_MAX  # на всякий случай запретим, чтобы не накосячить

    if cnt >= EXCL_MAX:
        await cq.answer("Лимит правил исключения достигнут", show_alert=True)
        return

    await state.set_state(AddExclusion.waiting_text)
    await state.update_data(link_id=link_id)
    await cq.message.edit_text("Отправьте строку/хэштег/эмодзи. Если встречается — пост пропускается.")
    await cq.answer()

@router.message(AddExclusion.waiting_text, F.chat.type == ChatType.PRIVATE)
async def excl_add_value(msg: Message, state: FSMContext):
    data = await state.get_data(); link_id = int(data["link_id"])
    token = (msg.text or "").strip()
    if not token:
        return await msg.answer("Пусто. Пришлите текст фильтра.")

    try:
        await aquery(
            "insert into link_exclusions(link_id, token) values (%s,%s) on conflict do nothing",
            (link_id, token),
        )
    except Exception as e:
        log.warning("excl_add_value: insert failed for link_id=%s: %s", link_id, e)

    invalidate_exclusions_for_link(link_id)
    await state.clear()
    kb = await asyncio.to_thread(kb_excl_menu, link_id)
    await msg.answer("Правило исключения добавлено.", reply_markup=kb)

@router.callback_query(F.data.startswith("link:") & F.data.contains(":excl:item:"))
async def cb_excl_item(cq: CallbackQuery):
    parts = cq.data.split(":"); link_id = int(parts[1]); excl_id = int(parts[-1])
    kb = InlineKeyboardBuilder()
    kb.button(text="🗑 Удалить правило", callback_data=f"link:{link_id}:excl:del:{excl_id}")
    kb.button(text="⬅️ Назад", callback_data=f"link:{link_id}:excl")
    kb.adjust(1)
    await cq.message.edit_text("Управление правилом исключения:", reply_markup=kb.as_markup())
    await cq.answer()

@router.callback_query(F.data.startswith("link:") & F.data.contains(":excl:del:"))
async def cb_excl_del(cq: CallbackQuery):
    parts = cq.data.split(":"); link_id = int(parts[1]); excl_id = int(parts[-1])

    def _delete():
        with db() as conn, conn.cursor() as cur:
            cur.execute("delete from link_exclusions where id=%s and link_id=%s", (excl_id, link_id))

    await asyncio.to_thread(_delete)
    invalidate_exclusions_for_link(link_id)
    kb = await asyncio.to_thread(kb_excl_menu, link_id)
    await cq.message.edit_text("Правило удалено.", reply_markup=kb)
    await cq.answer("Удалено")

@router.callback_query(F.data.startswith("link:") & F.data.endswith(":rules"))
async def cb_rules_root(cq: CallbackQuery):
    link_id = int(cq.data.split(":")[1])
    kb = await asyncio.to_thread(kb_rule_menu, link_id)
    text = (
        "<b>Правила замены</b>\n\n"
        "Здесь можно задать простые правила вида «что найти» → «на что заменить».\n"
        "Поддерживаются обычный текст, эмодзи и фрагменты с «вшитыми» ссылками.\n"
        "При пересылке сообщения бот применяет все правила по порядку."
        "Максимальное количество правил замены - <b>7</b>\n\n"
        "Ниже — список правил для этой связки:"
    )
    await cq.message.edit_text(text, reply_markup=kb)
    await cq.answer()

def kb_rule_menu(link_id: int) -> InlineKeyboardMarkup:
    with db() as conn, conn.cursor() as cur:
        cur.execute("select id, idx, type, data from rules where link_id=%s order by idx", (link_id,))
        rows = cur.fetchall()
    kb = InlineKeyboardBuilder()
    kb.button(text="➕ Создать правило замены", callback_data=f"link:{link_id}:rules:add")
    for i, r in enumerate(rows, start=1):
        r_display = dict(r); r_display["idx"] = i
        kb.button(text=label_for_rule(r_display), callback_data=f"link:{link_id}:rules:item:{r['id']}")
    kb.button(text="⬅️ Назад", callback_data=f"link:{link_id}:menu")
    kb.adjust(1); return kb.as_markup()

@router.callback_query(F.data.startswith("link:") & F.data.endswith(":rules:add"))
async def cb_rules_add(cq: CallbackQuery, state: FSMContext):
    link_id = int(cq.data.split(":")[1])

    try:
        rows = await aquery(
            "select count(*) as c from rules where link_id=%s",
            (link_id,),
        )
        cnt = int(rows[0]["c"]) if rows else 0
    except Exception as e:
        log.warning("cb_rules_add: DB query failed: %s", e)
        cnt = RULES_MAX

    if cnt >= RULES_MAX:
        await cq.answer("Лимит правил замены достигнут", show_alert=True)
        return

    await state.set_state(AddRule.input_from)
    await state.update_data(link_id=link_id)
    await cq.message.edit_text(
        "Отправьте текст, который нужно заменять (поле «from»).\n"
        "Это может быть слово/фраза/эмодзи или фрагмент с «вшитой» ссылкой."
    )
    await cq.answer()

@router.message(AddRule.input_from, F.chat.type == ChatType.PRIVATE)
async def rules_from(msg: Message, state: FSMContext):
    """
    Шаг 1: пользователь отправляет «что искать».
    Сохраняем и plain-строку, и HTML-версию (со всем форматированием и ссылками),
    чтобы потом заменять по точному совпадению.
    """
    plain = (msg.text or "").strip()
    if not plain:
        return await msg.answer("Пусто. Пришлите значение.")

    # HTML-версия текста с форматированием/ссылками
    htmltxt = getattr(msg, "html_text", None) or plain

    await state.update_data(
        rule_from_plain=plain,
        rule_from_html=htmltxt,
    )
    await state.set_state(AddRule.input_to)
    await msg.answer(
        "Теперь отправьте текст, на который нужно заменить (поле «to»).\n"
        "Форматирование и «вшитые» ссылки будут учтены как есть."
    )


@router.message(AddRule.input_to, F.chat.type == ChatType.PRIVATE)
async def rules_to(msg: Message, state: FSMContext):
    """
    Шаг 2: пользователь отправляет «на что заменить».
    Аналогично сохраняем plain и HTML, и пишем в rules.data.
    """
    plain = (msg.text or "").strip()
    if not plain:
        return await msg.answer("Пусто. Пришлите значение.")

    htmltxt = getattr(msg, "html_text", None) or plain

    data = await state.get_data()
    link_id = int(data["link_id"])
    from_plain = data["rule_from_plain"]
    from_html = data["rule_from_html"]

    def _insert_rule():
        with db() as conn, conn.cursor() as cur:
            cur.execute(
                "select coalesce(max(idx),0)+1 as next from rules where link_id=%s",
                (link_id,),
            )
            idx = cur.fetchone()["next"]
            cur.execute(
                """
                insert into rules(link_id, idx, type, data)
                values (%s,%s,'simple', %s::jsonb)
                """,
                (
                    link_id,
                    idx,
                    json.dumps(
                        {
                            "from_plain": from_plain,
                            "to_plain": plain,
                            "from_html": from_html,
                            "to_html": htmltxt,
                        }
                    ),
                ),
            )

    await asyncio.to_thread(_insert_rule)
    invalidate_rules_for_link(link_id)
    await state.clear()
    kb = await asyncio.to_thread(kb_rule_menu, link_id)
    await msg.answer("Правило добавлено.", reply_markup=kb)


@router.callback_query(F.data.startswith("link:") & F.data.contains(":rules:item:"))
async def cb_rule_item(cq: CallbackQuery):
    parts = cq.data.split(":"); link_id = int(parts[1]); rule_id = int(parts[-1])
    kb = InlineKeyboardBuilder()
    kb.button(text="🗑 Удалить правило", callback_data=f"link:{link_id}:rules:del:{rule_id}")
    kb.button(text="⬅️ Назад", callback_data=f"link:{link_id}:rules")
    kb.adjust(1)
    await cq.message.edit_text("Управление правилом:", reply_markup=kb.as_markup())
    await cq.answer()

@router.callback_query(F.data.startswith("link:") & F.data.contains(":rules:del:"))
async def cb_rule_del(cq: CallbackQuery):
    parts = cq.data.split(":"); link_id = int(parts[1]); rule_id = int(parts[-1])

    def _delete_rule():
        with db() as conn, conn.cursor() as cur:
            cur.execute("delete from rules where id=%s and link_id=%s", (rule_id, link_id))
            cur.execute(
                """
                with ordered as (
                    select id, row_number() over(order by idx) as rn
                      from rules
                     where link_id = %s
                )
                update rules r set idx = o.rn
                  from ordered o
                 where r.id = o.id
                """,
                (link_id,),

            )

    await asyncio.to_thread(_delete_rule)
    invalidate_rules_for_link(link_id)
    kb = await asyncio.to_thread(kb_rule_menu, link_id)
    await cq.message.edit_text("Правило удалено.", reply_markup=kb)
    await cq.answer("Удалено")

@router.callback_query(F.data.startswith("link:") & F.data.endswith(":delete"))
async def cb_link_delete_confirm(cq: CallbackQuery):
    link_id = int(cq.data.split(":")[1])
    kb = InlineKeyboardBuilder()
    kb.button(text="❌ Удалить связку", callback_data=f"link:{link_id}:delete:confirm")
    kb.button(text="⬅️ Назад", callback_data=f"link:{link_id}:menu")
    kb.adjust(1)
    await cq.message.edit_text(
        "Вы уверены, что хотите удалить связку?\nБудут удалены правила и оплата (если была).",
        reply_markup=kb.as_markup()
    )
    await cq.answer()

@router.callback_query(F.data.startswith("link:") & F.data.contains(":delete:confirm"))
async def cb_link_delete(cq: CallbackQuery):
    link_id = int(cq.data.split(":")[1])

    def _delete_link():
        src_id = None
        with db() as conn, conn.cursor() as cur:
            # сначала узнаём source_chat_id, чтобы инвалидировать кэш маршрутизации
            cur.execute("select source_chat_id from channel_links where id=%s", (link_id,))
            row = cur.fetchone()
            if row:
                src_id = row["source_chat_id"]

            cur.execute("delete from rules where link_id=%s", (link_id,))
            cur.execute("delete from link_exclusions where link_id=%s", (link_id,))
            cur.execute("delete from channel_links where id=%s", (link_id,))
        return src_id

    src_id = await asyncio.to_thread(_delete_link)

    if src_id is not None:
        try:
            invalidate_source_links(src_id)
        except Exception as e:
            log.warning("cb_link_delete: failed to invalidate cache: %s", e)

    invalidate_all_for_link(link_id)
    root_kb = await asyncio.to_thread(kb_root, cq.from_user.id)
    await cq.message.edit_text("Связка удалена.", reply_markup=root_kb)
    await cq.answer("Удалено")

@router.callback_query(F.data.startswith("pay:") & F.data.endswith(":menu"))
async def cb_pay_menu(cq: CallbackQuery):
    """
    Подменю «Подписка» для конкретной связки.
    Показывает дату окончания, статус триала и автопродления.
    """
    try:
        link_id = int(cq.data.split(":")[1])
    except Exception:
        await cq.answer("Некорректный ID связки.", show_alert=True)
        return

    text, kb = await asyncio.to_thread(build_pay_menu_text_and_kb, link_id, cq.from_user.id)
    await cq.message.edit_text(text, reply_markup=kb)
    await cq.answer()


@router.callback_query(F.data.startswith("pay:") & F.data.contains(":start"))
async def cb_pay_start(cq: CallbackQuery, state: FSMContext):
    """
    Нажатие на «Оплатить 1 месяц».
    Если email уже есть — сразу создаём платёж.
    Если нет — переводим пользователя в состояние ввода email.
    """
    try:
        link_id = int(cq.data.split(":")[1])
    except Exception:
        await cq.answer("Некорректный ID связки.", show_alert=True)
        return

    tg_user_id = cq.from_user.id
    # важное изменение: get_or_ask_email_for_user может ходить в БД, выносим в threadpool
    email = await asyncio.to_thread(get_or_ask_email_for_user, tg_user_id)

    if not email:
        # нужно спросить email
        await state.set_state(PayEmail.waiting_email)
        await state.update_data(link_id=link_id)

        await cq.message.edit_text(
            "Для оплаты нужна электронная почта для отправки чеков.\n\n"
            "Пожалуйста, отправьте e-mail одним сообщением (например: <code>name@example.com</code>).",
            reply_markup=None,
        )
        await cq.answer()
        return

    # email уже есть — создаём платёж
    try:
        confirmation_url = await create_initial_payment_for_link(tg_user_id, link_id, email)
    except Exception as e:
        log.exception("cb_pay_start: failed to create payment for link %s: %s", link_id, e)
        await cq.answer("Не удалось создать платёж. Попробуйте позже.", show_alert=True)
        return

    kb = InlineKeyboardBuilder()
    kb.button(
        text=f"Оплатить 1 месяц ({YK_SUBSCRIPTION_PRICE_RUB} ₽)",
        url=confirmation_url,
    )
    kb.button(text="⬅️ Назад", callback_data=f"pay:{link_id}:menu")
    kb.adjust(1)

    await cq.message.edit_text(
        "Я сформировал счёт на оплату подписки на 1 месяц.\n\n"
        "Нажмите кнопку ниже, чтобы перейти к оплате в ЮKassa.\n"
        "После успешной оплаты будет подключено автопродление раз в месяц "
        "(его всегда можно отключить в этом меню).",
        reply_markup=kb.as_markup(),
    )
    await cq.answer()


@router.message(PayEmail.waiting_email, F.chat.type == ChatType.PRIVATE)
async def pay_email_input(msg: Message, state: FSMContext):
    """
    Пользователь вводит email для отправки чеков.
    После успешной валидации создаём платёж и показываем кнопку оплаты.
    """
    email = (msg.text or "").strip()

    # простая проверка формата e-mail
    if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", email):
        await msg.answer(
            "Похоже, это не e-mail.\n"
            "Пожалуйста, отправьте адрес в формате <code>name@example.com</code>."
        )
        return

    data = await state.get_data()
    try:
        link_id = int(data.get("link_id"))
    except Exception:
        await state.clear()
        await msg.answer("Что-то пошло не так, попробуйте открыть меню подписки ещё раз.")
        return

    tg_user_id = msg.from_user.id

    try:
        # важное изменение: save_user_email тоже может ходить в БД — выносим в threadpool
        await asyncio.to_thread(save_user_email, tg_user_id, email)
        confirmation_url = await create_initial_payment_for_link(tg_user_id, link_id, email)
    except Exception as e:
        log.exception("pay_email_input: failed to create payment for link %s: %s", link_id, e)
        await state.clear()
        await msg.answer("Не удалось создать платёж. Попробуйте позже.")
        return

    await state.clear()

    kb = InlineKeyboardBuilder()
    kb.button(
        text=f"Оплатить 1 месяц ({YK_SUBSCRIPTION_PRICE_RUB} ₽)",
        url=confirmation_url,
    )
    kb.button(text="⬅️ Назад в подписку", callback_data=f"pay:{link_id}:menu")
    kb.adjust(1)

    await msg.answer(
        "Спасибо! E-mail сохранён.\n\n"
        "Я сформировал счёт на оплату подписки на 1 месяц.\n"
        "Нажмите кнопку ниже, чтобы перейти к оплате.\n"
        "После успешной оплаты будет подключено автопродление раз в месяц "
        "(его всегда можно отключить в меню подписки).",
        reply_markup=kb.as_markup(),
    )


@router.callback_query(F.data.startswith("pay:") & F.data.contains(":stop_confirm"))
async def cb_pay_stop_confirm(cq: CallbackQuery):
    """
    Подтверждение отключения автопродления.
    """
    try:
        link_id = int(cq.data.split(":")[1])
    except Exception:
        await cq.answer("Некорректный ID связки.", show_alert=True)
        return

    kb = InlineKeyboardBuilder()
    kb.button(
        text="✅ Да, остановить",
        callback_data=f"pay:{link_id}:stop_yes",
    )
    kb.button(
        text="⬅️ Отмена",
        callback_data=f"pay:{link_id}:menu",
    )
    kb.adjust(1)

    await cq.message.edit_text(
        "Вы уверены, что хотите остановить автопродление подписки этой связки?\n\n"
        "Текущая оплата будет действовать до конца оплаченного периода, "
        "но новые автосписания выполняться не будут.",
        reply_markup=kb.as_markup(),
    )
    await cq.answer()


@router.callback_query(F.data.startswith("pay:") & F.data.contains(":stop_yes"))
async def cb_pay_stop_yes(cq: CallbackQuery):
    """
    Фактическое отключение автопродления.
    """
    try:
        link_id = int(cq.data.split(":")[1])
    except Exception:
        await cq.answer("Некорректный ID связки.", show_alert=True)
        return

    tg_user_id = cq.from_user.id

    try:
        # disable_autopay_for_link использует синхронный доступ к БД,
        # поэтому выполняем его в threadpool.
        was_enabled = await asyncio.to_thread(disable_autopay_for_link, link_id, tg_user_id)
    except Exception as e:
        log.exception("cb_pay_stop_yes: failed to disable autopay for link %s: %s", link_id, e)
        await cq.answer("Не удалось отключить автопродление, попробуйте позже.", show_alert=True)
        return

    if was_enabled:
        await cq.answer("Автопродление отключено.", show_alert=False)
    else:
        await cq.answer("Автопродление уже было отключено.", show_alert=False)

    text, kb = await asyncio.to_thread(build_pay_menu_text_and_kb, link_id, tg_user_id)
    await cq.message.edit_text(text, reply_markup=kb)


@router.callback_query(F.data == "noop")
async def cb_noop(cq: CallbackQuery):
    await cq.answer()



