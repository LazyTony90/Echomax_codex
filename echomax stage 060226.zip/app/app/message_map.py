# app/message_map.py
import logging
from typing import Optional

from app.db import db

log = logging.getLogger(__name__)

_PLATFORM_TG = "tg"
_PLATFORM_MAX = "max"


def save_tg_to_max(link_id: int, tg_msg_id: int, max_mid: str) -> None:
    """
    Сохраняем соответствие сообщения Telegram -> MAX в cross_message_map.

    Важно: для альбомов несколько tg_msg_id могут соответствовать одному max_mid.
    Это нужно, чтобы reply на любое сообщение/часть альбома в TG корректно находил mid в MAX.
    """
    link_id = int(link_id)
    tg_msg_id = int(tg_msg_id)
    max_mid = str(max_mid)

    with db() as conn, conn.cursor() as cur:
        cur.execute(
            """
            insert into cross_message_map(
                link_id,
                src_platform, src_msg_id,
                dst_platform, dst_msg_id,
                tg_msg_id, max_mid
            )
            values (%s, %s, %s, %s, %s, %s, %s)
            on conflict (link_id, src_platform, src_msg_id) do update
              set dst_platform = excluded.dst_platform,
                  dst_msg_id   = excluded.dst_msg_id,
                  tg_msg_id    = excluded.tg_msg_id,
                  max_mid      = excluded.max_mid
            """,
            (
                link_id,
                _PLATFORM_TG,
                str(tg_msg_id),
                _PLATFORM_MAX,
                max_mid,
                tg_msg_id,
                max_mid,
            ),
        )


def save_max_to_tg(link_id: int, max_mid: str, tg_msg_id: int) -> None:
    """
    Сохраняем соответствие сообщения MAX -> Telegram в cross_message_map.
    """
    link_id = int(link_id)
    tg_msg_id = int(tg_msg_id)
    max_mid = str(max_mid)

    with db() as conn, conn.cursor() as cur:
        cur.execute(
            """
            insert into cross_message_map(
                link_id,
                src_platform, src_msg_id,
                dst_platform, dst_msg_id,
                tg_msg_id, max_mid
            )
            values (%s, %s, %s, %s, %s, %s, %s)
            on conflict (link_id, src_platform, src_msg_id) do update
              set dst_platform = excluded.dst_platform,
                  dst_msg_id   = excluded.dst_msg_id,
                  tg_msg_id    = excluded.tg_msg_id,
                  max_mid      = excluded.max_mid
            """,
            (
                link_id,
                _PLATFORM_MAX,
                max_mid,
                _PLATFORM_TG,
                str(tg_msg_id),
                tg_msg_id,
                max_mid,
            ),
        )


def get_max_mid_for_tg(link_id: int, tg_msg_id: int) -> Optional[str]:
    """
    Находим MAX mid по Telegram message_id (для reply TG -> MAX).
    """
    link_id = int(link_id)
    tg_msg_id = int(tg_msg_id)

    with db() as conn, conn.cursor() as cur:
        cur.execute(
            "select max_mid from cross_message_map where link_id=%s and tg_msg_id=%s",
            (link_id, tg_msg_id),
        )
        r = cur.fetchone()
        if not r:
            return None
        mid = r.get("max_mid")
        return str(mid) if mid is not None else None


def get_tg_msg_id_for_max(link_id: int, max_mid: str) -> Optional[int]:
    """
    Находим Telegram message_id по MAX mid (для reply MAX -> TG).

    После снятия UNIQUE(link_id, max_mid) (нужно для альбомов),
    в таблице может быть несколько строк с одним max_mid.
    Для чатов (1:1 сообщения) по-прежнему будет одна строка.
    Для альбомов выбираем детерминированно самое маленькое tg_msg_id.
    """
    link_id = int(link_id)
    max_mid = str(max_mid)

    with db() as conn, conn.cursor() as cur:
        cur.execute(
            """
            select tg_msg_id
            from cross_message_map
            where link_id=%s and max_mid=%s
            order by tg_msg_id asc
            limit 1
            """,
            (link_id, max_mid),
        )
        r = cur.fetchone()
        if not r:
            return None
        v = r.get("tg_msg_id")
        try:
            return int(v) if v is not None else None
        except Exception:
            return None

