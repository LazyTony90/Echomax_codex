# app/app/expiry_notifier.py
# Уведомления за 24 часа до окончания триала/оплаты для связок без автоплатежа.
# Без изменений структуры БД: состояние "уже уведомляли" хранится в JSON в /app/cache (volume tg-cache).

import asyncio
import json
import os
import logging
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, Optional, Iterator, Tuple

from zoneinfo import ZoneInfo

from app.db import db

logger = logging.getLogger(__name__)

MSK = ZoneInfo("Europe/Moscow")

CACHE_FILE = Path("/app/cache/expiry_notifier_state.json")


@dataclass
class ExpiringLink:
    link_id: int
    owner_tg_user_id: int
    name: Optional[str]
    link_type: str
    target_platform: str
    paid_until: Optional[datetime]
    trial_until: Optional[datetime]
    is_trial: bool
    expiry_at: datetime


def _load_state() -> Dict[str, Any]:
    try:
        if CACHE_FILE.exists():
            return json.loads(CACHE_FILE.read_text(encoding="utf-8"))
    except Exception:
        logger.exception("expiry_notifier: failed to load state")
    return {"sent": {}}


def _save_state(state: Dict[str, Any]) -> None:
    try:
        CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
        tmp = CACHE_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(CACHE_FILE)
    except Exception:
        logger.exception("expiry_notifier: failed to save state")


def _expiry_key(link_id: int, expiry_at: datetime) -> str:
    return f"{link_id}:{expiry_at.astimezone(timezone.utc).isoformat()}"


def _format_msk(dt: datetime) -> str:
    d = dt.astimezone(MSK)
    return d.strftime("%d.%m.%Y %H:%M") + " МСК"


def _is_trial_active(paid_until: Optional[datetime], trial_until: Optional[datetime], is_trial: bool, now: datetime) -> bool:
    if not is_trial:
        return False
    if trial_until is not None and trial_until > now:
        return True
    # fallback для старых данных: is_trial=true, trial_until пустой, но paid_until ещё не истёк
    if trial_until is None and paid_until is not None and paid_until > now:
        return True
    return False


def _compute_expiry(paid_until: Optional[datetime], trial_until: Optional[datetime]) -> Optional[datetime]:
    candidates = [d for d in (paid_until, trial_until) if d is not None]
    return max(candidates) if candidates else None


def _get_db_cursor():
    """
    В проекте db() может возвращать:
      - connection (psycopg2 connection), либо
      - cursor, либо
      - (conn, cursor)
    Этот хелпер делает код устойчивым ко всем вариантам, не меняя app.db.
    """
    ctx = db()
    entered = ctx.__enter__()
    try:
        # (conn, cur)
        if isinstance(entered, tuple) and len(entered) == 2:
            conn, cur = entered
            return ctx, conn, cur, False  # False => cursor management outside not needed
        # cursor-like
        if hasattr(entered, "execute") and hasattr(entered, "fetchall"):
            return ctx, None, entered, True
        # connection-like
        if hasattr(entered, "cursor"):
            conn = entered
            cur = conn.cursor()
            return ctx, conn, cur, True  # True => we created cursor, must close
        # unexpected
        raise TypeError(f"Unsupported db() enter type: {type(entered)}")
    except Exception:
        # make sure to exit context if we failed mid-way
        try:
            ctx.__exit__(None, None, None)
        except Exception:
            pass
        raise


def _close_db_cursor(ctx, conn, cur, created_cursor: bool):
    try:
        if created_cursor and cur is not None:
            try:
                cur.close()
            except Exception:
                pass
    finally:
        ctx.__exit__(None, None, None)


def _get_expiring_links(now: datetime, window: timedelta) -> list[ExpiringLink]:
    sql = """
        SELECT
            cl.id,
            cl.owner_tg_user_id,
            cl.name,
            cl.link_type,
            cl.target_platform,
            cl.paid_until,
            cl.trial_until,
            cl.is_trial
        FROM channel_links cl
        LEFT JOIN link_autopay la
            ON la.link_id = cl.id AND la.enabled = true
        WHERE la.id IS NULL
          AND (cl.paid_until IS NOT NULL OR cl.trial_until IS NOT NULL)
          AND GREATEST(
                COALESCE(cl.paid_until, to_timestamp(0)),
                COALESCE(cl.trial_until, to_timestamp(0))
              ) > %(now)s
          AND GREATEST(
                COALESCE(cl.paid_until, to_timestamp(0)),
                COALESCE(cl.trial_until, to_timestamp(0))
              ) <= %(until)s
    """
    until = now + window
    out: list[ExpiringLink] = []

    ctx, conn, cur, created_cursor = _get_db_cursor()
    try:
        cur.execute(sql, {"now": now, "until": until})
        rows = cur.fetchall() or []
        for row in rows:
            if isinstance(row, dict):
                link_id = int(row["id"])
                owner = int(row["owner_tg_user_id"])
                name = row.get("name")
                link_type = row.get("link_type") or "channel"
                target_platform = row.get("target_platform") or "tg"
                paid_until = row.get("paid_until")
                trial_until = row.get("trial_until")
                is_trial = bool(row.get("is_trial", False))
            else:
                (link_id, owner, name, link_type, target_platform, paid_until, trial_until, is_trial) = row

            expiry_at = _compute_expiry(paid_until, trial_until)
            if not expiry_at:
                continue

            out.append(
                ExpiringLink(
                    link_id=int(link_id),
                    owner_tg_user_id=int(owner),
                    name=name,
                    link_type=str(link_type),
                    target_platform=str(target_platform),
                    paid_until=paid_until,
                    trial_until=trial_until,
                    is_trial=bool(is_trial),
                    expiry_at=expiry_at,
                )
            )
    finally:
        _close_db_cursor(ctx, conn, cur, created_cursor)

    return out


async def expiry_notifier_worker(bot, *, check_every_seconds: int | None = None, window_hours: int | None = None) -> None:
    # Параметры можно задавать через .env без правок кода:
    #   EXPIRY_NOTIFY_CHECK_SEC=3600
    #   EXPIRY_NOTIFY_WINDOW_HOURS=24
    # Если параметры не переданы явно — берём из env, иначе используем дефолты.
    if check_every_seconds is None:
        try:
            check_every_seconds = int(os.getenv("EXPIRY_NOTIFY_CHECK_SEC", "3600"))
        except Exception:
            check_every_seconds = 3600
    if window_hours is None:
        try:
            window_hours = int(os.getenv("EXPIRY_NOTIFY_WINDOW_HOURS", "24"))
        except Exception:
            window_hours = 24

    state = _load_state()
    sent: Dict[str, str] = state.setdefault("sent", {})

    max_age = timedelta(days=60)

    while True:
        try:
            now = datetime.now(timezone.utc)

            # cleanup sent cache
            cutoff = now - max_age
            for k, v in list(sent.items()):
                try:
                    ts = datetime.fromisoformat(v)
                    if ts.tzinfo is None:
                        ts = ts.replace(tzinfo=timezone.utc)
                    if ts < cutoff:
                        sent.pop(k, None)
                except Exception:
                    sent.pop(k, None)

            expiring = _get_expiring_links(now, timedelta(hours=window_hours))
            for link in expiring:
                key = _expiry_key(link.link_id, link.expiry_at)
                if key in sent:
                    continue

                trial_active = _is_trial_active(link.paid_until, link.trial_until, link.is_trial, now)
                expiry_str = _format_msk(link.expiry_at)

                link_name = (link.name or f"Связка #{link.link_id}").strip()
                kind = "пробного периода" if trial_active else "подписки"

                text = (
                    f"⏰ Напоминание по связке: {link_name}\n\n"
                    f"Через ~24 часа наступит окончание {kind}: *{expiry_str}*.\n"
                    f"Автоплатёж отключён, поэтому для продолжения работы связки нужно оплатить подписку.\n\n"
                    f"Откройте бота → выберите связку → *Оплатить подписку*."
                )

                try:
                    await bot.send_message(
                        chat_id=link.owner_tg_user_id,
                        text=text,
                        parse_mode="Markdown",
                        disable_web_page_preview=True,
                    )
                    sent[key] = datetime.now(timezone.utc).isoformat()
                    _save_state(state)
                except Exception:
                    logger.exception("expiry_notifier: failed to send reminder (link_id=%s)", link.link_id)

        except Exception:
            logger.exception("expiry_notifier: loop failed")

        await asyncio.sleep(max(60, int(check_every_seconds)))

